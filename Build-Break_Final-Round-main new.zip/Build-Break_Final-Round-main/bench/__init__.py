"""Measured SYNAPSE benchmark runs."""
