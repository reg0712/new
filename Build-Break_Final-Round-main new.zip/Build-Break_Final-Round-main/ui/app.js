/* SYNAPSE dashboard. All data comes from this server; no external assets. */
"use strict";

const state = { workflows: [], selected: null, compiled: null, benchMode: "mock",
                bench: null, validation: null, pair: null, models: [], compiledFiles: {},
                workflowVersion: 0, benchVersion: 0 };
const LOAN_WORKFLOW = "loan_prescreen", REVIEW_WORKFLOW = "review_sentiment";
const MODEL_SELECTS = ["liveModel", "pdfModel", "reviewModel"];
const SENTIMENTS = ["positive", "neutral", "negative"];
const $ = id => document.getElementById(id);
const esc = value => String(value ?? "").replace(/[&<>"']/g, c =>
  ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
const ms = value => value == null ? "—" : `${Number(value).toFixed(1)} ms`;
const num = (value, digits = 1) => value == null ? "—" : Number(value).toFixed(digits);
const cost = (value, unit) => value == null ? "—" :
  String(unit ?? "").startsWith("USD") ? `$${Number(value).toFixed(8)}` : `${num(value, 3)} mock units`;
const tokens = value => value == null ? "—" : num(value, Number.isInteger(value) ? 0 : 1);
function change(before, after, format) {
  if (before == null || after == null) return "—";
  const delta = before - after;
  if (Math.abs(delta) < 1e-12) return "No change";
  const share = before ? ` (${num(Math.abs(delta) / before * 100, 1)}%)` : "";
  return `${format(Math.abs(delta))}${share} ${delta < 0 ? "more" : "saved"}`;
}
const recordUsage = record => record?.usage_totals || {
  tokens_in: (record?.nodes || []).reduce((sum, node) => sum + node.usage.tokens_in, 0),
  tokens_out: (record?.nodes || []).reduce((sum, node) => sum + node.usage.tokens_out, 0),
  tokens_total: (record?.nodes || []).reduce((sum, node) =>
    sum + node.usage.tokens_in + node.usage.tokens_out, 0),
  cost: (record?.nodes || []).reduce((sum, node) => sum + node.usage.cost, 0)
};

/* FastAPI sends detail as a string, or as a list of {loc, msg} for request validation. */
function detailText(detail) {
  if (detail == null || detail === "") return "";
  if (typeof detail === "string") return detail;
  if (Array.isArray(detail)) return detail.map(item => typeof item === "string" ? item :
    [(item?.loc || []).filter(part => part !== "body" && part !== "query").join("."),
      item?.msg].filter(Boolean).join(": ")).join("; ");
  return JSON.stringify(detail);
}
async function httpError(response) {
  const data = await response.json().catch(() => ({}));
  const failure = new Error(detailText(data.detail) || `${response.status} ${response.statusText}`);
  failure.status = response.status;
  return failure;
}
async function json(url, options = {}) {
  const response = await fetch(url, { ...options, headers: { "Content-Type": "application/json",
    ...options.headers } });
  if (!response.ok) throw await httpError(response);
  return response.json().catch(() => ({}));
}
const post = (url, body) => json(url, { method: "POST", body: JSON.stringify(body) });
function error(where, exception) {
  const message = String(exception.message || exception);
  const friendly = /minute model budget|local minute budget/i.test(message) ?
    "This model's local minute budget is full. Wait a minute or select Mock." :
    /daily model budget|daily model quota/i.test(message) ?
    "The provider reported an exhausted quota. You can run this model again to recheck, or choose another model." :
    /quota|RESOURCE_EXHAUSTED|rate.?limit|\b429\b/i.test(message) ?
    "Model quota or rate limit reached. Select another provider or Mock, then try again." :
    message.length > 280 ? `${message.slice(0, 277)}…` : message;
  $(where).innerHTML = `<p class="notice error">${esc(friendly)}</p>`;
}
const savingClass = (before, after) => before > after ? "good" : before < after ? "bad" : "";
const deltaLabel = (before, after, name) => `${name} ${after > before ? "increase" : "reduction"}`;
const timeRatio = (before, after) => before && after ? (before >= after ?
  `${num(before / after, 2)}× faster` : `${num(after / before, 2)}× slower`) : "—";
function metric(label, value, detail = "", klass = "") {
  return `<div class="metric"><div class="label">${esc(label)}</div>` +
    `<div class="value ${klass}">${esc(value)}</div><div class="detail">${esc(detail)}</div></div>`;
}
function selectCases() {
  const workflow = state.workflows.find(w => w.file === state.selected);
  const cases = workflow?.cases || [];
  for (const id of ["timelineCase", "liveCase"]) {
    $(id).innerHTML = cases.map(c => `<option value="${esc(c)}">${esc(c)}</option>`).join("");
  }
  fillScales(["timelineScale", "liveScale"]);
}
function fillScales(ids) {
  for (const id of ids) {
    $(id).innerHTML = [["0.001", "Fast"], ["0.01", "Demo"],
      ["0.1", "Visible"], ["1", "Full"]].map(([v, label]) =>
      `<option value="${v}" ${v === "0.01" ? "selected" : ""}>${label} (×${v})</option>`).join("");
  }
}
const workflowNamed = name => state.workflows.find(w => w.name === name);

function graphSvg(nodes, groups, original = false) {
  const perRow = original ? 1 : Math.max(1, ...groups.map(g => g.length));
  const cellW = 205, cellH = 88, left = 24, top = 34;
  const height = top + groups.length * cellH + 26;
  const width = left * 2 + perRow * cellW;
  const positions = {};
  groups.forEach((group, row) => group.forEach((id, col) => {
    positions[id] = { x: left + col * cellW, y: top + row * cellH };
  }));
  const arrows = nodes.flatMap(node => (node.deps || []).map(dep => {
    const a = positions[dep], b = positions[node.id];
    if (!a || !b) return "";
    return `<path class="edge" marker-end="url(#arrow)" d="M ${a.x + 92} ${a.y + 53} ` +
      `C ${a.x + 92} ${b.y - 9}, ${b.x + 92} ${a.y + 61}, ${b.x + 92} ${b.y - 4}"/>`;
  })).join("");
  const boxes = groups.map((group, row) => {
    if (original || group.length < 2) return "";
    return `<g class="group"><rect x="${left - 10}" y="${top + row * cellH - 16}" ` +
      `width="${perRow * cellW - 5}" height="${cellH - 4}" rx="10"/>` +
      `<text x="${left}" y="${top + row * cellH - 1}">PARALLEL</text></g>`;
  }).join("");
  const cards = nodes.map(node => {
    const p = positions[node.id];
    if (!p) return "";
    const removed = node.removed ? (node.removed.pass === "cse" ?
      `merged → ${node.removed.into}` : "removed") : "";
    const tags = [removed, node.routed ? `${node.routed.from} → ${node.routed.to}` : "",
      node.cached ? "cached" : ""].filter(Boolean).join(" · ");
    const kind = `${node.kind || ""} · ${node.effect || ""}` +
      (node.model ? ` · ${node.model}` : "");
    return `<g class="node ${esc(node.effect)} ${node.removed ? "removed" : ""} ` +
      `${node.routed ? "routed" : ""}"><rect class="box" x="${p.x}" y="${p.y}" ` +
      `width="184" height="58" rx="8"/><text class="id" x="${p.x + 10}" ` +
      `y="${p.y + 21}">${esc(node.id)}</text><text class="sub" x="${p.x + 10}" ` +
      `y="${p.y + 39}">${esc(kind)}</text>` +
      (tags ? `<text class="tag" x="${p.x + 10}" y="${p.y + 55}">${esc(tags)}</text>` : "") +
      `</g>`;
  }).join("");
  return `<svg viewBox="0 0 ${width} ${height}" role="img" ` +
    `aria-label="${original ? "Original" : "Compiled"} workflow graph">` +
    `<defs><marker id="arrow" markerWidth="8" markerHeight="8" refX="6" refY="3" ` +
    `orient="auto"><path class="arrowhead" d="M0 0L6 3L0 6Z"/></marker></defs>` +
    `${boxes}${arrows}${cards}</svg>`;
}

function renderGraph() {
  const data = state.compiled;
  if (!data) return;
  const before = data.graph.source.nodes, after = data.graph.compiled.nodes;
  const originalGroups = before.map(n => [n.id]);
  $("graphOriginal").innerHTML = graphSvg(before, originalGroups, true);
  $("graphCompiled").innerHTML = graphSvg(after, data.graph.levels);
  const parallel = data.graph.levels.filter(g => g.length > 1).length;
  $("graphSummary").innerHTML = [
    `${before.length} → ${after.length} steps`, `${parallel} parallel groups`,
    `${after.filter(n => n.cached).length} cacheable`].map(x =>
      `<span class="chip">${esc(x)}</span>`).join("");
}

function renderDecisions() {
  const rows = state.compiled?.passes || [];
  $("decisionRows").innerHTML = rows.map(row => {
    const verdict = row.verdict?.verdict || "—";
    const measured = row.measured_ms == null ? "—" :
      `${ms(row.measured_ms)}${row.measured_basis === "warm" ? " (warm)" : ""}`;
    return `<tr class="${esc(row.status)}"><td data-label="Pass">${esc(row.label || row.pass_name)}</td>` +
      `<td data-label="Compiler"><span class="pill ${esc(row.status)}">${esc(row.status)}</span></td>` +
      `<td data-label="Validation"><span class="pill ${esc(verdict)}">${esc(verdict)}</span></td>` +
      `<td data-label="Steps">${esc((row.nodes || []).join(", ") || "—")}</td>` +
      `<td data-label="Reason">${esc(row.reason || "—")}</td>` +
      `<td data-label="Predicted gain" class="num">${esc(ms(row.predicted_ms))}</td>` +
      `<td data-label="Measured gain" class="num">${esc(measured)}</td>` +
      `<td data-label="Cost change" class="num">` +
      `${esc(row.measured_cost == null ? "—" : num(row.measured_cost, 3))}</td></tr>`;
  }).join("") || `<tr><td colspan="8">No compiler decisions yet.</td></tr>`;
  $("decisionNote").textContent = state.compiled?.profile ?
    `Predictions use ${state.compiled.profile.runs} stored mock baseline run(s). ` +
    `Measured gains come from the latest benchmark, when available.` :
    "Run a profile and benchmark to populate predicted and measured gains.";
}

function gantt(records, compiled = state.compiled) {
  if (!records?.baseline && !records?.compiled) return `<p class="muted">Run a workflow first.</p>`;
  const max = Math.max(records.baseline?.wall_ms || 0, records.compiled?.wall_ms || 0, 1);
  const kinds = new Map((compiled?.source?.nodes || []).map(n => [n.id, n.kind]));
  const sections = ["baseline", "compiled"].filter(mode => records[mode]).map(mode => {
    const record = records[mode];
    const rows = (record.nodes || []).map(node => {
      if (node.skipped) return `<div class="row skip"><span class="name" title="${esc(node.node_id)}">` +
        `${esc(node.node_id)}</span><div class="track" title="${esc(node.skip_reason || "Branch not taken")}">` +
        `<span>Skipped · ${esc(node.skip_reason || "branch not taken")}</span></div></div>`;
      const left = 100 * node.start_s * 1000 / max;
      const width = Math.max(.4, 100 * (node.end_s - node.start_s) * 1000 / max);
      const label = `${node.node_id}: ${ms((node.end_s - node.start_s) * 1000)}` +
        (node.cache_hit ? " · cache hit" : "") + (node.error ? ` · ${node.error}` : "");
      return `<div class="row"><span class="name" title="${esc(node.node_id)}">` +
        `${esc(node.node_id)}</span><div class="track"><div class="bar ` +
        `k-${esc(kinds.get(node.node_id) || "tool")} ${node.cache_hit ? "hit" : ""} ` +
        `${node.error ? "err" : ""}" style="left:${left}%;width:${width}%" ` +
        `title="${esc(label)}"></div></div></div>`;
    }).join("");
    return `<div class="section ${mode}"><div class="section-head"><strong>` +
      `${mode === "baseline" ? "Original" : "Compiled"}</strong><span class="time">` +
      `${esc(ms(record.wall_ms))}</span></div>${rows}</div>`;
  }).join("");
  const ticks = [0, .25, .5, .75, 1].map(part =>
    `<span style="left:${part * 100}%">${esc(ms(max * part))}</span>`).join("");
  return sections + `<div class="axis">${ticks}</div>`;
}

function watch(runId, mode, onEvent) {
  return new Promise((resolve, reject) => {
    const scheme = location.protocol === "https:" ? "wss:" : "ws:";
    const socket = new WebSocket(`${scheme}//${location.host}/ws/runs/${encodeURIComponent(runId)}`);
    let finished = false;
    socket.onmessage = message => {
      let event;
      try { event = JSON.parse(message.data); }
      catch (_) { finished = true; socket.close(); reject(new Error(`Unreadable event during ${mode}`)); return; }
      onEvent(mode, event);
      if (event.type === "run_end") { finished = true; socket.close(); resolve(event); }
      if (event.type === "error") { finished = true; socket.close(); reject(new Error(event.message)); }
    };
    socket.onerror = () => { finished = true; reject(new Error(`Event stream failed for ${mode}`)); };
    socket.onclose = () => { if (!finished) reject(new Error(`Event stream closed during ${mode}`)); };
  });
}

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const providerName = p => ({ gemini: "Gemini", groq: "Groq", openrouter: "OpenRouter" })[p] || p;

function isDailyQuotaError(err) {
  const msg = [
    err?.message,
    err?.errorDetail,
    ...(err?.record?.nodes || []).map(n => n.error),
    ...Object.values(err?.records || {}).flatMap(r => (r.nodes || []).map(n => n.error))
  ].filter(Boolean).join(" ").toLowerCase();
  return /perday|per_day|per-day|requests per day|per day limit|daily quota|tokens per day|daily.*budget reached/i.test(msg);
}

function isMinuteRateLimitError(err) {
  if (!err || isDailyQuotaError(err)) return false;
  const msg = [
    err.message,
    err.errorDetail,
    ...(err.record?.nodes || []).map(n => n.error),
    ...Object.values(err.records || {}).flatMap(r => (r.nodes || []).map(n => n.error))
  ].filter(Boolean).join(" ").toLowerCase();
  return /quota|rate[ -]?limit|429|resource_exhausted|too many requests|minute budget|waiting for the minute window|retry in/i.test(msg);
}

function getRateLimitWaitSeconds(err) {
  const msg = [
    err?.message,
    err?.errorDetail,
    ...(err?.record?.nodes || []).map(n => n.error),
    ...Object.values(err?.records || {}).flatMap(r => (r.nodes || []).map(n => n.error))
  ].filter(Boolean).join(" ");
  const match = msg.match(/retry in ([\d.]+)\s*s/i);
  if (match) {
    return Math.max(5, Math.ceil(parseFloat(match[1])) + 2);
  }
  return 60;
}

async function waitForRateLimitRefresh(seconds, stoppedLabel, otherPrefix = "", statusId = "liveStatus") {
  for (let s = seconds; s > 0; s--) {
    const prefix = otherPrefix ? `${otherPrefix} ` : "";
    $(statusId).textContent =
      `${prefix}${stoppedLabel} agent stopped due to rate limits. Waiting ${s}s for rate limits to refresh before rerunning ${stoppedLabel.toLowerCase()} agent...`;
    await sleep(1000);
    if (s % 5 === 0 || s === 1) {
      loadModels().catch(() => {});
    }
  }
  $(statusId).textContent = `Rate limits refreshed. Rerunning ${stoppedLabel.toLowerCase()} agent...`;
}

/* One retry policy for every screen: wait out per-minute rate limits and run again; never
   retry a daily quota (isMinuteRateLimitError excludes it) or an error marked noRetry. */
async function withRateLimitRetry(attempt, { label, statusId, prefix = () => "", maxAttempts = 3 }) {
  for (let tries = 1; ; tries++) {
    try {
      return await attempt(tries);
    } catch (err) {
      if (err?.noRetry || tries >= maxAttempts || !isMinuteRateLimitError(err)) throw err;
      await waitForRateLimitRefresh(getRateLimitWaitSeconds(err), label, prefix(), statusId);
    }
  }
}
const modeLabel = mode => mode === "baseline" ? "Original" : "Compiled";

/* Follow a started run to its end and return its record. The event stream only drives the
   timers: when it fails the record is still read (and polled while the run is going), and a
   run that did not finish reports the stream error instead of a bare "run failed". */
async function followRun(runId, mode, onEvent = () => {}) {
  const url = `/runs/${encodeURIComponent(runId)}`;
  let streamError = null, readError = null;
  try {
    await watch(runId, mode, onEvent);
  } catch (exc) { streamError = exc; }
  const read = () => json(url).then(record => { readError = null; return record; },
    exc => { readError = exc; return null; });
  let record = await read();
  for (let polls = 0; streamError && record?.status === "running" && polls < 600; polls++) {
    await sleep(1000);
    record = (await read()) || record;
  }
  if (!record || record.status !== "done" || record.nodes?.some(n => n.error)) {
    const runError = record?.error || record?.nodes?.find(n => n.error)?.error;
    const finished = record && record.status !== "running";
    const errorMsg = (finished && runError) || [
      streamError && streamError.message,
      !record ? `could not read the run record${readError ? ` (${readError.message})` : ""}` :
        record.status === "running" ? "the run had not finished" : "",
      runError
    ].filter(Boolean).join("; ") || "run failed";
    const failure = new Error(`${record?.mode || mode} run failed: ${errorMsg}`);
    failure.records = record ? { [mode]: record } : {};
    failure.record = record;
    failure.mode = mode;
    failure.errorDetail = errorMsg;
    failure.streamError = streamError;
    failure.noRetry = record?.rerun_safe !== true;
    if (failure.noRetry && isMinuteRateLimitError(failure))
      failure.errorDetail += "; automatic retry skipped because a write may have completed";
    throw failure;
  }
  return record;
}

async function runOne(caseId, scale, choice, mode, onEvent = () => {}) {
  const { provider, model } = choice;
  onEvent(mode, { type: "run_start" });
  const started = await post("/runs", { workflow: choice.workflow || state.selected, mode,
    case_id: caseId, scale, live: provider !== "mock", provider, model,
    cache_mode: mode === "compiled" && choice.warm ? "warm" : "cold" });
  return followRun(started.run_id, mode, onEvent);
}

async function runPair(caseId, scale, choice, onEvent = () => {}, statusId = "timelineStatus") {
  const records = {};
  const collect = async mode => {
    records[mode] = await withRateLimitRetry(() => runOne(caseId, scale, choice, mode, onEvent), {
      label: modeLabel(mode), statusId,
      prefix: () => mode === "compiled" && records.baseline ?
        `Original run finished (${ms(records.baseline.wall_ms)}).` : "" });
  };
  try {
    if (choice.provider === "mock" || choice.provider === "groq") {
      const results = await Promise.allSettled([collect("baseline"), collect("compiled")]);
      const failed = results.find(r => r.status === "rejected");
      if (failed) throw failed.reason;
    } else {
      await collect("baseline");
      await collect("compiled");
    }
    return records;
  } catch (exc) {
    exc.records = { ...records, ...exc.records };
    throw exc;
  }
}

async function timelineRun() {
  $("timelineRun").disabled = true;
  $("timelineGantt").innerHTML = `<p class="muted">Running both versions…</p>`;
  $("timelineLegend").innerHTML = "";
  $("timelineStatus").textContent = "";
  const workflow = state.selected, compiled = state.compiled;
  const version = state.workflowVersion;
  try {
    const pair = await runPair($("timelineCase").value, Number($("timelineScale").value),
      { provider: "mock", model: null, workflow });
    if (state.workflowVersion !== version) return;
    state.pair = pair;
    $("timelineGantt").innerHTML = gantt(state.pair, compiled);
    const a = state.pair.baseline, b = state.pair.compiled;
    $("timelineLegend").innerHTML = `<span>Decision: ${esc(a.key_value)} → ` +
      `${esc(b.key_value)}</span><span>Speedup: ${esc(num(a.wall_ms / b.wall_ms, 2))}×</span>`;
  } catch (exc) {
    if (state.workflowVersion !== version) return;
    error("timelineGantt", exc);
    if (Object.keys(exc.records || {}).length)
      $("timelineGantt").innerHTML += gantt(exc.records, compiled);
  }
  finally { $("timelineRun").disabled = false; }
}

function renderValidation(data) {
  $("validationStatus").textContent = `${data.passed}/${data.checks.length} checks passed ` +
    `across ${data.cases.length} cases in ${num(data.duration_s, 1)} s.`;
  const verdicts = Object.entries(data.verdicts || {}).map(([name, value]) =>
    `<div class="verdict ${esc(value.verdict)}"><strong>${esc(name)}: ` +
    `${esc(value.verdict)}</strong><div class="why">${esc(value.reason)}</div></div>`).join("");
  const cases = data.cases.map(row => `<div class="case ${row.passed ? "" : "fail"}">` +
    `<strong>${esc(row.case_id)}</strong><small>${row.passed ? "pass" : "fail"} · ` +
    `${esc(row.checks)} checks</small></div>`).join("");
  $("validationContent").innerHTML = `<div class="card"><h3>Pass verdicts</h3>` +
    `<div class="verdicts">${verdicts}</div></div><div class="card"><h3>Cases</h3>` +
    `<div class="case-grid">${cases}</div></div>`;
}

async function validateRun() {
  $("validateRun").disabled = true;
  $("validationStatus").textContent = "Validating every case and pass with mock models…";
  const workflow = state.selected, version = state.workflowVersion;
  try {
    const validation = await post("/validate", { workflow,
      unsafe_route_risk: $("unsafe").checked, scale: .001 });
    if (state.workflowVersion !== version) return;
    state.validation = validation;
    renderValidation(state.validation);
    const compiled = await post("/compile", { workflow });
    if (state.workflowVersion !== version) return;
    state.compiled = compiled;
    renderGraph(); renderDecisions();
  } catch (exc) {
    if (state.workflowVersion === version) error("validationContent", exc);
  }
  finally { $("validateRun").disabled = false; }
}

function renderBench() {
  const all = state.bench;
  const result = Array.isArray(all) ? all.find(x => x.workflow ===
    state.workflows.find(w => w.file === state.selected)?.name) : null;
  if (!result) {
    $("benchContent").innerHTML = `<p class="notice">No ${esc(state.benchMode)} benchmark ` +
      `for this workflow yet. Run <code>make bench</code> to generate one.</p>`;
    return;
  }
  const cold = (result.configurations || []).filter(x => x.cache === "cold");
  const warm = (result.configurations || []).filter(x => x.cache === "warm");
  if (!cold.length) {
    $("benchContent").innerHTML = `<p class="notice">The ${esc(state.benchMode)} benchmark for ` +
      `this workflow has no cold-cache configurations to show.</p>`;
    return;
  }
  const first = cold[0], last = cold[cold.length - 1];
  const unit = result.cost_unit || "mock units";
  const getCost = row => row.mean_cost ?? row.mean_cost_mock_units;
  const getTokens = row => row.mean_tokens_in == null || row.mean_tokens_out == null ?
    null : row.mean_tokens_in + row.mean_tokens_out;
  const modelLabel = result.selected_model || (result.model_names ?
    [...new Set(Object.values(result.model_names))].join(" / ") : null);
  const valid = row => row.comparable !== false && !row.errors &&
    row.correct === row.runs && row.usage_complete !== false &&
    row.p50_ms != null && getTokens(row) != null && getCost(row) != null;
  const comparable = first.name === "baseline" && cold.length > 1 &&
    cold.every(valid) && result.summary?.comparable !== false &&
    (state.benchMode !== "live" || modelLabel);
  const headline = comparable ? [
    metric("Cold median", ms(last.p50_ms), `${ms(first.p50_ms)} original · ${timeRatio(first.p50_ms, last.p50_ms)}`, savingClass(first.p50_ms, last.p50_ms)),
    metric("Cold p95", ms(last.p95_ms), `${ms(first.p95_ms)} original`),
    metric("Original tokens / case", tokens(getTokens(first)),
      `${tokens(first.mean_tokens_in)} in · ${tokens(first.mean_tokens_out)} out`),
    metric("Optimized tokens / case", tokens(getTokens(last)),
      `${tokens(last.mean_tokens_in)} in · ${tokens(last.mean_tokens_out)} out`),
    metric("Token reduction", change(getTokens(first), getTokens(last), tokens)),
    metric("Original cost / case", cost(getCost(first), unit)),
    metric("Optimized cost / case", cost(getCost(last), unit)),
    metric("Cost reduction", change(getCost(first), getCost(last), value => cost(value, unit))),
    metric("Decision checks", `${last.correct}/${last.runs}`,
      `${result.correctness || "Expected outputs checked"} · ` +
      `${result.cases} cases × ${result.repeats} repeats`, "good")
  ].join("") : "";
  const reason = first.name !== "baseline" || cold.length < 2 ?
    "A baseline and an optimized step are required for a comparison." :
    state.benchMode === "live" && !modelLabel ?
      "This saved live benchmark does not record its model. Rerun it before comparing costs." :
      "A run failed, produced an incorrect answer, or has incomplete usage. Savings are hidden.";
  const table = cold.map((row, i) => `<tr><td>${esc(row.label || row.name)}</td>` +
    `<td class="num">${esc(ms(row.p50_ms))}</td><td class="num">${esc(ms(row.p95_ms))}</td>` +
    `<td class="num">${esc(num(row.mean_llm_calls, 2))}</td>` +
    `<td class="num">${esc(num(row.mean_tokens_in, 0))} / ${esc(num(row.mean_tokens_out, 0))}</td>` +
    `<td class="num">${esc(cost(getCost(row), unit))}</td>` +
    `<td class="num">${esc(row.correct)}/${esc(row.runs)}</td>` +
    `<td class="num">${i && cold[i - 1].p50_ms != null && row.p50_ms != null ?
      esc(ms(cold[i - 1].p50_ms - row.p50_ms)) : "—"}</td></tr>`).join("");
  const warmText = comparable && warm.length > 1 && warm.every(valid) ? `<p class="note">Repeat customer: ` +
    `${esc(ms(warm[0].p50_ms))} → ${esc(ms(warm[warm.length - 1].p50_ms))} ` +
    `(${esc(num(warm[0].p50_ms / warm[warm.length - 1].p50_ms, 2))}×).</p>` : "";
  $("benchContent").innerHTML = (comparable ? `<div class="metrics">${headline}</div>` :
    `<p class="notice">${esc(reason)}</p>`) + `<div class="card scroll">` +
    `<h3>Ablation bridge · cold cache</h3><table><thead><tr><th>Configuration</th>` +
    `<th class="num">Median</th><th class="num">p95</th><th class="num">LLM calls</th>` +
    `<th class="num">Tokens in / out</th><th class="num">Cost</th>` +
    `<th class="num">Correct</th><th class="num">Gain vs prior</th></tr></thead>` +
    `<tbody>${table}</tbody></table>${warmText}</div><p class="note">` +
    `${result.sample ? "Bundled synthetic example" : "Measured locally"} ` +
    `with synthetic bank delay scale ×${esc(result.latency_scale)}; generated ${esc(result.created_at)}. ` +
    `${state.benchMode === "mock" ? "Mock cost units are not dollars." :
      `Model: ${esc(modelLabel || "unknown")}. USD costs estimate published paid-tier prices; ` +
      "free-tier usage may incur no charge. Output token variation affects cost; " +
      "Groq two-account timing may differ with provider load."}</p>`;
}

async function loadBench() {
  const mode = state.benchMode, version = ++state.benchVersion;
  $("benchContent").innerHTML = `<p class="muted">Loading ${esc(mode)} results…</p>`;
  let results;
  try { results = await json(`/bench/latest?mode=${mode}`); }
  catch (_) { results = []; }
  if (state.benchVersion !== version || state.benchMode !== mode) return;
  state.bench = results;
  renderBench();
}

/* A run's clock and step list. The live screen uses its two timers and the selected
   workflow's graph; other screens pass their own element id and compile result. */
function renderTimer(mode, start, events, record, elementId = null, compiled = state.compiled) {
  const element = $(elementId || (mode === "baseline" ? "timerBaseline" : "timerCompiled"));
  const elapsed = record?.wall_ms ?? (start == null ? 0 : performance.now() - start);
  const nodes = (compiled?.graph?.[mode === "baseline" ? "source" : "compiled"]?.nodes || []);
  const seen = new Map(events.filter(e => e.node_id).map(e => [e.node_id, e]));
  const done = events.filter(e => e.type === "node_end" || e.type === "node_skip").length;
  const list = nodes.map(node => {
    const event = seen.get(node.id);
    const status = event?.type === "node_skip" ? "skipped" :
      event?.type === "node_end" ? (event.error ? "err" : event.cache_hit ? "hit" : "done") :
      event?.type === "node_wait" ? (event.reason === "quota" ? "quota wait" : "retry wait") :
      event ? "running" : "waiting";
    return `<li class="${status}"><span>${esc(node.id)}</span><span class="st">${status}</span></li>`;
  }).join("");
  element.classList.toggle("baseline", mode === "baseline");
  element.classList.toggle("compiled", mode !== "baseline");
  element.innerHTML = `<strong>${modeLabel(mode)}</strong>` +
    `<div class="clock">${esc((elapsed / 1000).toFixed(2))} s</div>` +
    `<div class="progress"><div style="width:${nodes.length ? done / nodes.length * 100 : 0}%"></div></div>` +
    `<ul>${list}</ul>`;
}

function chosenModel(id = "liveModel") {
  const [provider, model] = ($(id).value || "mock|").split("|");
  return { provider: provider || "mock", model: model || null };
}

/* What a provider choice will cost against SYNAPSE's local quota budget. */
function budgetText({ provider, model }) {
  const option = state.models?.find(row => row.provider === provider && row.model === model);
  const left = option?.remaining;
  if (provider === "groq" && option?.account_remaining) {
    const account = (label, remaining) =>
      `${label}: ${remaining?.rpd_remaining ?? "—"} requests and ` +
      `${remaining?.tpd_remaining ?? "—"} tokens today; ` +
      `${remaining?.rpm_remaining ?? "—"} requests and ` +
      `${remaining?.tpm_remaining ?? "—"} tokens this minute` +
      (remaining?.blocked ? " (provider last reported daily exhaustion)" : "");
    return `SYNAPSE local budgets for separate Groq accounts. ` +
      account("Original", option.account_remaining.original) + ". " +
      account("Compiled", option.account_remaining.compiled) +
      ". Each run still tries its selected account; other apps may use its quota.";
  }
  return provider === "mock" ? "Mock uses no model API calls." :
    left?.blocked || left?.rpd_remaining === 0 || left?.tpd_remaining === 0 ?
    `${provider} last reported or locally estimated an exhausted quota. Run will try the provider again; minute pacing still applies.` :
    `SYNAPSE local budget: ${left?.rpd_remaining ?? "—"} requests and ` +
    `${left?.tpd_remaining ?? "—"} tokens today; ${left?.rpm_remaining ?? "—"} requests and ` +
    `${left?.tpm_remaining ?? "—"} tokens this minute. Runs pause if the minute budget fills. ` +
    `Other apps may use the same provider quota.`;
}
function showPanelBudgets() {
  $("pdfBudget").textContent = budgetText(chosenModel("pdfModel"));
  $("reviewBudget").textContent = budgetText(chosenModel("reviewModel"));
}

function showModelBudget() {
  const noModel = state.compiled?.source?.nodes &&
    !state.compiled.source.nodes.some(node => node.kind === "llm");
  if (noModel) $("liveModel").value = "mock|";
  $("liveModel").disabled = Boolean(noModel);
  const { provider, model } = chosenModel();
  $("budgetStatus").textContent = noModel ?
    "This workflow has no model steps. Model choice does not apply and uses no API calls." :
    budgetText({ provider, model });
  $("dataBadge").textContent = provider === "mock" ? "Synthetic data · mock bank" :
    `${providerName(provider)} models · mock bank`;
  $("dataBadge").classList.toggle("live", provider !== "mock");
  $("costNote").textContent = provider === "mock" ?
    "Mock costs are comparison units, not dollars." :
    "Live cost is an estimate at published paid-tier token rates. Free-tier usage may incur no charge. " +
    "Elapsed time includes all waits. Time excluding local quota pacing removes only periods " +
    "when every running step was idle on the local limiter; provider retry waits remain. " +
    "Per-call wait totals can overlap.";
  const compare = provider === "mock" || $("compareLive").checked;
  $("compareLive").disabled = provider === "mock";
  $("liveRun").textContent = compare ? "Run original and compiled" : "Run compiled";
}

async function loadModels() {
  const models = await json("/models");
  state.models = Array.isArray(models) ? models : [];
  const options = state.models.map(row =>
    `<option value="${esc(row.provider)}|${esc(row.model || "")}" ` +
    `>${esc(row.label)}` +
    `${(row.account_remaining ?
      (row.account_remaining.original?.blocked && row.account_remaining.compiled?.blocked) :
      (row.remaining?.blocked || row.remaining?.rpd_remaining === 0)) ?
      " · daily quota exhausted" : ""}</option>`).join("");
  for (const id of MODEL_SELECTS) {
    const previous = $(id).value;
    $(id).innerHTML = options;
    if (state.models.some(row => `${row.provider}|${row.model || ""}` === previous))
      $(id).value = previous;
  }
  showModelBudget();
  showPanelBudgets();
}

async function liveRun() {
  $("liveRun").disabled = true;
  $("workflow").disabled = true;
  const choice = { ...chosenModel(), warm: $("warmCache").checked };
  const workflow = state.selected;
  const compare = choice.provider === "mock" || $("compareLive").checked;
  $("liveStatus").textContent = compare ?
    (choice.provider === "mock" ? "Starting both mock runs…" :
      (choice.provider === "groq" ?
        "Running original and compiled with separate Groq accounts…" :
        "Running original first, then compiled…")) : "Running compiled workflow…";
  $("liveResult").innerHTML = "";
  $("timerBaseline").innerHTML = "";
  $("timerCompiled").innerHTML = "";
  const provider = choice.provider;
  const starts = { baseline: null, compiled: null };
  const events = { baseline: [], compiled: [] }, finished = {};
  const records = {};
  const tick = setInterval(() => {
    for (const mode of compare ? ["baseline", "compiled"] : ["compiled"])
      renderTimer(mode, starts[mode], events[mode], records[mode] || finished[mode]);
  }, 100);
  try {
    const onEvent = (mode, event) => {
        if (event.type === "run_start") starts[mode] = performance.now();
        events[mode].push(event);
        if (event.type === "run_end") finished[mode] = { wall_ms: event.wall_ms };
      };
    const caseId = $("liveCase").value;
    const scale = Number($("liveScale").value);

    const runModeWithRetry = mode => withRateLimitRetry(async () => {
      starts[mode] = null;
      events[mode] = [];
      delete finished[mode];
      records[mode] = await runOne(caseId, scale, { ...choice, workflow }, mode, onEvent);
      return records[mode];
    }, { label: modeLabel(mode), statusId: "liveStatus",
         prefix: () => mode === "compiled" && records.baseline ?
           `Original run finished (${ms(records.baseline.wall_ms)}).` : "" });

    if (compare) {
      if (choice.provider === "mock" || choice.provider === "groq") {
        const results = await Promise.allSettled([
          runModeWithRetry("baseline"),
          runModeWithRetry("compiled")
        ]);
        const failed = results.find(r => r.status === "rejected");
        if (failed) throw failed.reason;
      } else {
        await runModeWithRetry("baseline");
        await runModeWithRetry("compiled");
      }
    } else {
      await runModeWithRetry("compiled");
    }
    for (const mode of ["baseline", "compiled"].filter(mode => records[mode]))
      renderTimer(mode, starts[mode], events[mode], records[mode]);
    const a = records.baseline, b = records.compiled;
    const before = a && recordUsage(a), after = recordUsage(b);
    const usageComplete = [before, after].filter(Boolean).every(u => u.usage_complete !== false);
    const unit = b.cost_unit || "mock units";
    const cachedModel = b.nodes.some(node => node.cache_hit &&
      state.compiled?.plan?.workflow?.nodes?.some(step => step.id === node.node_id && step.kind === "llm"));
    const allModelCallsCached = cachedModel && after.calls === 0 &&
      after.tokens_total === 0 && after.usage_complete !== false;
    const beforeActive = a && Math.max(0, a.wall_ms - (before.quota_idle_ms || 0));
    const afterActive = Math.max(0, b.wall_ms - (after.quota_idle_ms || 0));
    $("liveStatus").textContent = b.provider === "mock" ?
      `Finished ${b.case_id} offline with synthetic bank data.` :
      `Finished ${b.case_id} with ${providerName(b.provider)} model calls and synthetic bank data.`;
    if (b.provider === "groq") $("liveStatus").textContent += compare ?
      " Original and compiled used separate Groq accounts." :
      " Compiled used its Groq account.";
    const waited = [before, after].filter(Boolean).some(u =>
      (u.quota_wait_ms || 0) + (u.retry_wait_ms || 0) > 100);
    const decision = a?.key_field && b.key_field ?
      (a.key_value === b.key_value ? "Decision matches" : "Decision differs") :
      "See outputs and validation for correctness";
    const timing = compare ?
      metric("Original elapsed time", ms(a.wall_ms), a.key_value) +
      metric("Optimized elapsed time", ms(b.wall_ms), b.key_value, savingClass(a.wall_ms, b.wall_ms)) +
      metric("Original time excluding local quota pacing", ms(beforeActive),
        `Excluded ${ms(before.quota_idle_ms || 0)} of local quota idle`) +
      metric("Optimized time excluding local quota pacing", ms(afterActive),
        `Excluded ${ms(after.quota_idle_ms || 0)} of local quota idle`,
        savingClass(beforeActive, afterActive)) +
      metric("Time excluding local quota pacing ratio", timeRatio(beforeActive, afterActive),
        decision + (cachedModel ? " · warm cache" : ""), savingClass(beforeActive, afterActive)) :
      metric("Optimized elapsed time", ms(b.wall_ms), b.key_value) +
      metric("Optimized time excluding local quota pacing", ms(afterActive),
        `Excluded ${ms(after.quota_idle_ms || 0)} of local quota idle`);
    const usage = compare ? [
      metric(usageComplete ? "Original tokens" : "Reported original tokens",
        tokens(before.tokens_total),
        `${tokens(before.tokens_in)} in · ${tokens(before.tokens_out)} out`),
      metric(usageComplete ? (cachedModel ? "New model tokens · cache in use" : "Optimized tokens") :
        "Reported optimized tokens",
        tokens(after.tokens_total), allModelCallsCached ?
        "0 new tokens because earlier model answers were reused" :
        `${tokens(after.tokens_in)} in · ${tokens(after.tokens_out)} out`),
      cachedModel ? metric("Cache reuse", "Model answer reused",
        "Measured savings include cache reuse; run cold to isolate compiler changes") : "",
      (usageComplete ? metric(deltaLabel(before.tokens_total, after.tokens_total, "Total token"),
        change(before.tokens_total, after.tokens_total, tokens),
        cachedModel ? "Includes cache reuse and output variation" : "Includes output variation",
        savingClass(before.tokens_total, after.tokens_total)) :
        metric("Total token change", "Unavailable", "Provider usage is incomplete")),
      (usageComplete ? metric(deltaLabel(before.tokens_in, after.tokens_in, "Input token"),
        change(before.tokens_in, after.tokens_in, tokens),
        cachedModel ? "Includes cache reuse" : "Prompt and schema usage",
        savingClass(before.tokens_in, after.tokens_in)) : ""),
      metric(usageComplete ? "Original cost" : "Reported original cost", cost(before.cost, unit)),
      metric(usageComplete ? "Optimized cost" : "Reported optimized cost", cost(after.cost, unit)),
      (usageComplete ? metric(deltaLabel(before.cost, after.cost, "Cost"),
        change(before.cost, after.cost, value => cost(value, unit)),
        cachedModel ? "Measured difference includes cache reuse" : "",
        savingClass(before.cost, after.cost)) :
        metric("Cost change", "Unavailable", "Provider usage is incomplete"))
    ].join("") :
      metric(usageComplete ? (cachedModel ? "New model tokens · cache in use" : "Optimized tokens") :
        "Reported optimized tokens",
        tokens(after.tokens_total), allModelCallsCached ?
        "0 new tokens because earlier model answers were reused" :
        `${tokens(after.tokens_in)} in · ${tokens(after.tokens_out)} out`) +
      metric(usageComplete ? "Optimized cost" : "Reported optimized cost",
        cost(after.cost, unit), "Compare both to measure original cost");
    const waits = Object.entries(records).map(([mode, record]) => {
      const u = recordUsage(record), label = mode === "baseline" ? "Original" : "Optimized";
      return metric(`${label} quota wait`, ms(u.quota_wait_ms || 0), "Sum across model calls") +
        metric(`${label} model time`, ms(u.provider_ms || 0),
          `${u.calls ?? "—"} API calls · retry wait ${ms(u.retry_wait_ms || 0)}`);
    }).join("");
    const cacheInfo = b.cache_metrics ?
      metric("Cache hits", b.cache_metrics.hits,
        `${b.cache_metrics.misses} misses · ${num(b.cache_metrics.hit_rate * 100, 1)}% hit rate`) +
      metric("Cache entries", `${b.cache_metrics.entries}/${b.cache_metrics.capacity}`,
        `${b.cache_metrics.evictions} capacity evictions`) : "";
    $("liveResult").innerHTML = metric("Optimized cache", b.cold_cache ? "Cold" : "Warm",
      "Warm savings apply to repeated identical inputs") + cacheInfo + timing + usage +
      (provider !== "mock" ? waits : "");
    if (choice.warm) $("liveStatus").textContent += b.cold_cache ?
      " Cache started empty; repeat this exact case to reuse results. Writes still execute." :
      ` Reused ${b.nodes.filter(n => n.cache_hit).length} exact results; writes still executed.`;
    if (waited) $("liveStatus").textContent +=
      " Local quota idle was excluded from the adjusted time comparison above; provider retry waits remain.";
    if ([before, after].filter(Boolean).some(u => u.usage_complete === false))
      $("liveStatus").textContent += " Some model usage was not reported; cost is incomplete.";
    $("liveGantt").innerHTML = gantt(records) + usageTable(records);
  } catch (exc) {
    error("liveGantt", exc);
    const existingRecords = { ...records, ...(exc.records || {}) };
    if (Object.keys(existingRecords).length) {
      $("liveResult").innerHTML = Object.entries(existingRecords).map(([mode, record]) => {
        const u = recordUsage(record);
        renderTimer(mode, starts[mode], events[mode], record);
        return metric(`${mode} reported tokens`, tokens(u.tokens_total),
          record.status === "failed" ? "Partial run; no savings comparison" : "Completed run") +
          metric(`${mode} reported cost`, cost(u.cost, record.cost_unit),
            u.usage_complete === false ? "Provider did not report all usage" : "Includes failed structured replies");
      }).join("");
      $("liveGantt").innerHTML += usageTable(existingRecords);
    }
    $("liveStatus").textContent = isDailyQuotaError(exc) ?
      `${providerName(provider)} daily model quota exhausted. Choose another model or select Mock.` :
      provider === "mock" ? "Run failed on the mock backends. See the error below." :
      `Run failed on ${providerName(provider)}. You can try this model again or select another model.`;
  }
  finally {
    clearInterval(tick); $("liveRun").disabled = false;
    $("workflow").disabled = false;
    await loadModels().catch(() => {});
  }
}

function usageTable(records) {
  const rows = Object.entries(records).flatMap(([mode, record]) => (record.nodes || [])
    .filter(node => node.usage.model || node.cache_hit).map(node => {
      const u = node.usage;
      return `<tr><td>${esc(mode)}</td><td>${esc(node.node_id)}</td>` +
        `<td>${esc(u.model || (node.cache_hit ? "cached" : "—"))}</td>` +
        `<td>${tokens(u.tokens_in)} / ${tokens(u.tokens_out)}</td>` +
        `<td>${esc(cost(u.cost, record.cost_unit))}</td>` +
        `<td>${ms(u.quota_wait_ms || 0)}</td><td>${ms(u.provider_ms || 0)}</td></tr>`;
    })).join("");
  return `<div class="scroll"><table><thead><tr><th>Run</th><th>Step</th><th>Model</th>` +
    `<th>Tokens in / out</th><th>Cost</th><th>Quota wait</th><th>Model time</th>` +
    `</tr></thead><tbody>${rows}</tbody></table></div>`;
}

/* The compile result for a workflow other screens do not have selected, for step lists and
   bar colours. Kept for the session; a failed compile is retried on the next run. */
function compiledFor(name) {
  const file = workflowNamed(name)?.file || name;
  if (state.compiled && [state.compiled.workflow, state.compiled.name].includes(file))
    return Promise.resolve(state.compiled);
  if (!state.compiledFiles[file]) {
    state.compiledFiles[file] = post("/compile", { workflow: file }).catch(() => {
      delete state.compiledFiles[file];
      return null;
    });
  }
  return state.compiledFiles[file];
}

/* PDF application intake. The server returns extraction metadata only, never the text. */
const CUSTOMER_IDS = Array.from({ length: 20 }, (_, i) => `CUST-A${String(i + 1).padStart(2, "0")}`);
const UPLOAD_ERRORS = {
  413: ["The PDF is too large", "Upload a smaller file or one with fewer pages."],
  422: ["The server could not use this upload",
    "Check that the file is a readable, unencrypted PDF and that a customer id is filled in."],
  503: ["OCR is not available on this server",
    "Upload a PDF that has a text layer, or install Tesseract on the server (make setup)."]
};
const METHODS = { text: "Text layer", ocr: "OCR", mixed: "Text layer + OCR" };
const fileSize = bytes => bytes < 1024 ? `${bytes} B` : bytes < 1048576 ?
  `${num(bytes / 1024, 1)} KB` : `${num(bytes / 1048576, 1)} MB`;
const plural = (count, word) => `${count} ${word}${count === 1 ? "" : "s"}`;

async function uploadPdf(file, customerId, mode, scale, choice) {
  const params = new URLSearchParams({ mode, scale: String(scale), provider: choice.provider });
  if (choice.model) params.set("model", choice.model);
  let response;
  try {  // the customer id goes in a header so it never appears in URLs or access logs
    response = await fetch(`/applications/pdf?${params}`, { method: "POST", body: file,
      headers: { "Content-Type": "application/pdf", "X-Customer-Id": customerId } });
  } catch (exc) {
    const failure = new Error(`Could not reach the server: ${exc.message || exc}`);
    failure.upload = true; failure.noRetry = true;
    throw failure;
  }
  if (!response.ok) {
    const failure = await httpError(response);
    failure.upload = true; failure.noRetry = true;  // an upload problem is not a rate limit
    throw failure;
  }
  return response.json();
}

function uploadErrorHtml(exc) {
  const [title, hint] = UPLOAD_ERRORS[exc.status] || ["Upload failed", ""];
  return `<div class="notice error" role="alert"><strong>${esc(title)}` +
    `${exc.status ? ` · HTTP ${esc(exc.status)}` : ""}</strong>` +
    `<p class="detail">${esc(exc.message)}</p>` +
    (hint ? `<p class="muted">${esc(hint)}</p>` : "") + `</div>`;
}

function reviewItems(doc) {
  const items = [...(Array.isArray(doc.review_flags) ? doc.review_flags : [])];
  const low = Array.isArray(doc.low_text_pages) ? doc.low_text_pages : [];
  if (low.length) items.push(`${low.length === 1 ? "Page" : "Pages"} ${low.join(", ")} still ` +
    "had little or no text after extraction; check them against the document.");
  return items;
}

function documentHtml(doc) {
  const items = reviewItems(doc);
  const ocr = Array.isArray(doc.ocr_pages) ? doc.ocr_pages : [];
  const review = items.length ? `<div class="review-flags" role="alert">` +
    `<strong>Needs human review</strong><ul>${items.map(item =>
      `<li>${esc(item)}</li>`).join("")}</ul></div>` : "";
  return review + `<div class="metrics">` +
    metric("Extraction", METHODS[doc.method] || doc.method || "—",
      doc.from_cache ? "Reused from the content-hash cache" : "Extracted for this upload") +
    metric("Pages", doc.pages ?? "—", ocr.length ?
      `${plural(ocr.length, "page")} read by OCR: ${ocr.join(", ")}` : "No OCR needed") +
    metric("Extraction time", ms(doc.elapsed_ms), doc.from_cache ? "From cache" :
      doc.method === "text" ? "Text layer only" :
      doc.method === "ocr" ? "OCR only" : "Text layer and OCR") +
    metric("Text read", doc.chars == null ? "—" : `${doc.chars} chars`,
      doc.sha256 ? `sha256 ${String(doc.sha256).slice(0, 12)}…` : "") +
    `</div>`;
}

function pdfResultHtml(record, doc) {
  const u = recordUsage(record);
  const flagged = reviewItems(doc).length > 0;
  return metric("Decision", record.key_value ?? "—", flagged ?
    "Provisional: the extraction needs human review" : record.key_field || "",
    flagged ? "bad" : "") +
    metric(`${modeLabel(record.mode)} elapsed time`, ms(record.wall_ms), record.case_id || "") +
    metric("Tokens", tokens(u.tokens_total), `${tokens(u.tokens_in)} in · ${tokens(u.tokens_out)} out`) +
    metric("Cost", cost(u.cost, record.cost_unit), record.provider === "mock" ?
      "Mock units, not dollars" : `${providerName(record.provider)} estimate`);
}

async function pdfRun(event) {
  event?.preventDefault();
  const file = $("pdfFile").files?.[0];
  const customerId = $("pdfCustomer").value.trim();
  const problem = !file ? "Choose a PDF file first." :
    !customerId ? "Enter a customer id, for example CUST-A01." :
    !/^[\x21-\x7E]{1,64}$/.test(customerId) ?
      "The customer id must be 1 to 64 visible ASCII characters with no spaces." : "";
  if (problem) {
    $("pdfStatus").textContent = problem;
    return;
  }
  const mode = $("pdfMode").value, scale = Number($("pdfScale").value);
  const choice = chosenModel("pdfModel");
  $("pdfRun").disabled = true;
  $("pdfDocument").innerHTML = "";
  $("pdfResult").innerHTML = "";
  $("pdfTimer").innerHTML = "";
  $("pdfGantt").innerHTML = `<p class="muted">Waiting for the upload…</p>`;
  $("pdfStatus").textContent = `Uploading ${file.name} (${fileSize(file.size)}) and extracting its text…`;
  let start = null, events = [], doc = null, compiled = null;
  const compiling = compiledFor(LOAN_WORKFLOW).then(result => { compiled = result; return result; });
  const tick = setInterval(() => {
    if (start != null) renderTimer(mode, start, events, null, "pdfTimer", compiled);
  }, 100);
  try {
    const record = await withRateLimitRetry(async () => {
      start = null; events = [];
      const started = await uploadPdf(file, customerId, mode, scale, choice);
      doc = started.document || {};
      $("pdfDocument").innerHTML = documentHtml(doc);
      $("pdfStatus").textContent =
        `Text extracted. Running the ${modeLabel(mode).toLowerCase()} loan pre-screen…`;
      start = performance.now();
      return followRun(started.run.run_id, mode, (_, e) => { events.push(e); });
    }, { label: modeLabel(mode), statusId: "pdfStatus" });
    clearInterval(tick);
    await compiling;
    renderTimer(mode, start, events, record, "pdfTimer", compiled);
    $("pdfResult").innerHTML = pdfResultHtml(record, doc);
    $("pdfGantt").innerHTML = gantt({ [mode]: record }, compiled) +
      (record.provider !== "mock" ? usageTable({ [mode]: record }) : "");
    $("pdfStatus").textContent = `Finished: ${record.key_field || "decision"} = ` +
      `${record.key_value ?? "—"}.` + (reviewItems(doc).length ?
        " A person must check the flagged extraction before relying on this decision." : "");
  } catch (exc) {
    clearInterval(tick);
    if (exc.upload) {
      $("pdfDocument").innerHTML = uploadErrorHtml(exc);
      $("pdfGantt").innerHTML = `<p class="muted">No run was started.</p>`;
      $("pdfStatus").textContent = "The upload was rejected; nothing ran.";
    } else {
      error("pdfGantt", exc);
      if (exc.record) {
        renderTimer(mode, start, events, exc.record, "pdfTimer", compiled);
        $("pdfGantt").innerHTML += gantt({ [mode]: exc.record }, compiled);
      }
      $("pdfStatus").textContent = isDailyQuotaError(exc) ?
        `${providerName(choice.provider)} daily model quota exhausted. Choose another model or select Mock.` :
        "The run failed after the text was extracted. See the error below.";
    }
  } finally {
    $("pdfRun").disabled = false;
    loadModels().catch(() => {});
  }
}

/* Review sentiment: its own workflow, run on one synthetic review from its test suite. */
function reviewOutputs(record) {
  const outputs = Object.assign({}, ...(record?.nodes || []).map(node => node.output || {}));
  const sentiment = outputs.sentiment && typeof outputs.sentiment === "object" ? outputs.sentiment : {};
  let aspects = outputs.aspects;
  if (aspects && !Array.isArray(aspects)) aspects = aspects.aspects;  // {aspects: [...]} schema
  return { sentiment, aspects: Array.isArray(aspects) ? aspects : [] };
}

function sentimentHtml(record) {
  const { sentiment, aspects } = reviewOutputs(record);
  const value = sentiment.sentiment;
  const klass = SENTIMENTS.includes(value) ? value : "unknown";
  const raw = Number(sentiment.confidence);
  const confidence = sentiment.confidence != null && Number.isFinite(raw) ?
    Math.min(1, Math.max(0, raw)) : null;
  const expected = record.expected;
  const verdict = expected == null ? "" : expected === value ?
    `<span class="pill pass">matches expected ${esc(expected)}</span>` :
    `<span class="pill fail">expected ${esc(expected)}</span>`;
  const bar = confidence == null ? `<p class="muted">No confidence reported.</p>` :
    `<div class="confidence"><div class="confidence-head"><span>Confidence</span>` +
    `<strong>${esc(num(confidence, 2))}</strong></div>` +
    `<div class="meter" role="meter" aria-label="Confidence" aria-valuemin="0" aria-valuemax="1" ` +
    `aria-valuenow="${esc(confidence)}"><div style="width:${confidence * 100}%"></div></div></div>`;
  const list = aspects.length ? `<ul class="aspects">${aspects.map(item => {
    const tone = SENTIMENTS.includes(item?.sentiment) ? item.sentiment : "unknown";
    return `<li><span>${esc(String(item?.aspect ?? "—").replace(/_/g, " "))}</span>` +
      `<span class="pill ${tone}">${esc(item?.sentiment ?? "—")}</span></li>`;
  }).join("")}</ul>` : `<p class="muted">No aspects reported.</p>`;
  const u = recordUsage(record);
  return `<div class="grid-even"><div class="card sentiment-card"><h3>Sentiment · ${esc(record.case_id)}</h3>` +
    `<div class="sentiment-line"><span class="sentiment-badge ${klass}">${esc(value ?? "none")}</span>` +
    `${verdict}</div>${bar}<p class="explanation">${esc(sentiment.explanation || "No explanation given.")}</p>` +
    `</div><div class="card"><h3>Aspects</h3>${list}</div></div>` +
    `<div class="metrics">` +
    metric(`${modeLabel(record.mode)} elapsed time`, ms(record.wall_ms)) +
    metric("Tokens", tokens(u.tokens_total), `${tokens(u.tokens_in)} in · ${tokens(u.tokens_out)} out`) +
    metric("Cost", cost(u.cost, record.cost_unit), record.provider === "mock" ?
      "Mock units, not dollars" : `${providerName(record.provider)} estimate`) + `</div>`;
}

function setupPanels() {
  const loan = workflowNamed(LOAN_WORKFLOW), review = workflowNamed(REVIEW_WORKFLOW);
  $("pdfRun").disabled = !loan;
  if (!loan) $("pdfStatus").textContent = "The loan_prescreen workflow is not available on this server.";
  const cases = review?.cases || [];
  $("reviewCase").innerHTML = cases.map(c => `<option value="${esc(c)}">${esc(c)}</option>`).join("");
  $("reviewRun").disabled = !cases.length;
  if (!cases.length) $("reviewStatus").textContent =
    "The review_sentiment workflow or its cases are not available on this server.";
}

async function reviewRun() {
  const review = workflowNamed(REVIEW_WORKFLOW);
  if (!review) return;
  const caseId = $("reviewCase").value, mode = $("reviewMode").value;
  const scale = Number($("reviewScale").value);
  const choice = { ...chosenModel("reviewModel"), workflow: review.file };
  $("reviewRun").disabled = true;
  $("reviewResult").innerHTML = "";
  $("reviewTimer").innerHTML = "";
  $("reviewStatus").textContent = `Running ${caseId} (${modeLabel(mode).toLowerCase()})…`;
  let start = null, events = [], compiled = null;
  const compiling = compiledFor(REVIEW_WORKFLOW).then(result => { compiled = result; return result; });
  const tick = setInterval(() => {
    if (start != null) renderTimer(mode, start, events, null, "reviewTimer", compiled);
  }, 100);
  try {
    const record = await withRateLimitRetry(() => {
      start = null; events = [];
      return runOne(caseId, scale, choice, mode, (_, e) => {
        if (e.type === "run_start") start = performance.now();
        events.push(e);
      });
    }, { label: modeLabel(mode), statusId: "reviewStatus" });
    clearInterval(tick);
    await compiling;
    renderTimer(mode, start, events, record, "reviewTimer", compiled);
    $("reviewResult").innerHTML = sentimentHtml(record);
    $("reviewStatus").textContent = `Finished ${record.case_id} ` +
      (record.provider === "mock" ? "offline with mock model replies." :
        `with ${providerName(record.provider)} model calls.`);
  } catch (exc) {
    clearInterval(tick);
    error("reviewResult", exc);
    if (exc.record) renderTimer(mode, start, events, exc.record, "reviewTimer", compiled);
    $("reviewStatus").textContent = isDailyQuotaError(exc) ?
      `${providerName(choice.provider)} daily model quota exhausted. Choose another model or select Mock.` :
      "The review run failed. See the error below.";
  } finally {
    $("reviewRun").disabled = false;
    loadModels().catch(() => {});
  }
}

async function loadWorkflow() {
  const version = ++state.workflowVersion;
  state.selected = $("workflow").value;
  state.pair = null; state.validation = null; state.compiled = null;
  $("timelineGantt").innerHTML = '<p class="muted">Press Run both to measure this case.</p>';
  $("timelineLegend").innerHTML = "";
  $("timelineStatus").textContent = "";
  $("validationStatus").textContent = "Not validated in this session yet.";
  $("validationContent").innerHTML = "";
  $("timerBaseline").innerHTML = "";
  $("timerCompiled").innerHTML = "";
  $("liveResult").innerHTML = "";
  $("liveStatus").textContent = "Choose a model, then run one synthetic case.";
  $("liveGantt").innerHTML = '<p class="muted">Press run to start.</p>';
  const chosen = state.workflows.find(w => w.file === state.selected);
  $("unsafe").checked = false;
  $("unsafe").disabled = chosen?.name !== "loan_prescreen";
  $("unsafeLabel").title = $("unsafe").disabled ? "The unsafe demo pass is only defined for the loan workflow" : "";
  selectCases();
  $("graphOriginal").innerHTML = `<p class="muted">Compiling…</p>`;
  const selected = state.selected;
  try {
    const compiled = await post("/compile", { workflow: selected });
    if (state.workflowVersion !== version || state.selected !== selected) return;
    state.compiled = compiled;
    renderGraph(); renderDecisions(); showModelBudget();
  } catch (exc) {
    if (state.workflowVersion !== version || state.selected !== selected) return;
    error("graphOriginal", exc);
  }
  if (state.workflowVersion !== version) return;
  await loadBench();
}

function setupControls() {
  document.querySelectorAll("[data-screen]").forEach(button => button.addEventListener("click", () => {
    document.querySelectorAll("[data-screen]").forEach(tab =>
      tab.setAttribute("aria-selected", tab === button ? "true" : "false"));
    document.querySelectorAll(".screen").forEach(screen =>
      screen.classList.toggle("active", screen.id === button.dataset.screen));
  }));
  document.querySelectorAll("[data-bench-mode]").forEach(button => button.addEventListener("click", () => {
    state.benchMode = button.dataset.benchMode;
    document.querySelectorAll("[data-bench-mode]").forEach(b =>
      b.setAttribute("aria-pressed", b === button ? "true" : "false"));
    loadBench();
  }));
  const themes = ["auto", "light", "dark"];
  let theme = "auto";
  try { theme = themes.includes(localStorage.getItem("synapse-theme")) ?
    localStorage.getItem("synapse-theme") : "auto"; } catch (_) {}
  const applyTheme = () => {
    document.documentElement.dataset.theme = theme === "auto" ? "" : theme;
    $("theme").textContent = `Theme: ${theme}`;
    try { localStorage.setItem("synapse-theme", theme); } catch (_) {}
  };
  applyTheme();
  $("theme").addEventListener("click", () => { theme = themes[(themes.indexOf(theme) + 1) % themes.length]; applyTheme(); });
  $("workflow").addEventListener("change", loadWorkflow);
  $("timelineRun").addEventListener("click", timelineRun);
  $("validateRun").addEventListener("click", validateRun);
  $("liveRun").addEventListener("click", liveRun);
  $("liveModel").addEventListener("change", showModelBudget);
  $("compareLive").addEventListener("change", showModelBudget);
  $("pdfForm").addEventListener("submit", pdfRun);
  $("reviewRun").addEventListener("click", reviewRun);
  for (const id of ["pdfModel", "reviewModel"]) $(id).addEventListener("change", showPanelBudgets);
  $("pdfCustomers").innerHTML = CUSTOMER_IDS.map(id => `<option value="${esc(id)}"></option>`).join("");
  fillScales(["pdfScale", "reviewScale"]);
}

async function init() {
  setupControls();
  try {
    state.workflows = (await json("/workflows")).filter(w => !w.error);
    await loadModels();
    $("workflow").innerHTML = state.workflows.map(w =>
      `<option value="${esc(w.file)}">${esc(w.name)}</option>`).join("");
    if (!state.workflows.length) throw new Error("No runnable workflows were found.");
    setupPanels();
    await loadWorkflow();
  } catch (exc) { error("graphOriginal", exc); }
}

init();
