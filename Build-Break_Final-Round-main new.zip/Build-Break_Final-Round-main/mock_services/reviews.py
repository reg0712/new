"""Review sentiment test data: 18 synthetic customer reviews of a fictional bank branch, each
with a hand-assigned sentiment, and one deterministic stand-in for each LLM prompt of the
review workflow. Synthetic data only: written for these tests, never copied from real reviews.

The stand-ins share a small lexicon scorer: each clause of a review scores +1 per positive
word or emoji and -1 per negative one, a negation in the three words before a word (not an
emoji) flips it, and a few fixed phrases count as negative. Good enough to label the test set;
not a sentiment model."""

from __future__ import annotations

import json
import re
from typing import Any

from synapse import ROOT

REVIEWS_FILE = ROOT / "mock_services" / "data" / "reviews.json"
SENTIMENTS = ("positive", "neutral", "negative")
EXPLANATION_CHARS = 240  # prompts/review_sentiment.json maxLength

_POSITIVE = {"friendly", "helpful", "quick", "quickly", "polite", "patient", "thank", "thanks",
             "smooth", "easy", "recommend", "excellent", "great", "fixed",
             "excelente", "amable", "rápido", "👍", "😊"}
_NEGATIVE = {"waited", "long", "slow", "rude", "ignored", "worst", "nobody", "crashing",
             "useless", "blocked", "problem", "😡", "👎"}
_NEGATIVE_PHRASES = ("out of cash", "hidden charges", "too high")
_NEGATIONS = {"not", "no", "never"}
_SARCASM = re.compile(r"\b(oh|wow),? (great|wonderful|fantastic|brilliant)\b|"
                      r"\bjust what i (needed|wanted)\b|\bthanks for nothing\b|"
                      r"\blove (waiting|standing|queuing)\b", re.IGNORECASE)
_CLAUSES = re.compile(r"[.!?;]+|,?\s+but\s+", re.IGNORECASE)
_TOKENS = re.compile(r"[\w']+|[^\w\s]")

# Keywords that tie a clause to an aspect of prompts/review_aspects.json.
_ASPECTS = {
    "staff": re.compile(r"\b(staff|teller|cashier|manager|employees?|personal)\b", re.IGNORECASE),
    "wait_time": re.compile(r"\b(wait|waited|waiting|queues?|minutes|hours)\b", re.IGNORECASE),
    "fees": re.compile(r"\b(fees?|charges?|charged)\b", re.IGNORECASE),
    "digital_banking": re.compile(r"\b(app|net ?banking|upi|website)\b", re.IGNORECASE),
    "atm": re.compile(r"\batms?\b", re.IGNORECASE),
    "branch": re.compile(r"\b(branch|sucursal|premises|parking|seating)\b", re.IGNORECASE),
}
_ASPECT_NAMES = {"staff": "staff", "wait_time": "waiting time", "fees": "fees",
                 "digital_banking": "digital banking", "atm": "the ATM",
                 "branch": "the branch", "other": "the service"}


def load_reviews() -> list[dict[str, Any]]:
    """The 18 synthetic reviews, R01 to R18."""
    return json.loads(REVIEWS_FILE.read_text())


def review(case_id: str) -> dict[str, Any]:
    """One review by case id."""
    found = next((r for r in load_reviews() if r["case_id"] == case_id), None)
    if found is None:
        raise LookupError(f"no synthetic review {case_id!r}")
    return found


def cases() -> list[dict[str, Any]]:
    """One test case per review: the review workflow's inputs plus a case_id."""
    return [{"case_id": r["case_id"], "review_text": r["review_text"],
             "star_rating": r["star_rating"]} for r in load_reviews()]


def expected_sentiment(case_id: str) -> str:
    """The sentiment the review was labelled with."""
    return review(case_id)["expected_sentiment"]


def clause_score(clause: str) -> int:
    """Lexicon score of one clause: +1 per positive word or emoji, -1 per negative one or
    negative phrase, with a negation in the three words before a word flipping it."""
    tokens = _TOKENS.findall(clause.lower())
    score = -sum(clause.lower().count(phrase) for phrase in _NEGATIVE_PHRASES)
    for i, token in enumerate(tokens):
        polarity = (token in _POSITIVE) - (token in _NEGATIVE)
        if polarity and token.isalpha() and _NEGATIONS & set(tokens[max(0, i - 3):i]):
            polarity = -polarity
        score += polarity
    return score


def clauses(text: str) -> list[str]:
    """A review split into clauses at sentence ends and at 'but'."""
    return [part.strip() for part in _CLAUSES.split(text) if part.strip()]


def _label(score: float) -> str:
    """positive, neutral or negative by the sign of a score."""
    return "positive" if score > 0 else "negative" if score < 0 else "neutral"


# Deterministic stand-ins for the workflow's LLM prompts, keyed by prompt file name.

def extract_review_aspects(inputs: dict[str, Any]) -> dict[str, Any]:
    """prompts/extract_review_aspects.txt: each aspect a clause mentions, scored by the summed
    scores of its clauses. An opinionated clause that names no aspect counts as 'other'."""
    totals: dict[str, int] = {}
    for clause in clauses(inputs["review_text"]):
        score = clause_score(clause)
        named = [aspect for aspect, rule in _ASPECTS.items() if rule.search(clause)]
        for aspect in named or (["other"] if score else []):
            totals[aspect] = totals.get(aspect, 0) + score
    return {"aspects": [{"aspect": aspect, "sentiment": _label(score)}
                        for aspect, score in totals.items()]}


def judge_review_tone(inputs: dict[str, Any]) -> dict[str, Any]:
    """prompts/judge_review_tone.txt: polarity from the summed clause scores, intensity from
    their size, and sarcastic praise read as negative."""
    text = inputs["review_text"]
    score = sum(clause_score(clause) for clause in clauses(text))
    if _SARCASM.search(text):
        return {"polarity": "negative", "sarcastic": True, "intensity": 0.6}
    return {"polarity": _label(score), "sarcastic": False,
            "intensity": round(min(1.0, abs(score) / 4), 2)}


def score_review_sentiment(inputs: dict[str, Any]) -> dict[str, Any]:
    """prompts/score_review_sentiment.txt: the tone's polarity, except that a mild review
    praising some aspects and criticising others is neutral; confidence drops for mixed,
    sarcastic or rating-contradicted reviews."""
    tone = inputs["tone"]
    liked = [a["aspect"] for a in inputs["aspects"]["aspects"] if a["sentiment"] == "positive"]
    disliked = [a["aspect"] for a in inputs["aspects"]["aspects"] if a["sentiment"] == "negative"]
    mixed = bool(liked and disliked)
    if tone["sarcastic"]:
        sentiment, confidence = "negative", 0.7
        named = [a["aspect"] for a in inputs["aspects"]["aspects"]] or ["other"]
        explanation = (f"Negative: the praise is sarcastic; the reviewer is unhappy with "
                       f"{_names(named)}.")
    elif mixed and tone["intensity"] < 0.5:
        sentiment, confidence = "neutral", 0.6
        explanation = f"Neutral: mixed review that praises {_names(liked)} but criticises " \
                      f"{_names(disliked)}."
    elif tone["polarity"] == "neutral":
        sentiment, confidence = "neutral", 0.75
        explanation = "Neutral: a factual or noncommittal review with no clear opinion."
    else:
        sentiment = tone["polarity"]
        confidence = 0.55 + 0.4 * tone["intensity"] - (0.1 if mixed else 0.0)
        explanation = _polar_explanation(sentiment, liked, disliked)
    rating = inputs.get("star_rating")
    if rating is not None and ((sentiment == "positive" and rating <= 2) or
                               (sentiment == "negative" and rating >= 4)):
        confidence -= 0.2
        explanation += f" The {rating}-star rating disagrees with the text."
    return {"sentiment": sentiment, "confidence": round(min(1.0, max(0.0, confidence)), 2),
            "explanation": explanation[:EXPLANATION_CHARS]}


def _polar_explanation(sentiment: str, liked: list[str], disliked: list[str]) -> str:
    """'Positive: praises staff despite a complaint about fees.' and the like."""
    main, other = (liked, disliked) if sentiment == "positive" else (disliked, liked)
    verb, overall = (("praises", "happy") if sentiment == "positive"
                     else ("criticises", "unhappy"))
    text = f"{sentiment.title()}: {verb} {_names(main)}" if main else \
        f"{sentiment.title()}: the reviewer is {overall} overall"
    if other:
        text += f" despite {'a complaint about' if sentiment == 'positive' else 'praising'} " \
                f"{_names(other)}"
    return text + "."


def _names(aspects: list[str]) -> str:
    """Aspects as prose: 'staff', 'staff and fees', 'staff, fees and the ATM'."""
    names = [_ASPECT_NAMES[aspect] for aspect in aspects]
    return names[0] if len(names) == 1 else f"{', '.join(names[:-1])} and {names[-1]}"


MOCK_TASKS = {
    "extract_review_aspects": extract_review_aspects,
    "judge_review_tone": judge_review_tone,
    "score_review_sentiment": score_review_sentiment,
}
