# `venky-feature` optimization audit

Reviewed `origin/venky-feature` at `b45b3fe` against `main` after `35c1254`.
The branches diverged at `135ddf9`. The feature branch predates the current
conditional gates, optional inputs, PDF intake, review workflow and dashboard.
Its reported test result covers that older tree, so its files cannot be merged
as a group.

| Feature branch change | Current decision | Reason and evidence |
| --- | --- | --- |
| Prioritize ready nodes by remaining measured critical path | Integrated | `synapse/graph.py` computes downstream criticality; `synapse/compiler.py` carries measured p50 latencies in the plan; `synapse/optimiser.py` passes the profile; `synapse/executor.py` schedules ready nodes with file order as the tie breaker. Dependencies, gate decisions and write barriers remain in force. |
| Separate model, tool and retrieval concurrency limits | Integrated | `config/models.yaml` and `synapse/backends/__init__.py` define the caps; the compiled executor applies one semaphore per kind. A test verifies a tool and a retrieval can overlap while each kind respects its own cap. |
| Bounded LRU exact cache | Integrated | `synapse/passes/memoise.py` limits entries and evicts the least recently used key. TTLs, entity-specific write invalidation, gate exclusion and defensive copies remain. |
| Cache hit, miss and eviction metrics | Integrated | The cache exposes metrics; the API returns per-run deltas and the Live Run dashboard shows hits, misses, hit rate, occupancy and evictions. |
| Single-flight duplicate suppression | Deferred | The feature branch gives every waiter the producer's `Usage`, which would count one provider call and its cost more than once. It also needs a write-invalidation generation check before an in-flight read can fill a cache after a write. The current API serializes requests sharing one warm cache. |
| Fail-fast cancellation of active reads and models | Deferred | A cancelled provider request may still be billed, while its usage and quota reservation can be lost. Stopping new work after a failure is already implemented; active work needs a cancellation and accounting contract before changing it. |
| Node and workflow timeouts | Deferred | The feature branch uses `asyncio.wait_for` on write nodes, which can cancel an external side effect. Its workflow deadline can discard a completed write's run record. A safe implementation must let started writes settle and retain their records, including on timeout, so retry decisions remain correct. |
| Persisted compiled-plan cache | Deferred | The feature branch's cache key includes workflow and prompt/schema content, but not the measured profile, benchmark history or current routing proof. Reusing such a plan can freeze adaptive choices and preserve a routed model after its proof is revoked. A future key needs those inputs, plus invalidation tests. |

The main branch also now runs original and compiled Groq comparisons on distinct
accounts, pins GPT-OSS 20B for live checks with `--model openai/gpt-oss-20b`,
and accounts for each account's local quota separately. The compiler's cold
token savings come from safe rewrites such as lossless input compaction; running
independent steps in parallel primarily affects time. Generated output length
and provider load can make a single live comparison cost more or run slower.
