"""Dependency graph (NetworkX) for a workflow.

Data edges run from the one node that produces an input to each node that reads it; order
edges keep write nodes in file order; control edges run from a gate to each node its branches
list, so a branch node never starts before its gate has chosen. Also here: topological order,
parallel levels, the latency-weighted critical path, and the branch helpers passes need to stay
safe around gates (branch_of, run_conditions, gates).

Skip rule (the executor applies it): a node is skipped when a gate that lists it chose another
branch or was itself skipped, or when it reads, other than through optional_inputs, the output
of a skipped node. Order and control edges from a skipped node count as satisfied.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping

import networkx as nx

from synapse.ir import Effect, NodeKind, Workflow


class GraphError(ValueError):
    """Dependencies that cannot form a valid execution graph."""


class UnknownInputError(GraphError):
    """An input that is neither a workflow input nor any node's output."""


class CycleError(GraphError):
    """Dependencies that loop back on themselves."""


def input_root(field: str) -> str:
    """The first segment of an input reference: 'applicant' for 'applicant.pan'."""
    return field.split(".", 1)[0]


def build_graph(wf: Workflow) -> nx.DiGraph:
    """Build the dependency graph of a workflow.

    Each graph node carries its Node model ("node") and file position ("index"); each edge
    carries its kinds ("data", "order") and the input fields it feeds. Raises GraphError on
    duplicate ids or outputs and on a workflow output no node produces, UnknownInputError on
    an input nobody produces, and CycleError on a loop.
    """
    g = nx.DiGraph(workflow=wf.name)
    producers = _add_nodes(g, wf)
    for field in wf.outputs:
        if input_root(field) not in producers:
            raise GraphError(f"workflow output {field!r} is not produced by any node")
    for node in wf.nodes:
        for field in node.inputs:
            root = input_root(field)
            if root in wf.inputs:
                continue
            if root not in producers:
                raise UnknownInputError(f"{node.id}: input {field!r} is not a workflow input "
                                        f"or any node's output")
            _link(g, producers[root], node.id, "data", field)
    writes = [node.id for node in wf.nodes if node.effect is Effect.WRITE]
    for earlier, later in zip(writes, writes[1:]):
        _link(g, earlier, later, "order")
    _add_control_edges(g, wf)
    _check_acyclic(g)
    _check_file_order(g)
    return g


def _add_nodes(g: nx.DiGraph, wf: Workflow) -> dict[str, str]:
    """Add every node to g and map each output field to the node that produces it."""
    producers: dict[str, str] = {}
    for index, node in enumerate(wf.nodes):
        if node.id in g:
            raise GraphError(f"duplicate node id {node.id!r}")
        g.add_node(node.id, node=node, index=index)
        for field in node.outputs:
            if field in wf.inputs:
                raise GraphError(f"{node.id}: output {field!r} has the name of a workflow input")
            if field in producers:
                raise GraphError(f"output {field!r} is produced by both {producers[field]} "
                                 f"and {node.id}")
            producers[field] = node.id
    return producers


def _add_control_edges(g: nx.DiGraph, wf: Workflow) -> None:
    """Link each gate to its branch nodes and record every node's memberships ("branches",
    a list of (gate id, branch name)). Missing branch members are errors: removing one can
    silently omit an outside write when the gate chooses that branch."""
    for node_id in g.nodes:
        g.nodes[node_id]["branches"] = []
    for node in wf.nodes:
        if node.kind is not NodeKind.GATE:
            if node.branches or node.condition or node.router:
                raise GraphError(f"{node.id}: only gate nodes have branches")
            continue
        seen: set[str] = set()
        for name, members in node.branches.items():
            for member in members:
                if member == node.id:
                    raise CycleError(f"{node.id}: a gate cannot be in its own branch")
                if member in seen:
                    raise GraphError(f"{node.id}: {member} is in two branches of the gate")
                seen.add(member)
                if member not in g:
                    raise GraphError(f"{node.id}: branch {name} lists missing node {member}")
                _link(g, node.id, member, "control")
                g.nodes[member]["branches"].append((node.id, name))


def _link(g: nx.DiGraph, src: str, dst: str, kind: str, field: str | None = None) -> None:
    """Add or extend the edge src -> dst with a kind and, for data edges, the field it feeds."""
    if not g.has_edge(src, dst):
        g.add_edge(src, dst, kinds=set(), fields=[])
    edge = g.edges[src, dst]
    edge["kinds"].add(kind)
    if field is not None:
        edge["fields"].append(field)


def _check_acyclic(g: nx.DiGraph) -> None:
    """Raise CycleError naming one loop if the graph has any."""
    try:
        cycle = nx.find_cycle(g)
    except nx.NetworkXNoCycle:
        return
    path = " -> ".join([src for src, _ in cycle] + [cycle[0][0]])
    raise CycleError(f"dependency cycle: {path}")


def _check_file_order(g: nx.DiGraph) -> None:
    """Raise GraphError if a node is listed before one it depends on: baseline mode runs
    nodes in file order, so every producer must come first."""
    for src, dst in g.edges:
        if g.nodes[src]["index"] > g.nodes[dst]["index"]:
            raise GraphError(f"{dst} is listed before {src}, which it depends on; "
                             f"baseline mode runs nodes in file order")


def _position(g: nx.DiGraph) -> Callable[[str], int]:
    """Sort key: a node's position in the workflow file."""
    return lambda node_id: g.nodes[node_id]["index"]


def topological_order(g: nx.DiGraph) -> list[str]:
    """Node ids in dependency order, ties broken by file position."""
    return list(nx.lexicographical_topological_sort(g, key=_position(g)))


def levels(g: nx.DiGraph) -> list[list[str]]:
    """Groups of nodes that could run at the same time: each depends only on earlier groups."""
    return [sorted(generation, key=_position(g)) for generation in nx.topological_generations(g)]


def dependencies(g: nx.DiGraph, node_id: str) -> list[str]:
    """Nodes whose outputs node_id reads directly, in file order; order-only edges excluded."""
    producers = [src for src in g.predecessors(node_id) if "data" in g.edges[src, node_id]["kinds"]]
    return sorted(producers, key=_position(g))


def consumers(g: nx.DiGraph, node_id: str) -> list[str]:
    """Nodes that read node_id's outputs directly, in file order; order-only edges excluded."""
    readers = [dst for dst in g.successors(node_id) if "data" in g.edges[node_id, dst]["kinds"]]
    return sorted(readers, key=_position(g))


def write_chain(g: nx.DiGraph) -> list[str]:
    """Write nodes in the order they must keep."""
    return [node_id for node_id in topological_order(g)
            if g.nodes[node_id]["node"].effect is Effect.WRITE]


def critical_path(g: nx.DiGraph, latency_ms: Mapping[str, float]) -> tuple[list[str], float]:
    """The longest latency-weighted chain of dependent nodes and its length in milliseconds.

    No amount of parallelism finishes a run faster than this chain. Nodes missing from
    latency_ms count as 0 ms; ties go to the node listed first in the file.
    """
    position = _position(g)
    finish: dict[str, float] = {}
    via: dict[str, str | None] = {}
    for node_id in topological_order(g):
        before = max(g.predecessors(node_id), default=None,
                     key=lambda src: (finish[src], -position(src)))
        via[node_id] = before
        start = finish[before] if before is not None else 0.0
        finish[node_id] = start + float(latency_ms.get(node_id, 0.0))
    if not finish:
        return [], 0.0
    end: str | None = max(finish, key=lambda node_id: (finish[node_id], -position(node_id)))
    total = finish[end]
    path = []
    while end is not None:
        path.append(end)
        end = via[end]
    return path[::-1], total


def downstream_criticality(g: nx.DiGraph,
                           latency_ms: Mapping[str, float]) -> dict[str, float]:
    """Estimated time from each node through its slowest remaining dependency path."""
    remaining: dict[str, float] = {}
    for node_id in reversed(topological_order(g)):
        remaining[node_id] = max(0.0, float(latency_ms.get(node_id, 1.0))) + max(
            (remaining[successor] for successor in g.successors(node_id)), default=0.0)
    return remaining


def gates(g: nx.DiGraph) -> list[str]:
    """Gate node ids in file order."""
    return sorted((node_id for node_id in g.nodes if g.nodes[node_id]["node"].kind is NodeKind.GATE),
                  key=_position(g))


def branch_of(g: nx.DiGraph, node_id: str) -> list[tuple[str, str]]:
    """The (gate id, branch name) pairs whose branch lists node_id directly, in file order of
    the gates; empty for a node no gate lists."""
    return sorted(g.nodes[node_id]["branches"], key=lambda pair: _position(g)(pair[0]))


def run_conditions(g: nx.DiGraph, node_id: str) -> frozenset[tuple[str, str]]:
    """Every (gate id, branch name) choice that must be made for node_id to run, directly or
    inherited: its own branch memberships, those of the gates that list it, and those of every
    node whose output it reads other than through optional_inputs. Empty means the node always
    runs (unless the run fails). Two nodes may be merged, reordered or substituted for each
    other only when their run conditions are equal; a node with conditions must never run
    before its gates decide."""
    memo: dict[str, frozenset[tuple[str, str]]] = {}
    for current in topological_order(g):
        node = g.nodes[current]["node"]
        conditions = set(g.nodes[current]["branches"])
        for gate_id, _ in g.nodes[current]["branches"]:
            conditions |= memo[gate_id]
        for src in g.predecessors(current):
            edge = g.edges[src, current]
            if "data" not in edge.get("kinds", ()):
                continue
            if any(field not in node.optional_inputs for field in edge["fields"]):
                conditions |= memo[src]
        memo[current] = frozenset(conditions)
        if current == node_id:
            return memo[current]
    raise KeyError(node_id)
