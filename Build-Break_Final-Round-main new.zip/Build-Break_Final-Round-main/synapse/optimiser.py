"""Choose dynamic passes from measured node profiles and run history, with explicit reasons.

Static rewrites (dead nodes, CSE, input compaction) always run. Dynamic passes need a profile:
parallelisation when a simulated schedule of the measured latencies finishes sooner than the
serial run, memoisation when cacheable nodes saw repeated inputs, and routing when the routed
plan passed the validation suite. A pass that run history measured as giving no gain is
skipped; measured gains are written back onto the decisions they belong to.
"""

from __future__ import annotations

import heapq
from collections.abc import Mapping
from typing import Any

import networkx as nx

from synapse.compiler import compile_workflow
from synapse.graph import build_graph
from synapse.ir import Decision, ExecPlan, NodeKind, Profile, Workflow
from synapse.passes.memoise import cache_blocker
from synapse.passes.parallelise import safe_order_edges
from synapse.passes.routing import Routing

DYNAMIC_PASSES = ("parallelise", "memoise", "routing")


def simulate_schedule(graph: nx.DiGraph, latency_ms: Mapping[str, float],
                      max_llm_concurrency: int | None = None) -> float:
    """Simulated wall time of a compiled run: a node starts once every predecessor (data or
    order edge) has finished, LLM nodes share max_llm_concurrency slots (None: no cap), and
    ready nodes start in file order. Nodes missing from latency_ms take 0 ms."""
    if max_llm_concurrency is not None and max_llm_concurrency < 1:
        raise ValueError("max_llm_concurrency must be at least 1")
    position = {node_id: graph.nodes[node_id].get("index", 0) for node_id in graph.nodes}
    is_llm = {node_id: getattr(graph.nodes[node_id].get("node"), "kind", None) is NodeKind.LLM
              for node_id in graph.nodes}
    waiting = {node_id: graph.in_degree(node_id) for node_id in graph.nodes}
    ready = [node_id for node_id, count in waiting.items() if count == 0]
    running: list[tuple[float, int, str]] = []
    now, busy, finish = 0.0, 0, 0.0
    while ready or running:
        ready.sort(key=position.__getitem__)
        for node_id in list(ready):
            if is_llm[node_id] and max_llm_concurrency is not None and busy >= max_llm_concurrency:
                continue
            ready.remove(node_id)
            busy += is_llm[node_id]
            heapq.heappush(running, (now + float(latency_ms.get(node_id, 0.0)),
                                     position[node_id], node_id))
        end, _, node_id = heapq.heappop(running)
        now, finish = end, max(finish, end)
        busy -= is_llm[node_id]
        for successor in graph.successors(node_id):
            waiting[successor] -= 1
            if waiting[successor] == 0:
                ready.append(successor)
    return finish


def record_measured(plan: ExecPlan, gains: Mapping[str, Mapping[str, Any]]) -> ExecPlan:
    """Write measured gains (pass name -> {"measured_ms", "measured_cost"}) back onto the
    plan: onto each pass's first applied decision, or its first decision when none applied,
    so a sum over decisions counts each measurement once. Returns the same plan."""
    for name, gain in gains.items():
        decisions = [d for d in plan.decisions if d.pass_name == name]
        target = next((d for d in decisions if d.status == "applied"),
                      decisions[0] if decisions else None)
        if target is None:
            continue
        target.measured_ms = gain.get("measured_ms")
        target.measured_cost = gain.get("measured_cost")
    return plan


def _no_gain(gain: Mapping[str, Any] | None) -> str | None:
    """Why run history rules a pass out: it was measured and saved neither time nor cost."""
    if not gain or gain.get("measured_ms") is None:
        return None
    saved_ms, saved_cost = gain["measured_ms"], gain.get("measured_cost")
    if saved_ms > 0 or (saved_cost is not None and saved_cost > 0):
        return None
    cost = f" and {saved_cost:.4g} cost" if saved_cost is not None else ""
    return f"run history measured no gain ({saved_ms:.1f} ms{cost} saved)"


def optimise(wf: Workflow, profile: Profile | None, *, validated_routing: bool = False,
             max_concurrency: int | None = None,
             history: Mapping[str, Mapping[str, Any]] | None = None) -> ExecPlan:
    """Static rewrites always run; schedule, cache and model changes need measured evidence.

    max_concurrency caps concurrent LLM calls in the simulated schedule (the provider's cap);
    history maps a pass name to its measured gain from earlier runs ({"measured_ms",
    "measured_cost"}), which is written back onto the plan and skips a dynamic pass that
    gained nothing."""
    selected = ["dead_nodes", "cse", "compact_inputs"]
    history = history or {}
    extra: list[Decision] = []
    candidates: list[str] = []
    static = compile_workflow(wf, passes=tuple(selected))
    if profile is None:
        for name in DYNAMIC_PASSES:
            extra.append(Decision(pass_name=name, nodes=[], status="skipped",
                                  reason="no measured profile is available"))
    else:
        graph = build_graph(static.workflow)
        graph.add_edges_from(safe_order_edges(static.workflow))
        latencies = {id: profile.nodes[id].p50_ms for id in graph.nodes if id in profile.nodes}
        serial = sum(latencies.values())
        scheduled = simulate_schedule(graph, latencies, max_concurrency)
        parallel_gain = max(0.0, serial - scheduled)
        blocked = _no_gain(history.get("parallelise"))
        if parallel_gain > 0 and blocked is None:
            selected.append("parallelise")
            extra.append(Decision(pass_name="parallelise", nodes=list(graph.nodes),
                                  status="applied",
                                  reason=f"simulated schedule of measured p50 latencies takes "
                                         f"{scheduled:.1f} ms against {serial:.1f} ms serial",
                                  predicted_ms=parallel_gain))
        else:
            extra.append(Decision(pass_name="parallelise", nodes=[], status="skipped",
                                  reason=blocked or "no measured parallel latency gain",
                                  predicted_ms=parallel_gain))
        if validated_routing:
            selected.append("routing")
            candidates = [d.nodes[0] for d in Routing(probe=True).plan(static.workflow)
                          if d.status == "applied"]
            extra.append(Decision(pass_name="routing", nodes=candidates,
                                  status="applied", reason="candidate passed the validation suite"))
        else:
            extra.append(Decision(pass_name="routing", nodes=[], status="skipped",
                                  reason="routing has not passed the validation suite"))
        repeaters = [id for id in graph.nodes if id in profile.nodes
                     and profile.nodes[id].repeat_input_rate > 0
                     and cache_blocker(graph.nodes[id]["node"]) is None]
        cache_gain_ms = sum(profile.nodes[id].p50_ms * profile.nodes[id].repeat_input_rate
                            for id in repeaters)
        cache_gain_cost = sum(profile.nodes[id].cost * profile.nodes[id].repeat_input_rate
                              for id in repeaters)
        blocked = _no_gain(history.get("memoise"))
        if repeaters and blocked is None:
            selected.append("memoise")
            extra.append(Decision(pass_name="memoise", nodes=repeaters,
                                  status="applied", reason="identical inputs recur in measured runs",
                                  predicted_ms=cache_gain_ms, predicted_cost=cache_gain_cost))
        else:
            extra.append(Decision(pass_name="memoise", nodes=[], status="skipped",
                                  reason=blocked or "no repeated inputs observed on a "
                                                    "cacheable node"))
    routing_evidence = ({node_id: None for node_id in candidates}
                        if "routing" in selected else None)
    plan = compile_workflow(wf, profile, passes=tuple(selected),
                            routing_evidence=routing_evidence)
    # The optimiser's summary decision leads each dynamic pass, so measurements land on it.
    plan.decisions = [d for d in plan.decisions if d.pass_name not in DYNAMIC_PASSES] + extra + [
        d for d in plan.decisions if d.pass_name in DYNAMIC_PASSES]
    return record_measured(plan, {name: gain for name, gain in history.items()
                                  if name in {d.pass_name for d in plan.decisions}})
