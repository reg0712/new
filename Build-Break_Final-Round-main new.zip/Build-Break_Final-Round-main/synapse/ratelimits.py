"""Rate limits during a run: a per-minute limit refreshes soon, so a run may wait and try
again; a daily quota does not, so the run must stop. The patterns match the dashboard's
isDailyQuotaError and isMinuteRateLimitError in ui/app.js, so both report alike.

Live calls already retry each request with backoff (synapse/backends/llm.py); this module
decides whether a whole run that still failed may be rerun once.
"""

from __future__ import annotations

import asyncio
import math
import re
from collections.abc import Awaitable, Callable
from typing import Literal

from synapse.ir import Effect, RunRecord, Workflow

_DAILY = re.compile(r"perday|per_day|per-day|requests per day|per day limit|daily quota|"
                    r"tokens per day|daily.*budget reached", re.IGNORECASE)
_LIMIT = re.compile(r"quota|rate[ -]?limit|429|resource_exhausted|too many requests|"
                    r"minute budget|waiting for the minute window|retry in", re.IGNORECASE)
_HINT = re.compile(r"retry in ([\d.]+)\s*s", re.IGNORECASE)


def limit_kind(error: str | None) -> Literal["daily", "minute"] | None:
    """Whether an error is a daily quota, a per-minute rate limit, or neither."""
    if not error:
        return None
    if _DAILY.search(error):
        return "daily"
    return "minute" if _LIMIT.search(error) else None


def wait_s(error: str, default: float = 60.0) -> float:
    """How long to wait before rerunning: the provider's 'retry in Ns' hint plus a margin,
    else a full minute."""
    hint = _HINT.search(error)
    return max(5.0, math.ceil(float(hint.group(1))) + 2.0) if hint else default


def rerun_is_safe(record: RunRecord, wf: Workflow) -> bool:
    """A rerun repeats every node, so it is safe only if no write was attempted.
    A node missing from the workflow counts as a write. An attempted write with an error
    may still have committed remotely, while a skipped write was never attempted."""
    effects = {node.id: node.effect for node in wf.nodes}
    return not any(effects.get(node.node_id, Effect.WRITE) is Effect.WRITE and not node.skipped
                   for node in record.nodes)


async def run_with_limit_retry(run: Callable[[], Awaitable[RunRecord]], wf: Workflow,
                               label: str, *,
                               sleep: Callable[[float], Awaitable[None]] = asyncio.sleep,
                               notify: Callable[[str], None] = print) -> RunRecord:
    """Run once; if it stopped on a per-minute rate limit before any write, wait as the
    provider asks and run it once more. Daily quotas and other errors return as they are."""
    record = await run()
    failure = next((node for node in record.nodes if node.error), None)
    if failure is None or limit_kind(failure.error) is None:
        return record
    if limit_kind(failure.error) == "daily":
        notify(f"{label} run stopped: the provider's daily quota is used up; try another "
               f"model or mock mode")
        return record
    if not rerun_is_safe(record, wf):
        notify(f"{label} run hit a rate limit after a write step; not rerunning, so the "
               f"write is not repeated")
        return record
    seconds = wait_s(str(failure.error))
    notify(f"{label} run stopped on a rate limit; waiting {seconds:.0f} s, then rerunning")
    await sleep(seconds)
    return await run()
