"""SQLite persistence for run traces, the compiler's audit log and validation proofs, and
content-addressed results (the `cache` table) such as OCR text for an uploaded document.

Content records are keyed by f"{kind}:{sha256(content)}" and keep the original bytes, so a
lookup verifies the bytes, not just the digest: a SHA-256 collision can never return another
document's value. Expiry uses wall-clock time (rows outlive processes). Content records are
pure functions of their bytes, so bank writes never invalidate them; the in-memory ExactCache
(synapse.passes.memoise) keeps its own ttl_s and write-invalidation rules.
"""

from __future__ import annotations

import json
import logging
import sqlite3
import hashlib
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from synapse import ROOT
from synapse.ir import ExecPlan, NodeRun, RunRecord, Usage, Workflow

SCHEMA = """
CREATE TABLE runs (run_id TEXT PRIMARY KEY, workflow TEXT, mode TEXT, plan_id TEXT,
  case_id TEXT, live INTEGER, cold_cache INTEGER, wall_ms REAL, created_at TEXT,
  latency_scale REAL, metadata_json TEXT);
CREATE TABLE node_runs (run_id TEXT, node_id TEXT, start_s REAL, end_s REAL,
  tokens_in INTEGER, tokens_out INTEGER, model TEXT, cost REAL, cache_hit INTEGER,
  cpu_pct REAL, mem_mb REAL, error TEXT, output_json TEXT, input_hash TEXT,
  retries INTEGER DEFAULT 0, usage_json TEXT, skipped INTEGER DEFAULT 0,
  skip_reason TEXT, branch TEXT);
CREATE TABLE decisions (plan_id TEXT, workflow TEXT, pass_name TEXT, nodes_json TEXT,
  reason TEXT, status TEXT, predicted_ms REAL, predicted_cost REAL,
  measured_ms REAL, measured_cost REAL);
CREATE TABLE cache (key TEXT PRIMARY KEY, entity TEXT, value_json TEXT,
  created_at REAL, ttl_s INTEGER, kind TEXT, content_sha256 TEXT, content BLOB);
CREATE TABLE checks (run_id TEXT, case_id TEXT, node_id TEXT, kind TEXT,
  passed INTEGER, detail TEXT);
CREATE TABLE validation_proofs (plan_id TEXT, workflow TEXT, workflow_hash TEXT,
  cases_json TEXT, backend_key TEXT, passed INTEGER, created_at TEXT,
  PRIMARY KEY (plan_id, workflow_hash, cases_json, backend_key));
"""

# Columns added after a table's first release, added to older databases on open.
_MIGRATIONS = {
    "node_runs": {"input_hash": "TEXT", "retries": "INTEGER DEFAULT 0", "usage_json": "TEXT",
                  "skipped": "INTEGER DEFAULT 0", "skip_reason": "TEXT", "branch": "TEXT"},
    "runs": {"latency_scale": "REAL", "metadata_json": "TEXT"},
    "cache": {"kind": "TEXT", "content_sha256": "TEXT", "content": "BLOB"},
}

logger = logging.getLogger(__name__)


def _content_digest(content: bytes) -> str:
    """SHA-256 hex digest of content: the content-record key (tests replace it to collide)."""
    return hashlib.sha256(content).hexdigest()


def _workflow_hash(workflow: Workflow) -> str:
    """Fingerprint the definition and prompt/schema bytes that were validated."""
    from synapse.passes.memoise import _file_digests
    source = json.dumps({"workflow": workflow.model_dump(mode="json"),
                         "files": {node.id: _file_digests(node) for node in workflow.nodes}},
                        sort_keys=True,
                        separators=(",", ":"))
    return hashlib.sha256(source.encode()).hexdigest()


def _backend_key(provider: str, model_names: dict[str, str] | None = None) -> str:
    """Identify the actual models whose small-tier outputs were checked."""
    if model_names is None:
        from synapse.config import load_config
        tiers = load_config("models.yaml")["providers"][provider]
        model_names = {tier: str(tiers[tier]) for tier in ("small", "large")}
    return json.dumps({"provider": provider, "models": model_names}, sort_keys=True)


class Store:
    """One SQLite database. A run and all its nodes commit as one transaction."""

    def __init__(self, path: str | Path = ROOT / "data" / "synapse.db") -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.connection = sqlite3.connect(self.path)
        self.connection.row_factory = sqlite3.Row
        self.connection.execute("PRAGMA foreign_keys=ON")
        with self.connection:
            for statement in SCHEMA.split(";"):
                if statement.strip():
                    self.connection.execute(statement.strip().replace("CREATE TABLE ",
                                                                     "CREATE TABLE IF NOT EXISTS ", 1))
            for table, added in _MIGRATIONS.items():
                columns = {row["name"] for row in
                           self.connection.execute(f"PRAGMA table_info({table})")}
                for column, kind in added.items():
                    if column not in columns:
                        self.connection.execute(f"ALTER TABLE {table} ADD COLUMN {column} {kind}")

    def __enter__(self) -> Store:
        return self

    def __exit__(self, *_: object) -> None:
        self.connection.close()

    def save_run(self, record: RunRecord, metadata: dict[str, Any] | None = None) -> None:
        """Persist a run atomically; a repeated run id is an error."""
        with self.connection:
            self.connection.execute(
                "INSERT INTO runs (run_id, workflow, mode, plan_id, case_id, live, "
                "cold_cache, wall_ms, created_at, latency_scale, metadata_json) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (record.run_id, record.workflow, record.mode, record.plan_id, record.case_id,
                 int(record.live), int(record.cold_cache), record.wall_ms,
                 datetime.now(timezone.utc).isoformat(), record.latency_scale,
                 json.dumps(metadata, ensure_ascii=False) if metadata is not None else None))
            self.connection.executemany(
                "INSERT INTO node_runs (run_id, node_id, start_s, end_s, tokens_in, tokens_out, "
                "model, cost, cache_hit, cpu_pct, mem_mb, error, output_json, input_hash, "
                "retries, usage_json, skipped, skip_reason, branch) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                [(record.run_id, node.node_id, node.start_s, node.end_s,
                  node.usage.tokens_in, node.usage.tokens_out, node.usage.model,
                  node.usage.cost, int(node.cache_hit), node.cpu_pct, node.mem_mb,
                  node.error, json.dumps(node.output, ensure_ascii=False),
                  node.input_hash, node.retries, node.usage.model_dump_json(),
                  int(node.skipped), node.skip_reason, node.branch) for node in record.nodes])

    def load_run(self, run_id: str) -> RunRecord:
        """Read one complete trace; preserve its execution order."""
        row = self.connection.execute("SELECT * FROM runs WHERE run_id=?", (run_id,)).fetchone()
        if row is None:
            raise KeyError(run_id)
        nodes = []
        for item in self.connection.execute(
                "SELECT * FROM node_runs WHERE run_id=? ORDER BY rowid", (run_id,)):
            nodes.append(NodeRun(
                run_id=run_id, node_id=item["node_id"], start_s=item["start_s"],
                end_s=item["end_s"], usage=(Usage.model_validate_json(item["usage_json"])
                if item["usage_json"] else Usage(tokens_in=item["tokens_in"],
                tokens_out=item["tokens_out"], model=item["model"], cost=item["cost"],
                retries=item["retries"] or 0)),
                cache_hit=bool(item["cache_hit"]), cpu_pct=item["cpu_pct"],
                mem_mb=item["mem_mb"], error=item["error"],
                output=json.loads(item["output_json"]), input_hash=item["input_hash"],
                retries=item["retries"] or 0, skipped=bool(item["skipped"]),
                skip_reason=item["skip_reason"], branch=item["branch"]))
        return RunRecord(run_id=run_id, workflow=row["workflow"], mode=row["mode"],
                         plan_id=row["plan_id"], case_id=row["case_id"],
                         live=bool(row["live"]), cold_cache=bool(row["cold_cache"]),
                         latency_scale=row["latency_scale"],
                         wall_ms=row["wall_ms"], nodes=nodes)

    def load_run_metadata(self, run_id: str) -> dict[str, Any]:
        """Return persisted API labels for a run, or empty labels for a legacy run."""
        row = self.connection.execute(
            "SELECT metadata_json FROM runs WHERE run_id=?", (run_id,)).fetchone()
        if row is None:
            raise KeyError(run_id)
        return json.loads(row["metadata_json"]) if row["metadata_json"] else {}

    def list_runs(self, workflow: str | None = None) -> list[str]:
        """Return run ids in creation order, optionally for one workflow."""
        query = "SELECT run_id FROM runs"
        params: tuple[Any, ...] = ()
        if workflow is not None:
            query += " WHERE workflow=?"
            params = (workflow,)
        return [row[0] for row in self.connection.execute(query + " ORDER BY rowid", params)]

    def save_decisions(self, plan: ExecPlan) -> None:
        """Persist the compiler audit record for this plan."""
        with self.connection:
            self.connection.execute("DELETE FROM decisions WHERE plan_id=?", (plan.plan_id,))
            self.connection.executemany(
                "INSERT INTO decisions VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                [(plan.plan_id, plan.workflow.name, decision.pass_name,
                  json.dumps(decision.nodes), decision.reason, decision.status,
                  decision.predicted_ms, decision.predicted_cost,
                  decision.measured_ms, decision.measured_cost)
                 for decision in plan.decisions])

    def save_validation(self, source: Workflow, plan: ExecPlan,
                        case_ids: list[str], passed: bool, *, provider: str = "mock",
                        model_names: dict[str, str] | None = None) -> None:
        """Record exactly which current workflow and cases approved a plan."""
        cases_json = json.dumps(sorted(set(case_ids)))
        with self.connection:
            self.connection.execute(
                "INSERT OR REPLACE INTO validation_proofs VALUES (?, ?, ?, ?, ?, ?, ?)",
                (plan.plan_id, source.name, _workflow_hash(source), cases_json,
                 _backend_key(provider, model_names),
                 int(passed), datetime.now(timezone.utc).isoformat()))

    def route_validated(self, workflow: Workflow, *, provider: str = "mock",
                        model_names: dict[str, str] | None = None,
                        plan: ExecPlan | None = None) -> bool:
        """Whether the current routed plan passed every case of the current suite."""
        from synapse.compiler import compile_workflow
        from mock_services import suite_for
        try:
            cases_json = json.dumps(sorted({case["case_id"]
                                           for case in suite_for(workflow.name).cases()}))
        except LookupError:
            return False
        candidate = plan or compile_workflow(workflow, passes=("dead_nodes", "cse", "compact_inputs", "parallelise",
                                                        "memoise", "routing"),
                                     routing_probe=True)
        return self.connection.execute(
            "SELECT 1 FROM validation_proofs WHERE plan_id=? AND workflow_hash=? "
            "AND cases_json=? AND backend_key=? AND passed=1 LIMIT 1",
            (candidate.plan_id, _workflow_hash(workflow), cases_json,
             _backend_key(provider, model_names))).fetchone() is not None

    # Content-addressed records

    def get_by_content(self, kind: str, content: bytes) -> dict[str, Any] | None:
        """The value saved for exactly these bytes under kind, or None. The stored original
        bytes must equal content, so a digest collision returns None, never another document's
        value. An expired row counts as missing and is deleted."""
        key, _ = _content_key(kind, content)
        row = self.connection.execute(
            "SELECT value_json, content, created_at, ttl_s FROM cache WHERE key=?",
            (key,)).fetchone()
        if row is None:
            return None
        if _expired(row["created_at"], row["ttl_s"], time.time()):
            with self.connection:  # only this row, and only if no put refreshed it meanwhile
                self.connection.execute("DELETE FROM cache WHERE key=? AND created_at IS ?",
                                        (key, row["created_at"]))
            return None
        if row["content"] is None or bytes(row["content"]) != bytes(content):
            logger.warning("content cache: %s matches a stored record but the bytes differ "
                           "(SHA-256 collision or foreign row); treating as a miss", key)
            return None
        return json.loads(row["value_json"])

    def put_by_content(self, kind: str, content: bytes, value: dict[str, Any],
                       ttl_s: int | None = None) -> str:
        """Save (or replace) the value for these bytes under kind; returns their SHA-256 hex
        digest. Saving identical bytes again replaces the value and restarts its ttl_s. If a
        live record with the same digest holds different bytes (a collision), it is kept
        unchanged and a warning is logged: the new value is not cached, so get_by_content for
        the new bytes keeps returning None and the caller recomputes."""
        key, digest = _content_key(kind, content)
        if not isinstance(value, dict):
            raise TypeError("value must be a dict")
        if ttl_s is not None and (isinstance(ttl_s, bool) or not isinstance(ttl_s, int)
                                  or ttl_s < 0):
            raise ValueError("ttl_s must be a non-negative integer or None")
        value_json = json.dumps(value, ensure_ascii=False)
        now = time.time()
        with self.connection:  # one statement, so the check and the write are atomic
            cursor = self.connection.execute(
                "INSERT INTO cache (key, entity, value_json, created_at, ttl_s, kind, "
                "content_sha256, content) VALUES (?, NULL, ?, ?, ?, ?, ?, ?) "
                "ON CONFLICT(key) DO UPDATE SET entity=excluded.entity, "
                "value_json=excluded.value_json, created_at=excluded.created_at, "
                "ttl_s=excluded.ttl_s, kind=excluded.kind, "
                "content_sha256=excluded.content_sha256, content=excluded.content "
                "WHERE cache.content IS NULL OR cache.content = excluded.content "
                "OR (cache.ttl_s IS NOT NULL AND (cache.created_at IS NULL "
                "OR ? >= cache.created_at + cache.ttl_s))",
                (key, value_json, now, ttl_s, kind, digest, bytes(content), now))
        if cursor.rowcount == 0:
            logger.warning("content cache: SHA-256 collision on %s; the stored record's bytes "
                           "differ, so it is kept and the new value is not cached", key)
        return digest


def _content_key(kind: str, content: bytes) -> tuple[str, str]:
    """The cache key and digest for content under kind, after checking both."""
    if not isinstance(kind, str) or not kind or ":" in kind:
        raise ValueError("kind must be a non-empty string without ':'")
    if not isinstance(content, (bytes, bytearray, memoryview)):
        raise TypeError("content must be bytes")
    digest = _content_digest(bytes(content))
    return f"{kind}:{digest}", digest


def _expired(created_at: float | None, ttl_s: int | None, now: float) -> bool:
    """Whether a row with this wall-clock created_at and ttl_s has expired at now."""
    if ttl_s is None:
        return False
    return created_at is None or now >= created_at + ttl_s
