"""One async executor for both modes, so every speedup comes from the graph rewrite.

Baseline mode awaits nodes in file order, the way most hand-written agents run. Compiled mode
launches every node whose inputs are ready, capped by a semaphore per provider (M5). Gate nodes
choose one branch in both modes; skipped nodes are recorded with skipped=True, no output and no
error, and never run (see graph.py for the skip rule).
"""

from __future__ import annotations

import asyncio
import time
import uuid
import hashlib
import json
import logging
from collections.abc import Awaitable, Callable, Mapping
from typing import Any, Literal

from synapse.backends import Backends, open_backends
from synapse.backends.llm import output_schema, render_prompt
from synapse.backends.llm import InvalidStructuredOutput, LLM_EVENTS
from synapse.ir import ExecPlan, Node, NodeKind, NodeRun, RunRecord, Usage, Workflow
from synapse.cost import estimate_cost
from synapse.graph import build_graph, downstream_criticality, input_root
from synapse.ir import Effect
from synapse.passes.memoise import ExactCache, cache_key

NodeResult = tuple[dict[str, Any], Usage, int]
logger = logging.getLogger(__name__)


async def run(wf: Workflow, case: dict[str, Any], mode: Literal["baseline", "compiled"],
              plan: ExecPlan | None = None, live: bool = False,
              cache: ExactCache | None = None,
              on_event: Callable[[dict[str, Any]], Awaitable[None]] | None = None) -> RunRecord:
    """Run one test case on fresh backends (live LLM calls when live is set). Callers running
    many cases should open the backends once and call execute()."""
    async with open_backends(live=live,
                             key_role="compiled" if mode == "compiled" else "original") as backends:
        return await execute(wf, case, mode, backends, plan=plan, live=live,
                             cache=cache, on_event=on_event)


async def execute(wf: Workflow, case: dict[str, Any], mode: Literal["baseline", "compiled"],
                  backends: Backends, plan: ExecPlan | None = None,
                  live: bool = False, cache: ExactCache | None = None,
                  on_event: Callable[[dict[str, Any]], Awaitable[None]] | None = None) -> RunRecord:
    """Run one test case through the workflow on the given backends.

    Gates choose one branch; nodes in untaken branches, and nodes that need a skipped node's
    output (other than through optional_inputs), are recorded as skipped and never run. In
    compiled mode a branch node starts only after its gate has chosen."""
    if mode == "compiled" and plan is None:
        from synapse.compiler import compile_workflow
        plan = compile_workflow(wf)
    active = plan.workflow if mode == "compiled" and plan else wf
    missing = [name for name in wf.inputs if name not in case]
    if missing:
        raise ValueError(f"case {case.get('case_id')!r} lacks workflow input(s): "
                         f"{', '.join(missing)}")
    run_id = uuid.uuid4().hex[:12]
    cold_cache = not _has_live_entries(cache)
    entity = cache_entity(wf, case)
    state = {name: case[name] for name in wf.inputs}
    started = time.perf_counter()
    nodes: list[NodeRun] = []
    branching = _Branching(active)

    async def skip(node: Node, reason: str) -> NodeRun:
        at_s = time.perf_counter() - started
        record = NodeRun(run_id=run_id, node_id=node.id, start_s=at_s, end_s=at_s,
                         skipped=True, skip_reason=reason)
        if on_event is not None:
            await on_event({"type": "node_skip", "node_id": node.id, "at_s": at_s,
                            "reason": reason})
        return record

    if mode == "baseline" or (plan is not None and not any(
            decision.pass_name == "parallelise" and decision.status == "applied"
            for decision in plan.decisions)):
        sequential_cache = None
        if mode == "compiled":
            sequential_cache = cache = cache if cache is not None else ExactCache()
        cached_ids = set(plan.cached_nodes) if mode == "compiled" and plan else set()
        for node in active.nodes:
            reason = branching.skip_reason(node)
            if reason is not None:
                record = await skip(node, reason)
            else:
                record = await _run_node(node, state, backends, run_id, started,
                                         cache=sequential_cache if node.id in cached_ids
                                         else None, entity=entity, on_event=on_event)
            nodes.append(record)
            branching.record(record)
            if not record.skipped and node.effect is Effect.WRITE and sequential_cache is not None:
                # A write may affect another customer's view of the same account.
                sequential_cache.invalidate(None)
            if record.error is not None:
                break
            state.update(record.output)
    else:
        assert plan is not None
        cache = cache if cache is not None else ExactCache()
        graph = build_graph(active)
        graph.add_edges_from(plan.order_edges)
        criticality = (downstream_criticality(graph, plan.schedule_latencies)
                       if plan.schedule_latencies else {})
        semaphores = {
            NodeKind.LLM: asyncio.Semaphore(backends.max_concurrency),
            NodeKind.TOOL: asyncio.Semaphore(backends.tool_concurrency),
            NodeKind.RETRIEVE: asyncio.Semaphore(backends.retrieve_concurrency),
        }

        async def launch(node: Node, snapshot: Mapping[str, Any]) -> NodeRun:
            node_cache = cache if node.id in plan.cached_nodes else None
            semaphore = semaphores.get(node.kind)
            if semaphore is not None:
                async with semaphore:
                    return await _run_node(node, snapshot, backends, run_id, started,
                                           cache=node_cache, entity=entity, on_event=on_event)
            return await _run_node(node, snapshot, backends, run_id, started,
                                   cache=node_cache, entity=entity, on_event=on_event)

        pending = set(graph.nodes)
        resolved: set[str] = set()  # finished or skipped
        running: dict[asyncio.Task[NodeRun], str] = {}
        failed = False
        while pending or running:
            progressed = not failed
            while progressed:  # skipping a node may make others ready at once
                progressed = False
                ready = sorted((id for id in pending if set(graph.predecessors(id)) <= resolved),
                               key=lambda id: (-criticality.get(id, 0.0),
                                               graph.nodes[id]["index"]))
                for id in ready:
                    pending.remove(id)
                    node = graph.nodes[id]["node"]
                    reason = branching.skip_reason(node)
                    if reason is None:
                        task = asyncio.create_task(launch(node, state.copy()))
                        running[task] = id
                        continue
                    record = await skip(node, reason)
                    nodes.append(record)
                    branching.record(record)
                    resolved.add(id)
                    progressed = True
            if not running:
                break
            done, _ = await asyncio.wait(running, return_when=asyncio.FIRST_COMPLETED)
            for task in done:
                id = running.pop(task)
                record = task.result()
                nodes.append(record)
                if graph.nodes[id]["node"].effect is Effect.WRITE and not record.skipped:
                    # Customer IDs alone cannot identify every resource a write changes.
                    cache.invalidate(None)
                if record.error:
                    failed = True
                else:
                    branching.record(record)
                    state.update(record.output)
                    resolved.add(id)
    return RunRecord(run_id=run_id, workflow=wf.name, mode=mode,
                     plan_id=plan.plan_id if plan else None, case_id=str(case.get("case_id", "")),
                     live=live, cold_cache=cold_cache, latency_scale=backends.latency_scale,
                     wall_ms=(time.perf_counter() - started) * 1000,
                     nodes=nodes)


def cache_entity(wf: Workflow, case: Mapping[str, Any]) -> str | None:
    """Whose records this run's reads and writes concern: the customer_id workflow input when
    there is one, else None (unknown, so a write drops every cached read)."""
    if "customer_id" in wf.inputs and case.get("customer_id") is not None:
        return str(case["customer_id"])
    return None


def _has_live_entries(cache: ExactCache | None) -> bool:
    """Whether the cache holds any entry that has not expired."""
    if cache is None:
        return False
    now = time.monotonic()
    return any(getattr(entry, "expires", None) is None or entry.expires > now
               for entry in cache.entries.values())


class _Branching:
    """Which gates chose which branch so far, which nodes were skipped, and why the next node
    must be skipped (the rule in graph.py's docstring)."""

    def __init__(self, wf: Workflow) -> None:
        self.members: dict[str, list[tuple[str, str]]] = {}
        for node in wf.nodes:
            if node.kind is NodeKind.GATE:
                for name, ids in node.branches.items():
                    for member in ids:
                        self.members.setdefault(member, []).append((node.id, name))
        self.producers = {field: node.id for node in wf.nodes for field in node.outputs}
        self.skipped: set[str] = set()
        self.chosen: dict[str, str] = {}

    def skip_reason(self, node: Node) -> str | None:
        """Why node must not run, or None when it may."""
        for gate, branch in self.members.get(node.id, ()):
            if gate in self.skipped:
                return f"gate {gate} was skipped"
            chosen = self.chosen.get(gate)
            if chosen is None:  # never run ahead of a gate's decision
                return f"gate {gate} has not chosen a branch"
            if chosen != branch:
                return f"{gate} chose branch {chosen}, not {branch}"
        for field in node.inputs:
            producer = self.producers.get(input_root(field))
            if producer in self.skipped and field not in node.optional_inputs:
                return f"needs {field} from skipped {producer}"
        return None

    def record(self, run: NodeRun) -> None:
        if run.skipped:
            self.skipped.add(run.node_id)
        elif run.branch is not None:
            self.chosen[run.node_id] = run.branch


def final_outputs(record: RunRecord) -> dict[str, Any]:
    """Every output field a run produced, merged."""
    merged: dict[str, Any] = {}
    for node in record.nodes:
        merged.update(node.output)
    return merged


def resolve(reference: str, state: Mapping[str, Any]) -> Any:
    """The value an input reference names: 'applicant.pan' reads state['applicant']['pan']."""
    root, *path = reference.split(".")
    if root not in state:
        raise KeyError(f"{reference}: {root!r} has not been produced")
    value = state[root]
    for key in path:
        if not isinstance(value, Mapping) or key not in value:
            raise KeyError(f"{reference}: no field {key!r}")
        value = value[key]
    return value


async def _run_node(node: Node, state: Mapping[str, Any], backends: Backends, run_id: str,
                    started: float, cache: ExactCache | None = None,
                    on_event: Callable[[dict[str, Any]], Awaitable[None]] | None = None,
                    entity: str | None = None) -> NodeRun:
    """Run one node and time it; a failure is recorded on the NodeRun, not raised. A cached
    read is tagged with entity, whose writes invalidate it. Gates are never cached. A result
    the cache cannot store (not plain JSON) is logged and left uncached; the node still
    succeeds."""
    start_s = time.perf_counter() - started
    output: dict[str, Any] = {}
    usage, error = Usage(), None
    retries = 0
    input_hash = None
    cache_hit = False
    branch = None
    if node.kind is NodeKind.GATE:
        cache = None  # a gate's decision is cheap and must be recorded on every run
    if on_event is not None:
        await on_event({"type": "node_start", "node_id": node.id, "at_s": start_s})
    from synapse.profiler import resource_snapshot, resource_usage
    before = resource_snapshot()
    quota_starts: list[float] = []
    quota_intervals: list[tuple[float, float]] = []
    async def model_event(event: dict[str, Any]) -> None:
        at_s = time.perf_counter() - started
        if event["type"] == "node_wait" and event["reason"] == "quota":
            quota_starts.append(at_s)
        elif event["type"] == "node_resume" and event["reason"] == "quota" and quota_starts:
            quota_intervals.append((quota_starts.pop(), at_s))
        if on_event is not None:
            await on_event({**event, "at_s": at_s})
    event_token = LLM_EVENTS.set(model_event)
    try:
        inputs = {reference: resolve(reference, state) for reference in node.inputs
                  if reference not in node.optional_inputs or input_root(reference) in state}
        canonical = json.dumps(inputs, sort_keys=True, separators=(",", ":"), default=str)
        input_hash = hashlib.sha256(canonical.encode()).hexdigest()
        settings = {"provider": backends.provider,
                    "model_name": backends.model_names.get(str(node.model))}
        if node.kind is not NodeKind.LLM:
            settings["backend"] = backends.cache_namespace
        key = cache_key(node, inputs, settings=settings) if cache is not None else None
        cached = cache.get(key) if cache is not None and key is not None else None
        if node.kind is NodeKind.GATE:
            branch = await _choose_branch(node, inputs, backends)
            output = {field: branch for field in node.outputs}
        elif cached is not None:
            output, cache_hit = cached, True
        else:
            output, usage, escalations = await _RUNNERS[node.kind](node, inputs, backends)
            retries = escalations + usage.retries
            if usage.cost == 0:
                usage.cost = estimate_cost(usage, node.model, provider=backends.provider)
            if cache is not None and key is not None:
                _store(cache, key, node, output, entity)
    except Exception as exc:  # the run stops at this node and reports why
        if isinstance(getattr(exc, "usage", None), Usage):
            usage = exc.usage
            if usage.cost == 0:
                usage.cost = estimate_cost(usage, node.model, provider=backends.provider)
            retries = usage.retries
        error = f"{type(exc).__name__}: {exc}"
    finally:
        LLM_EVENTS.reset(event_token)
    end_s = time.perf_counter() - started
    usage.quota_wait_intervals = quota_intervals
    cpu_pct, mem_mb = resource_usage(before, end_s - start_s)
    record = NodeRun(run_id=run_id, node_id=node.id, start_s=start_s,
                     end_s=end_s, usage=usage, output=output, error=error,
                     input_hash=input_hash, cpu_pct=cpu_pct, mem_mb=mem_mb,
                     cache_hit=cache_hit, retries=retries,
                     branch=branch if error is None else None)
    if on_event is not None:
        event = {"type": "node_finish", "node_id": node.id, "at_s": end_s,
                 "error": error, "cache_hit": cache_hit, "usage": usage.model_dump(mode="json")}
        if record.branch is not None:
            event["branch"] = record.branch
        await on_event(event)
    return record


def _store(cache: ExactCache, key: str, node: Node, output: dict[str, Any],
           entity: str | None) -> None:
    """Cache a node's result; a result the cache cannot hold is logged and not cached, since
    a caching failure must never turn a successful node into a failed one."""
    read = node.effect is Effect.READ
    try:
        cache.put(key, output, node.ttl_s if read else None, entity if read else None,
                  read=read)
    except Exception as exc:  # e.g. TypeError: a value that is not plain JSON
        logger.warning("%s: result not cached: %s: %s", node.id, type(exc).__name__, exc)


async def _choose_branch(node: Node, inputs: dict[str, Any], backends: Backends) -> str:
    """The branch a gate chooses: from its condition, or from its registered router function
    (called with the gate's inputs, like a transform), which must name exactly one branch."""
    if node.condition is not None:
        from synapse.parser import parse_condition
        branch: Any = parse_condition(node.condition).choose(inputs)
    else:
        function = backends.functions.get(str(node.router))
        if function is None:
            raise LookupError(f"no registered router {node.router!r} for gate {node.id}")
        if asyncio.iscoroutinefunction(function):
            branch = await function(dict(inputs))
        else:
            branch = await asyncio.to_thread(function, dict(inputs))
        if isinstance(branch, (list, tuple)) and len(branch) == 1:
            branch = branch[0]
        if isinstance(branch, (list, tuple, set, dict)):
            raise ValueError(f"gate {node.id}: router must choose exactly one branch, "
                             f"got {branch!r}")
        branch = branch if isinstance(branch, str) else str(branch)
    if branch not in node.branches:
        raise ValueError(f"gate {node.id} chose unknown branch {branch!r}; branches are "
                         f"{', '.join(node.branches)}")
    return branch


def _assign(node: Node, value: Any) -> dict[str, Any]:
    """A node's output fields: the whole value for one output, else one key per field."""
    if len(node.outputs) <= 1:
        return {field: value for field in node.outputs}
    if not isinstance(value, Mapping) or any(field not in value for field in node.outputs):
        raise ValueError(f"{node.id}: result lacks output fields {node.outputs}")
    return {field: value[field] for field in node.outputs}


async def _run_llm(node: Node, inputs: dict[str, Any], backends: Backends) -> NodeResult:
    schema = output_schema(node)
    prompt = render_prompt(node, inputs)
    try:
        result, usage = await backends.llm.invoke(node, prompt, schema)
        return _assign(node, result if schema is not None else result["text"]), usage, 0
    except Exception as first_error:
        from pydantic import ValidationError
        if node.fallback_model is None or not isinstance(
                first_error, (ValidationError, InvalidStructuredOutput)):
            raise
        fallback = node.model_copy(update={"model": node.fallback_model,
                                           "fallback_model": None})
        small_usage = (first_error.usage if isinstance(first_error, InvalidStructuredOutput)
                       else Usage(model=backends.model_names.get(str(node.model)), usage_complete=False))
        try:
            result, large_usage = await backends.llm.invoke(fallback, prompt, schema)
        except Exception as second_error:
            large_usage = getattr(second_error, "usage", Usage(
                model=backends.model_names.get(node.fallback_model), usage_complete=False))
            combined = _combine_usage(small_usage, large_usage, node, backends)
            error = RuntimeError(f"human review required: both model tiers failed: {second_error}")
            error.usage = combined
            raise error from second_error
        usage = _combine_usage(small_usage, large_usage, node, backends)
        return _assign(node, result if schema is not None else result["text"]), usage, 1


def _combine_usage(small: Usage, large: Usage, node: Node, backends: Backends) -> Usage:
    """Retain both calls' known usage, even when both schemas fail."""
    combined = large.model_copy(deep=True)
    combined.cost = (small.cost or estimate_cost(small, node.model, provider=backends.provider)) + (
        large.cost or estimate_cost(large, node.fallback_model, provider=backends.provider))
    for field in ("tokens_in", "tokens_out", "retries", "calls", "quota_wait_ms",
                  "retry_wait_ms", "provider_ms"):
        setattr(combined, field, getattr(large, field) + getattr(small, field))
    combined.quota_wait_intervals = small.quota_wait_intervals + large.quota_wait_intervals
    combined.usage_complete = small.usage_complete and large.usage_complete
    combined.model = f"{small.model}+{large.model}"
    return combined


async def _run_tool(node: Node, inputs: dict[str, Any], backends: Backends) -> NodeResult:
    return _assign(node, await backends.tools.call(str(node.tool), inputs)), Usage(), 0


async def _run_retrieve(node: Node, inputs: dict[str, Any], backends: Backends) -> NodeResult:
    query = node.query or str(next(iter(inputs.values()), ""))
    return _assign(node, await backends.retriever.search(str(node.index), query)), Usage(), 0


async def _run_transform(node: Node, inputs: dict[str, Any], backends: Backends) -> NodeResult:
    function = backends.functions.get(node.tool or node.id)
    if function is None:
        raise LookupError(f"no imported function for {node.id}")
    if asyncio.iscoroutinefunction(function):
        result = await function(inputs)
    else:
        result = await asyncio.to_thread(function, inputs)
    if not isinstance(result, Mapping) or any(field not in result for field in node.outputs):
        raise ValueError(f"{node.id}: imported function did not return declared outputs")
    return {field: result[field] for field in node.outputs}, Usage(), 0


async def _not_runnable(node: Node, inputs: dict[str, Any], backends: Backends) -> NodeResult:
    raise NotImplementedError(f"{node.kind.value} nodes run through _choose_branch")


_RUNNERS: dict[NodeKind, Callable[[Node, dict[str, Any], Backends], Awaitable[NodeResult]]] = {
    NodeKind.LLM: _run_llm,
    NodeKind.TOOL: _run_tool,
    NodeKind.RETRIEVE: _run_retrieve,
    NodeKind.TRANSFORM: _run_transform,
    NodeKind.GATE: _not_runnable,
}
