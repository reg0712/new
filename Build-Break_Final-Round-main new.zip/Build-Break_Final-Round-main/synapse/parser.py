"""YAML workflow files to Workflow models, validated on load.

A file has `workflow` (the name), `input` (the input fields), `nodes`, and optionally
`output` (results that must survive optimization; each must be produced by some node). Unknown
keys and node fields are errors, so a typo such as `efect: read` never falls back silently to
a default. Settings that would be silently ignored are errors too: `fallback_model` outside a
checked small-model LLM node, and `ttl_s` on a write (a node without `effect` is a write).

Gate nodes (`kind: gate`) branch a workflow. A gate lists `branches` (branch name -> ids of the
nodes that run only on that branch) and chooses one with either `condition`, an expression in
the small language of parse_condition, or `router`, the name of a registered function. Gates
must be pure and deterministic, may have one output (the chosen branch name), and are always
required. Every branch node must exist, be listed after its gate, and sit in at most one branch
of that gate; every branch a condition names must exist and every branch must be reachable.
"""

from __future__ import annotations

import re
from collections.abc import Mapping
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any

import yaml
from pydantic import ValidationError

from synapse.ir import Effect, Node, NodeKind, Workflow
from synapse.passes.cascade import checkable


class ParseError(ValueError):
    """A workflow file that does not describe a valid workflow."""


# Accepted spellings of each top-level key, preferred spelling first.
_TOP_LEVEL = {"name": ("workflow", "name"), "inputs": ("input", "inputs"),
              "nodes": ("nodes",), "outputs": ("output", "outputs")}

# Fields a node of each kind must set to be runnable.
_REQUIRED_BY_KIND = {
    NodeKind.LLM: ("model", "prompt"),
    NodeKind.TOOL: ("tool",),
    NodeKind.RETRIEVE: ("index", "query"),
}

_NAME = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")
_REFERENCE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_]*)*")


def load_workflow(path: str | Path) -> Workflow:
    """Read and validate a workflow YAML file."""
    path = Path(path)
    try:
        data = yaml.safe_load(path.read_text())
    except yaml.YAMLError as exc:
        raise ParseError(f"{path}: not valid YAML: {exc}") from exc
    return parse_workflow(data, source=str(path))


def parse_workflow(data: Any, source: str = "<workflow>") -> Workflow:
    """Validate a loaded YAML document into a Workflow; errors name the source and node."""
    if not isinstance(data, dict):
        raise ParseError(f"{source}: expected a mapping with workflow, input and nodes")
    known = {key for spellings in _TOP_LEVEL.values() for key in spellings}
    unknown = sorted(str(key) for key in data if key not in known)
    if unknown:
        raise ParseError(f"{source}: unknown top-level key(s): {', '.join(unknown)}")
    name = _pick(data, _TOP_LEVEL["name"], source)
    inputs = _pick(data, _TOP_LEVEL["inputs"], source)
    nodes = _pick(data, _TOP_LEVEL["nodes"], source)
    if not isinstance(name, str) or not _NAME.fullmatch(name):
        raise ParseError(f"{source}: workflow name must be a plain identifier, got {name!r}")
    if not isinstance(inputs, list) or not all(
            isinstance(field, str) and _NAME.fullmatch(field) for field in inputs):
        raise ParseError(f"{source}: input must be a list of plain field names")
    if len(set(inputs)) != len(inputs):
        raise ParseError(f"{source}: input lists a field twice")
    if not isinstance(nodes, list) or not nodes:
        raise ParseError(f"{source}: nodes must be a non-empty list")
    parsed = [_parse_node(raw, position, source) for position, raw in enumerate(nodes, start=1)]
    results = _pick(data, _TOP_LEVEL["outputs"], source, default=[])
    _check_outputs(results, parsed, source)
    _check_branches(parsed, source)
    return Workflow(name=name, inputs=inputs, nodes=parsed, outputs=results)


_REQUIRED = object()  # _pick default: the key must be present


def _pick(data: dict[Any, Any], spellings: tuple[str, ...], source: str,
          default: Any = _REQUIRED) -> Any:
    """The value under exactly one accepted spelling of a top-level key, or default when the
    key is optional and absent."""
    present = [key for key in spellings if key in data]
    if len(present) > 1:
        raise ParseError(f"{source}: use only one of {' or '.join(present)}")
    if not present:
        if default is _REQUIRED:
            raise ParseError(f"{source}: missing {spellings[0]!r}")
        return default
    return data[present[0]]


def _check_outputs(fields: Any, nodes: list[Node], source: str) -> None:
    """Workflow outputs: field names or dotted paths, each listed once and produced by a node."""
    if not isinstance(fields, list) or not all(
            isinstance(field, str) and _REFERENCE.fullmatch(field) for field in fields):
        raise ParseError(f"{source}: output must be a list of field names or dotted paths")
    if len(set(fields)) != len(fields):
        raise ParseError(f"{source}: output lists a field twice")
    produced = {field for node in nodes for field in node.outputs}
    missing = [field for field in fields if field.split(".", 1)[0] not in produced]
    if missing:
        raise ParseError(f"{source}: output {missing[0]!r} is not produced by any node")


def _parse_node(raw: Any, position: int, source: str) -> Node:
    """Validate one node mapping; errors name the node by id, or by position without one."""
    if not isinstance(raw, dict):
        raise ParseError(f"{source}: node {position} is not a mapping")
    where = f"{source}: node {raw.get('id', position)}"
    unknown = sorted(str(key) for key in raw if key not in Node.model_fields)
    if unknown:
        raise ParseError(f"{where}: unknown field(s): {', '.join(unknown)}")
    if raw.get("kind") == NodeKind.GATE.value and raw.get("required", True) is not True:
        raise ParseError(f"{where}: gates are always required checks; drop required: false")
    try:
        node = Node.model_validate(raw)
    except ValidationError as exc:
        first = exc.errors()[0]
        field = ".".join(str(part) for part in first["loc"])
        raise ParseError(f"{where}: {field}: {first['msg']}") from exc
    _check_node(node, where)
    return node


def _check_node(node: Node, where: str) -> None:
    """Check names, kind-specific fields, expiry and fallback, which the IR types alone cannot."""
    if not _NAME.fullmatch(node.id):
        raise ParseError(f"{where}: id must be a plain identifier")
    bad = [field for field in node.outputs if not _NAME.fullmatch(field)]
    if bad:
        raise ParseError(f"{where}: outputs must be plain field names, got {', '.join(bad)}")
    bad = [field for field in node.inputs if not _REFERENCE.fullmatch(field)]
    if bad:
        raise ParseError(f"{where}: inputs must be field names or dotted paths, "
                         f"got {', '.join(bad)}")
    missing = [field for field in _REQUIRED_BY_KIND.get(node.kind, ()) if not getattr(node, field)]
    if missing:
        raise ParseError(f"{where}: {node.kind.value} nodes need {', '.join(missing)}")
    if node.ttl_s is not None and node.ttl_s <= 0:
        raise ParseError(f"{where}: ttl_s must be positive")
    if node.ttl_s is not None and node.effect is Effect.WRITE:
        raise ParseError(f"{where}: ttl_s is a read's cache expiry, but this node is a write "
                         f"(a node without effect counts as a write)")
    if node.fallback_model is not None:
        if node.kind is not NodeKind.LLM:
            raise ParseError(f"{where}: fallback_model applies only to llm nodes")
        if node.model != "small":
            raise ParseError(f"{where}: fallback_model needs model: small, the tier it "
                             f"escalates from")
        if not checkable(node):
            raise ParseError(f"{where}: fallback_model needs a schema test to decide when "
                             f"to escalate")
    stray = [field for field in node.optional_inputs if field not in node.inputs]
    if stray:
        raise ParseError(f"{where}: optional_inputs must also be listed in inputs: "
                         f"{', '.join(stray)}")
    if node.kind is NodeKind.GATE:
        _check_gate(node, where)
    else:
        extra = [field for field in ("branches", "condition", "router") if getattr(node, field)]
        if extra:
            raise ParseError(f"{where}: {', '.join(extra)} apply only to gate nodes")


def _check_gate(node: Node, where: str) -> None:
    """A gate's own fields: pure, deterministic, at most one output, named branches, and
    exactly one valid way to choose among them."""
    if node.effect is not Effect.PURE or not node.deterministic:
        raise ParseError(f"{where}: gates must be effect: pure and deterministic: true")
    if len(node.outputs) > 1:
        raise ParseError(f"{where}: a gate has at most one output, the chosen branch name")
    if not node.branches:
        raise ParseError(f"{where}: gates need branches")
    bad = [name for name in node.branches if not _NAME.fullmatch(name) or name in _KEYWORDS]
    if bad:
        raise ParseError(f"{where}: branch names must be plain identifiers, got {bad[0]!r}")
    if (node.condition is None) == (node.router is None):
        raise ParseError(f"{where}: a gate needs exactly one of condition or router")
    if any(field for field in ("model", "prompt", "tool", "index", "query", "ttl_s")
           if getattr(node, field) is not None):
        raise ParseError(f"{where}: gates choose with condition or router only")
    if node.condition is not None:
        try:
            condition = parse_condition(node.condition)
        except ConditionError as exc:
            raise ParseError(f"{where}: condition: {exc}") from exc
        unknown = sorted(condition.branches - set(node.branches))
        if unknown:
            raise ParseError(f"{where}: condition names unknown branch {unknown[0]!r}")
        unreachable = [name for name in node.branches if name not in condition.branches]
        if unreachable:
            raise ParseError(f"{where}: condition never chooses branch {unreachable[0]!r}")
        uncovered = [ref for ref in condition.refs if covering_input(ref, node.inputs) is None]
        if uncovered:
            raise ParseError(f"{where}: condition reads {uncovered[0]!r}, which is not in "
                             f"the gate's inputs")
    elif not _NAME.fullmatch(str(node.router)):
        raise ParseError(f"{where}: router must be a plain function name")


def _check_branches(nodes: list[Node], source: str) -> None:
    """Branch ids name existing nodes listed after their gate, each in one branch per gate."""
    position = {node.id: index for index, node in enumerate(nodes)}
    for gate in nodes:
        if gate.kind is not NodeKind.GATE:
            continue
        where = f"{source}: node {gate.id}"
        seen: dict[str, str] = {}
        for name, members in gate.branches.items():
            for member in members:
                if member not in position:
                    raise ParseError(f"{where}: branch {name} lists unknown node {member!r}")
                if member == gate.id:
                    raise ParseError(f"{where}: a gate cannot be in its own branch")
                if member in seen:
                    raise ParseError(f"{where}: {member} is listed in branch {seen[member]} "
                                     f"and branch {name}; a node is in at most one branch")
                if position[member] < position[gate.id]:
                    raise ParseError(f"{where}: branch node {member} must be listed after "
                                     f"the gate")
                seen[member] = name


class ConditionError(ValueError):
    """A gate condition that is not in the condition language."""


_KEYWORDS = {"if", "else", "and", "or", "in", "true", "false", "null"}
_TOKEN = re.compile(r"""\s*(?:(?P<string>"[^"\\]*"|'[^'\\]*')
                       |(?P<number>-?\d+(?:\.\d+)?)
                       |(?P<op>==|!=|<=|>=|<|>|\(|\)|\[|\]|,)
                       |(?P<name>[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*))""",
                    re.VERBOSE)
_LITERALS = {"true": True, "false": False, "null": None}
_COMPARISONS = ("==", "!=", "<", "<=", ">", ">=")


@dataclass(frozen=True)
class Condition:
    """A parsed gate condition: the branches it can choose and the input fields it reads.

    The language, evaluated without eval():
        route      := BRANCH ["if" test "else" route]
        test       := conjunct ("or" conjunct)*
        conjunct   := atom ("and" atom)*
        atom       := "(" test ")" | FIELD OP literal | FIELD "in" "[" literal ("," literal)* "]"
        OP         := == | != | < | <= | > | >=
        literal    := "string" | 'string' | number | true | false | null
    For example: screen if kyc_status.status == "verified" else decline. FIELD is a gate input
    or a dotted path inside one. == and in never treat true as 1; ordering compares two
    numbers or two strings and fails the gate on anything else.
    """

    text: str
    tree: tuple
    branches: frozenset[str]
    refs: tuple[str, ...]

    def choose(self, inputs: Mapping[str, Any]) -> str:
        """The branch the condition picks for the gate's inputs ({reference: value}, as the
        executor passes them); raises ConditionError on a missing field or a bad comparison."""
        node = self.tree
        while node[0] == "if":
            _, branch, test, rest = node
            if _test(test, inputs):
                return branch
            node = rest
        return node[1]


def covering_input(ref: str, inputs: list[str]) -> str | None:
    """The gate input that ref reads: the input itself or the longest one ref extends."""
    best = None
    for field in inputs:
        if (ref == field or ref.startswith(field + ".")) and (best is None
                                                               or len(field) > len(best)):
            best = field
    return best


def _lookup(ref: str, inputs: Mapping[str, Any]) -> Any:
    """A condition field's value; None when it extends an optional input that was omitted."""
    field = covering_input(ref, list(inputs))
    if field is None:
        return None
    value = inputs[field]
    for key in ref[len(field):].split(".")[1:]:
        if not isinstance(value, Mapping) or key not in value:
            raise ConditionError(f"{ref}: no field {key!r}")
        value = value[key]
    return value


def _equal(left: Any, right: Any) -> bool:
    """Equality that never treats true as 1."""
    return isinstance(left, bool) == isinstance(right, bool) and left == right


def _test(tree: tuple, inputs: Mapping[str, Any]) -> bool:
    kind = tree[0]
    if kind == "or":
        return any(_test(part, inputs) for part in tree[1])
    if kind == "and":
        return all(_test(part, inputs) for part in tree[1])
    _, ref, op, literal = tree
    value = _lookup(ref, inputs)
    if op == "in":
        return any(_equal(value, item) for item in literal)
    if op == "==":
        return _equal(value, literal)
    if op == "!=":
        return not _equal(value, literal)
    numbers = all(isinstance(x, (int, float)) and not isinstance(x, bool) for x in (value, literal))
    if not numbers and not (isinstance(value, str) and isinstance(literal, str)):
        raise ConditionError(f"cannot compare {ref} = {value!r} {op} {literal!r}")
    return {"<": value < literal, "<=": value <= literal,
            ">": value > literal, ">=": value >= literal}[op]


def _tokens(text: str) -> list[tuple[str, Any]]:
    tokens: list[tuple[str, Any]] = []
    position = 0
    while position < len(text):
        if text[position:].strip() == "":
            break
        match = _TOKEN.match(text, position)
        if match is None or match.end() == position:
            raise ConditionError(f"unexpected text at {text[position:].strip()[:20]!r}")
        position = match.end()
        kind = match.lastgroup
        value = match.group(kind)
        if kind == "string":
            tokens.append(("literal", value[1:-1]))
        elif kind == "number":
            tokens.append(("literal", float(value) if "." in value else int(value)))
        elif kind == "name" and value in _LITERALS:
            tokens.append(("literal", _LITERALS[value]))
        elif kind == "name" and value in _KEYWORDS:
            tokens.append(("keyword", value))
        else:
            tokens.append((kind, value))
    return tokens


class _ConditionParser:
    def __init__(self, text: str) -> None:
        self.tokens = _tokens(text)
        self.position = 0
        self.branches: set[str] = set()
        self.refs: list[str] = []

    def peek(self) -> tuple[str, Any] | None:
        return self.tokens[self.position] if self.position < len(self.tokens) else None

    def take(self, kind: str, value: Any = None) -> Any:
        token = self.peek()
        if token is None or token[0] != kind or (value is not None and token[1] != value):
            wanted = repr(value) if value is not None else kind
            found = repr(token[1]) if token else "the end"
            raise ConditionError(f"expected {wanted}, found {found}")
        self.position += 1
        return token[1]

    def accept(self, kind: str, value: Any) -> bool:
        if self.peek() == (kind, value):
            self.position += 1
            return True
        return False

    def route(self) -> tuple:
        branch = self.take("name")
        if "." in branch:
            raise ConditionError(f"branch name {branch!r} must be a plain identifier")
        self.branches.add(branch)
        if not self.accept("keyword", "if"):
            return ("branch", branch)
        test = self.test()
        self.take("keyword", "else")
        return ("if", branch, test, self.route())

    def test(self) -> tuple:
        parts = [self.conjunct()]
        while self.accept("keyword", "or"):
            parts.append(self.conjunct())
        return parts[0] if len(parts) == 1 else ("or", tuple(parts))

    def conjunct(self) -> tuple:
        parts = [self.atom()]
        while self.accept("keyword", "and"):
            parts.append(self.atom())
        return parts[0] if len(parts) == 1 else ("and", tuple(parts))

    def atom(self) -> tuple:
        if self.accept("op", "("):
            inner = self.test()
            self.take("op", ")")
            return inner
        ref = self.take("name")
        self.refs.append(ref)
        if self.accept("keyword", "in"):
            self.take("op", "[")
            items = [self.take("literal")]
            while self.accept("op", ","):
                items.append(self.take("literal"))
            self.take("op", "]")
            return ("cmp", ref, "in", tuple(items))
        token = self.peek()
        if token is None or token[0] != "op" or token[1] not in _COMPARISONS:
            raise ConditionError(f"expected a comparison after {ref}, found "
                                 f"{repr(token[1]) if token else 'the end'}")
        self.position += 1
        return ("cmp", ref, token[1], self.take("literal"))


@lru_cache(maxsize=256)
def parse_condition(text: str) -> Condition:
    """Parse a gate condition (grammar on Condition); ConditionError says what is wrong."""
    if not isinstance(text, str) or not text.strip():
        raise ConditionError("condition is empty")
    parser = _ConditionParser(text)
    tree = parser.route()
    if parser.peek() is not None:
        raise ConditionError(f"unexpected {parser.peek()[1]!r} after the condition")
    return Condition(text, tree, frozenset(parser.branches), tuple(dict.fromkeys(parser.refs)))
