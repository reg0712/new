"""Pass protocol shared by every optimisation pass, and the gate facts passes respect.

A pass plans first, returning Decision records for everything it considered, including
skipped and rejected ones, each with a reason; then it applies the applied decisions.

Gates: a gate is always a required check, so no pass removes or merges it, and its branch
choice is never cached. A node a gate lists in a branch keeps its place in that branch: dead
nodes keeps it, and CSE never merges it away.
"""

from __future__ import annotations

from typing import Protocol

from synapse.ir import Decision, NodeKind, Profile, Workflow

__all__ = ["Decision", "Pass", "branch_members"]


class Pass(Protocol):
    name: str

    def plan(self, wf: Workflow, profile: Profile | None) -> list[Decision]: ...

    def apply(self, wf: Workflow, decisions: list[Decision]) -> Workflow: ...


def branch_members(wf: Workflow) -> dict[str, list[tuple[str, str]]]:
    """Each node a gate lists directly, with the (gate id, branch name) pairs listing it."""
    members: dict[str, list[tuple[str, str]]] = {}
    for node in wf.nodes:
        if node.kind is not NodeKind.GATE:
            continue
        for branch, ids in getattr(node, "branches", {}).items():
            for member in ids:
                members.setdefault(member, []).append((node.id, branch))
    return members
