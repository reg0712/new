"""PDF loan-application intake: turn an uploaded PDF into the loan workflow's `application_pdf`.

Pages with a usable text layer are read directly with pypdf. Pages without one are treated as
scans: rendered with pypdfium2 and read with Tesseract (through pytesseract, imported only when
a page needs OCR, so text PDFs never touch Tesseract). Extractions can be deduplicated through
any store with get_by_content/put_by_content, so a repeated upload is not OCR'd twice.

Errors are DocumentError subclasses whose messages tell a bank operator what to do next. They
never quote document content, and neither do the log lines.
"""

from __future__ import annotations

import asyncio
import hashlib
import io
import logging
import math
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import unicodedata
from collections.abc import Generator
from contextlib import closing
from dataclasses import asdict, dataclass, field, fields
from functools import lru_cache
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal, NamedTuple, Protocol

from synapse.config import load_config

if TYPE_CHECKING:
    from PIL.Image import Image

log = logging.getLogger(__name__)

# Store kinds may not contain ":". v2: identifier lines get a targeted second OCR pass.
CACHE_KIND = "pdf_text_v2"
OCR_MODES = ("auto", "always", "never")
WORKFLOW_INPUTS = ("application_pdf", "customer_id")
Method = Literal["text", "ocr", "mixed"]

_MB = 1024 * 1024
_HEADER_WINDOW = 1024              # the PDF spec lets %PDF- sit anywhere in the first 1 KB
_MAX_RENDER_PIXELS = 40_000_000    # about A2 at 300 dpi; bigger pages render at lower dpi
# pdfium is not thread-safe, even across separate documents, and extraction runs in worker
# threads, so every pdfium call goes through this lock.
_PDFIUM_LOCK = threading.Lock()


class DocumentError(ValueError):
    """An uploaded document cannot be used; the message says what the operator should do."""


class EncryptedPDF(DocumentError):
    """The PDF is encrypted or password-protected."""


class PDFTooLarge(DocumentError):
    """The PDF exceeds the configured size or page limit."""


class MalformedPDF(DocumentError):
    """The file is not a PDF, or its structure is damaged."""


class UnreadablePDF(DocumentError):
    """The PDF opened but yielded too little text to use."""


class OCRUnavailable(DocumentError):
    """The PDF needs OCR but Tesseract cannot be run."""


class ContentStore(Protocol):
    """What extraction needs from a cache: synapse.store.Store satisfies it."""

    def get_by_content(self, kind: str, content: bytes) -> dict[str, Any] | None: ...

    def put_by_content(self, kind: str, content: bytes, value: dict[str, Any],
                       ttl_s: int | None = None) -> str: ...


@dataclass(frozen=True)
class DocumentSettings:
    """Intake settings from config/documents.yaml; see that file for what each one does."""

    ocr: str = "auto"
    dpi: int = 300
    lang: str = "eng"
    tesseract_cmd: str = ""
    max_bytes: int = 10 * _MB
    max_pages: int = 20
    min_chars_per_page: int = 40
    ocr_timeout_s: float = 60
    cache_ttl_s: int | None = 86400

    def __post_init__(self) -> None:
        if self.ocr not in OCR_MODES:
            raise ValueError(f"documents ocr must be one of {', '.join(OCR_MODES)}, "
                             f"not {self.ocr!r}")
        if not 72 <= self.dpi <= 600:
            raise ValueError(f"documents dpi must be between 72 and 600, not {self.dpi}")
        if not re.fullmatch(r"[A-Za-z_]+(\+[A-Za-z_]+)*", self.lang):
            raise ValueError(f"documents lang must look like eng or eng+hin, not {self.lang!r}")
        for name in ("max_bytes", "max_pages", "min_chars_per_page"):
            if getattr(self, name) < 1:
                raise ValueError(f"documents {name} must be at least 1")
        if self.ocr_timeout_s < 0:
            raise ValueError("documents ocr_timeout_s must be 0 (no limit) or more")

    @classmethod
    def load(cls, **overrides: Any) -> DocumentSettings:
        """Settings from config/documents.yaml, with keyword overrides (tests, CLI flags)."""
        raw = {**load_config("documents.yaml"), **overrides}
        unknown = set(raw) - {f.name for f in fields(cls)}
        if unknown:
            raise ValueError(f"unknown documents setting(s): {', '.join(sorted(unknown))}")
        if raw.get("ocr") is False:   # YAML reads a bare `off` or `no` as False
            raw["ocr"] = "never"
        raw["tesseract_cmd"] = str(raw.get("tesseract_cmd") or "")
        return cls(**raw)


@dataclass
class Extraction:
    """Text pulled from one PDF, and how it was obtained. Page numbers start at 1."""

    text: str
    method: Method
    pages: int
    ocr_pages: list[int]
    sha256: str
    elapsed_ms: float
    from_cache: bool = False
    low_text_pages: list[int] = field(default_factory=list)  # still near-empty after extraction
    identifier_rereads: int = 0   # identifier lines given a second, targeted OCR pass
    review_flags: list[str] = field(init=False)  # things an operator must check by hand

    def __post_init__(self) -> None:
        self.review_flags = review_flags(self.text, ocr_used=bool(self.ocr_pages))

    def metadata(self) -> dict[str, Any]:
        """Everything but the text: safe to log, store with a run, or return from the API."""
        meta = asdict(self)
        del meta["text"]
        meta["chars"] = len(self.text)
        return meta


def load_pdf(path: str | Path, settings: DocumentSettings | None = None) -> bytes:
    """Read a PDF from disk, refusing files over max_bytes before reading them."""
    settings = settings or DocumentSettings.load()
    path = Path(path)
    size = path.stat().st_size
    if size > settings.max_bytes:
        raise _too_many_bytes(size, settings)
    with path.open("rb") as handle:
        data = handle.read(settings.max_bytes + 1)  # the file may have grown since stat
    if len(data) > settings.max_bytes:
        raise _too_many_bytes(len(data), settings)
    return data


def extract_text(data: bytes, *, settings: DocumentSettings | None = None,
                 store: ContentStore | None = None) -> Extraction:
    """Extract an application's text: the text layer where usable, Tesseract OCR elsewhere.
    Blocks for as long as OCR takes; async callers use extract_text_async."""
    settings = settings or DocumentSettings.load()
    started = time.perf_counter()
    data, digest, kind = _prepare(data, settings, store)
    cached = _cache_get(store, kind, data, digest, settings, started)
    if cached is not None:
        return cached
    extraction = _extract(data, digest, settings, started)
    _cache_put(store, kind, data, extraction, settings)
    return extraction


async def extract_text_async(data: bytes, *, settings: DocumentSettings | None = None,
                             store: ContentStore | None = None) -> Extraction:
    """extract_text with hashing, parsing, rendering and OCR in a worker thread, so the event
    loop keeps serving other requests while a scan is read."""
    settings = settings or DocumentSettings.load()
    started = time.perf_counter()
    data, digest, kind = await asyncio.to_thread(_prepare, data, settings, store)
    # The cache stays on the loop thread: a Store's sqlite3 connection works only in the
    # thread that opened it.
    cached = _cache_get(store, kind, data, digest, settings, started)
    if cached is not None:
        return cached
    extraction = await asyncio.to_thread(_extract, data, digest, settings, started)
    _cache_put(store, kind, data, extraction, settings)
    return extraction


def application_case(data: bytes, customer_id: str, case_id: str = "UPLOAD", *,
                     settings: DocumentSettings | None = None,
                     store: ContentStore | None = None) -> dict[str, Any]:
    """A loan_prescreen test case from an uploaded PDF. The workflow reads only
    application_pdf and customer_id; extraction metadata (no text) rides under "document"."""
    return case_from_extraction(extract_text(data, settings=settings, store=store),
                                customer_id, case_id)


async def application_case_async(data: bytes, customer_id: str, case_id: str = "UPLOAD", *,
                                 settings: DocumentSettings | None = None,
                                 store: ContentStore | None = None) -> dict[str, Any]:
    """application_case for async callers such as the API."""
    extraction = await extract_text_async(data, settings=settings, store=store)
    return case_from_extraction(extraction, customer_id, case_id)


def case_from_extraction(extraction: Extraction, customer_id: str,
                         case_id: str = "UPLOAD") -> dict[str, Any]:
    """A loan_prescreen case from an extraction the caller already holds."""
    customer_id = str(customer_id).strip()
    if not customer_id:
        raise ValueError("customer_id is required to screen an uploaded application")
    return {"case_id": case_id, "application_pdf": extraction.text, "customer_id": customer_id,
            "document": extraction.metadata()}


def resolve_tesseract(settings: DocumentSettings) -> str:
    """The tesseract binary: tesseract_cmd if set, else PATH, else this Python env's bin/."""
    if settings.tesseract_cmd:
        configured = Path(settings.tesseract_cmd).expanduser()
        if configured.is_file() and os.access(configured, os.X_OK):
            return str(configured)
        found = shutil.which(settings.tesseract_cmd)  # a bare command name is fine too
        if found:
            return found
        raise OCRUnavailable(
            f"This PDF needs OCR, but tesseract_cmd in config/documents.yaml "
            f"({settings.tesseract_cmd!r}) is not an executable file. Fix the path, or leave "
            f"it empty to auto-detect Tesseract.")
    env_bin = Path(sys.executable).parent
    for candidate in (shutil.which("tesseract"), env_bin / "tesseract",
                      env_bin / "tesseract.exe", env_bin / "Library" / "bin" / "tesseract.exe"):
        if candidate and Path(candidate).is_file() and os.access(candidate, os.X_OK):
            return str(candidate)
    raise OCRUnavailable(
        "This PDF is scanned and needs OCR, but Tesseract is not installed. Install it "
        "(conda install -c conda-forge tesseract) or set tesseract_cmd in "
        "config/documents.yaml; or ask the applicant for a PDF with selectable text.")


def cache_kind(settings: DocumentSettings) -> str:
    """Cache namespace for extractions: the OCR engine and its version plus every setting that
    changes the text, so an upgrade or a config change never serves stale text."""
    return (f"{CACHE_KIND}|{ocr_engine(settings)}|ocr={settings.ocr}|dpi={settings.dpi}"
            f"|lang={settings.lang}|min_chars={settings.min_chars_per_page}")


def ocr_engine(settings: DocumentSettings) -> str:
    """The OCR engine these settings would use, e.g. "tesseract-5.5.3". Asks the binary for
    its version (once per binary) without importing pytesseract."""
    if settings.ocr == "never":
        return "ocr-off"
    try:
        command = resolve_tesseract(settings)
    except OCRUnavailable:
        return "tesseract-missing"
    return _tesseract_version(command, Path(command).stat().st_mtime_ns)


@lru_cache(maxsize=8)
def _tesseract_version(command: str, mtime_ns: int) -> str:
    """`tesseract --version`, keyed by mtime too so an in-place upgrade is noticed."""
    try:
        result = subprocess.run([command, "--version"], capture_output=True, text=True,
                                timeout=10, check=False)
    except (OSError, subprocess.TimeoutExpired):
        return "tesseract-unknown"
    match = re.search(r"tesseract\s+v?(\d+(?:\.\d+)*)", result.stdout + result.stderr,
                      re.IGNORECASE)
    return f"tesseract-{match.group(1)}" if match else "tesseract-unknown"


def normalise_text(text: str) -> str:
    """Tidy extracted text for line-by-line parsing: fold Unicode compatibility forms and
    whitespace runs, strip each line and squeeze blank runs, but keep every line break."""
    text = unicodedata.normalize("NFKC", text)
    lines = [" ".join(line.split()) for line in text.splitlines()]
    kept: list[str] = []
    for line in lines:
        if line or (kept and kept[-1]):
            kept.append(line)
    return "\n".join(kept).strip("\n")


def meaningful_chars(text: str) -> int:
    """Letters and digits in text: the measure of whether a page has usable text."""
    return sum(ch.isalnum() for ch in text)


# Extraction steps.

def _prepare(data: bytes | bytearray | memoryview, settings: DocumentSettings,
             store: ContentStore | None) -> tuple[bytes, str, str]:
    """Validate and hash the bytes, and name the cache kind if a store will be asked."""
    data, digest = _precheck(data, settings)
    return data, digest, cache_kind(settings) if store is not None else ""


def _precheck(data: bytes | bytearray | memoryview, settings: DocumentSettings
              ) -> tuple[bytes, str]:
    """Cheap checks before parsing; returns the bytes and their sha256."""
    if not isinstance(data, (bytes, bytearray, memoryview)):
        raise TypeError(f"PDF data must be bytes, not {type(data).__name__}")
    data = bytes(data)
    if len(data) > settings.max_bytes:
        raise _too_many_bytes(len(data), settings)
    if not data:
        raise MalformedPDF("The uploaded file is empty. Ask the applicant to upload the "
                           "application again.")
    if b"%PDF-" not in data[:_HEADER_WINDOW]:
        raise MalformedPDF("The uploaded file is not a PDF. Ask the applicant for the "
                           "application as a PDF document.")
    return data, hashlib.sha256(data).hexdigest()


def _extract(data: bytes, digest: str, settings: DocumentSettings, started: float) -> Extraction:
    """Read every page's text layer, then OCR the pages that lack usable text."""
    reader = _open_pdf(data, settings)
    page_count = len(reader.pages)
    texts = [_page_text(reader, index) for index in range(page_count)]
    to_ocr = [index for index, text in enumerate(texts)
              if settings.ocr == "always"
              or (settings.ocr == "auto" and meaningful_chars(text) < settings.min_chars_per_page)]
    rereads = 0
    if to_ocr:
        for index, (ocr_text, page_rereads) in zip(to_ocr, _ocr_pages(data, to_ocr, settings)):
            # In auto mode a sparse text layer (say, a scanner's footer) is kept when OCR
            # finds even less.
            if settings.ocr == "always" or meaningful_chars(ocr_text) >= meaningful_chars(texts[index]):
                texts[index] = ocr_text
                rereads += page_rereads
    low = [index + 1 for index, text in enumerate(texts)
           if meaningful_chars(text) < settings.min_chars_per_page]
    if sum(meaningful_chars(text) for text in texts) < settings.min_chars_per_page:
        raise _unreadable(settings, ocr_ran=bool(to_ocr), pages=page_count)
    if low:
        log.info("PDF %s: page(s) %s have little or no text", digest[:12], low)
    ocr_pages = [index + 1 for index in to_ocr]
    method: Method = ("text" if not ocr_pages else
                      "ocr" if len(ocr_pages) == page_count else "mixed")
    return Extraction(text="\n\n".join(text for text in texts if text), method=method,
                      pages=page_count, ocr_pages=ocr_pages, sha256=digest,
                      elapsed_ms=_ms_since(started), low_text_pages=low,
                      identifier_rereads=rereads)


def _open_pdf(data: bytes, settings: DocumentSettings) -> Any:
    """A pypdf reader for an unencrypted PDF within the page limit."""
    from pypdf import PdfReader
    from pypdf.errors import LimitReachedError

    try:
        reader = PdfReader(io.BytesIO(data), strict=False)
        encrypted = reader.is_encrypted
        page_count = 0 if encrypted else len(reader.pages)
    except LimitReachedError:
        raise PDFTooLarge("The PDF holds more data than the intake limits allow. Ask the "
                          "applicant for a smaller file (fewer or lower-resolution pages).") from None
    except Exception as exc:  # pypdf raises many exception types on damaged or hostile input
        # `from None`: pypdf messages can quote raw file bytes, which must not reach logs.
        raise MalformedPDF(f"The PDF is damaged and cannot be opened ({type(exc).__name__}). "
                           "Ask the applicant to export or scan the application again.") from None
    if encrypted:
        # Refused even when the user password is empty: unlocking documents is the
        # applicant's call, and a permissions-only lock still signals restricted handling.
        raise EncryptedPDF("The PDF is password-protected or encrypted. Ask the applicant for "
                           "an unprotected copy (for example, print it to a new PDF).")
    if page_count == 0:
        raise MalformedPDF("The PDF has no pages. Ask the applicant to upload the full "
                           "application.")
    if page_count > settings.max_pages:
        raise _too_many_pages(page_count, settings)
    return reader


def _page_text(reader: Any, index: int) -> str:
    """One page's text layer, normalised; empty if the layer cannot be read."""
    try:
        return normalise_text(reader.pages[index].extract_text() or "")
    except Exception as exc:  # a broken content stream on one page should not sink the file
        log.warning("PDF page %d text layer unreadable (%s); treating it as a scan",
                    index + 1, type(exc).__name__)
        return ""


class PageOCR(NamedTuple):
    """One OCR'd page: its normalised text, and how many identifier lines were re-read."""

    text: str
    identifier_rereads: int = 0


def _ocr_pages(data: bytes, indexes: list[int], settings: DocumentSettings) -> list[PageOCR]:
    """OCR the given pages (0-based), one rendered page in memory at a time."""
    command = resolve_tesseract(settings)
    try:
        import pytesseract
    except ImportError:
        raise OCRUnavailable("This PDF needs OCR, but the pytesseract package is not "
                             "installed. Run `make setup` to install it.") from None
    # pytesseract reads its binary from a module global. Every caller in a process resolves
    # the same binary from the same config, so concurrent assignments agree.
    pytesseract.pytesseract.tesseract_cmd = command
    with closing(_render_pages(data, indexes, settings.dpi)) as images:
        return [_ocr_image(pytesseract, image, index + 1, settings)
                for index, image in zip(indexes, images)]


def _render_pages(data: bytes, indexes: list[int], dpi: int) -> Generator[Image, None, None]:
    """Render pages to grayscale images at dpi, lowering it for oversized pages."""
    import pypdfium2 as pdfium

    try:
        with _PDFIUM_LOCK:
            document = pdfium.PdfDocument(data)
    except pdfium.PdfiumError as exc:
        raise MalformedPDF(f"The PDF's pages cannot be rendered for OCR "
                           f"({type(exc).__name__}). Ask the applicant to scan the "
                           "application again.") from None
    try:
        for index in indexes:
            try:
                with _PDFIUM_LOCK:
                    image = _render_page(document, index, dpi)
            except pdfium.PdfiumError as exc:
                raise MalformedPDF(f"Page {index + 1} of the PDF cannot be rendered for OCR "
                                   f"({type(exc).__name__}). Ask the applicant to scan the "
                                   "application again.") from None
            yield image
    finally:
        with _PDFIUM_LOCK:
            document.close()


def _render_page(document: Any, index: int, dpi: int) -> Image:
    """One page as a grayscale image; call with _PDFIUM_LOCK held."""
    page = document[index]
    try:
        width, height = page.get_size()
        scale = dpi / 72
        if width * height * scale * scale > _MAX_RENDER_PIXELS:
            scale = math.sqrt(_MAX_RENDER_PIXELS / (width * height))
        bitmap = page.render(scale=scale, grayscale=True)
        # Copy so the image owns its pixels and nothing pdfium-backed is freed later by a
        # garbage collector running outside the lock.
        image = bitmap.to_pil().copy()
        bitmap.close()
        return image
    finally:
        page.close()


def _ocr_image(pytesseract: Any, image: Image, page: int, settings: DocumentSettings) -> PageOCR:
    """Tesseract on one page image; returns normalised text. A PAN line that is still not a
    valid PAN after the positional repair gets a targeted second pass (_reread_pans), within
    the same per-page ocr_timeout_s."""
    deadline = time.monotonic() + settings.ocr_timeout_s if settings.ocr_timeout_s else None
    try:
        raw = pytesseract.image_to_string(image, lang=settings.lang,
                                          timeout=settings.ocr_timeout_s)
    except pytesseract.TesseractNotFoundError:
        raise OCRUnavailable("This PDF needs OCR, but the Tesseract binary could not be "
                             "started. Check the Tesseract install or tesseract_cmd in "
                             "config/documents.yaml.") from None
    except pytesseract.TesseractError as exc:
        raise OCRUnavailable(f"Tesseract failed on page {page} (exit status {exc.status}). "
                             f"Check that its language data for {settings.lang!r} is "
                             "installed.") from None
    except RuntimeError as exc:
        if "timeout" not in str(exc).lower():
            raise
        raise UnreadablePDF(f"OCR of page {page} took longer than {settings.ocr_timeout_s:g} s "
                            "and was stopped. Ask for a clearer or smaller scan, or raise "
                            "ocr_timeout_s in config/documents.yaml.") from None
    text = _repair_ocr_identifiers(normalise_text(raw))
    if not _invalid_pan_lines(text):
        return PageOCR(text)
    return _reread_pans(pytesseract, image, text, page, settings, deadline)


# Tesseract confuses O/0, I/1, S/5 and B/8 inside IDs. A PAN is five letters, four digits
# and a letter, so each position says which reading is right.
_PAN_LINE = re.compile(r"^PAN\s*[:;.]?\s*([A-Za-z0-9]{10})$", re.MULTILINE)
_AS_LETTER = str.maketrans("012586", "OIZSBG")
_AS_DIGIT = str.maketrans("ODQILZSBG", "000112586")
_PAN = re.compile(r"[A-Z]{5}[0-9]{4}[A-Z]")
# Every line that starts with PAN, and what follows the label (spaces included, so a value
# that OCR split in two is still caught).
_PAN_VALUE = re.compile(r"^PAN[ \t]*[:;.]?[ \t]*(.*?)[ \t]*$", re.MULTILINE)

# The second pass re-reads just the PAN line: cropped from the page with some margin, enlarged,
# and read as one line (--psm 7) with a whitelist of the characters a PAN line can hold
# (spaces between words are kept regardless, so the whitelist needs none). Each variant is
# (margin as a share of the line height, upscale factor); different crops and sizes fail in
# different places, which is what makes their agreement meaningful.
_REREAD_VARIANTS = ((0.25, 1), (0.5, 1), (0.25, 2), (0.5, 2), (0.5, 3))
_REREAD_CONFIG = "--psm 7 -c tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789:"
_REREAD_MIN_AGREEING = 2
_REREAD_READING = re.compile(r"PAN\s*[:;.]?\s*([A-Z]{5}[0-9]{4}[A-Z])")


class _RereadStopped(Exception):
    """The second pass ran out of time or Tesseract failed; the first-pass text stands."""


def review_flags(text: str, *, ocr_used: bool) -> list[str]:
    """Problems that need a person: an OCR'd PAN that is still not a valid PAN is never
    guessed at, since a wrong guess could match another customer's record."""
    if not ocr_used:
        return []
    return ["PAN could not be read reliably by OCR; check it against the document before "
            "relying on KYC or bureau results" for _ in _invalid_pan_lines(text)]


def _invalid_pan_lines(text: str) -> list[re.Match[str]]:
    return [match for match in _PAN_VALUE.finditer(text) if not _PAN.fullmatch(match.group(1))]


def _repair_ocr_identifiers(text: str) -> str:
    """Fix OCR letter/digit swaps in the PAN line, only when the result is a valid PAN."""
    def fix(match: re.Match[str]) -> str:
        token = match.group(1).upper()
        candidate = (token[:5].translate(_AS_LETTER) + token[5:9].translate(_AS_DIGIT)
                     + token[9].translate(_AS_LETTER))
        return f"PAN: {candidate}" if _PAN.fullmatch(candidate) else match.group(0)

    return _PAN_LINE.sub(fix, text)


def _reread_pans(pytesseract: Any, image: Image, text: str, page: int,
                 settings: DocumentSettings, deadline: float | None) -> PageOCR:
    """Second OCR pass for PAN lines the first pass misread. A line's text is replaced only
    when its re-reads agree on one valid PAN that differs from the first reading by at most
    one character (the usual failure: a 0 read as "OO"); otherwise the first-pass text stays
    and review_flags reports it. Nothing here guesses a character no re-read produced."""
    lines = list(_PAN_VALUE.finditer(text))
    try:
        boxes = _pan_line_boxes(pytesseract, image, settings, deadline)
    except _RereadStopped as why:
        log.info("PDF page %d: PAN re-read skipped (%s)", page, why)
        return PageOCR(text)
    if len(boxes) != len(lines):  # the layout pass split the page differently: cannot pair
        log.info("PDF page %d: PAN re-read skipped (%d PAN line(s) located, %d read)",
                 page, len(boxes), len(lines))
        return PageOCR(text)
    rereads, pieces, last = 0, [], 0
    for match, box in zip(lines, boxes):
        if _PAN.fullmatch(match.group(1)):
            continue
        rereads += 1
        try:
            value = _reread_pan(pytesseract, image, box, match.group(1), settings, deadline)
        except _RereadStopped as why:
            log.info("PDF page %d: PAN re-read stopped (%s)", page, why)
            break
        if value is not None:
            pieces += [text[last:match.start()], f"PAN: {value}"]
            last = match.end()
    log.info("PDF page %d: re-read %d PAN line(s), %d accepted", page, rereads, len(pieces) // 2)
    return PageOCR("".join(pieces) + text[last:], rereads)


def _pan_line_boxes(pytesseract: Any, image: Image, settings: DocumentSettings,
                    deadline: float | None) -> list[tuple[int, int, int, int]]:
    """Pixel boxes (left, top, right, bottom) of the page's lines that start with PAN, in
    reading order, from Tesseract's layout analysis of the same image."""
    data = _soft_tesseract(lambda timeout: pytesseract.image_to_data(
        image, lang=settings.lang, timeout=timeout, output_type=pytesseract.Output.DICT),
        deadline)
    lines: dict[tuple[int, int, int], list[int]] = {}
    for i, word in enumerate(data["text"]):
        if str(word).strip():
            lines.setdefault((data["block_num"][i], data["par_num"][i], data["line_num"][i]),
                             []).append(i)
    return [(min(data["left"][i] for i in words), min(data["top"][i] for i in words),
             max(data["left"][i] + data["width"][i] for i in words),
             max(data["top"][i] + data["height"][i] for i in words))
            for words in lines.values() if str(data["text"][words[0]]).strip().startswith("PAN")]


def _reread_pan(pytesseract: Any, image: Image, box: tuple[int, int, int, int],
                first_value: str, settings: DocumentSettings,
                deadline: float | None) -> str | None:
    """Re-read one PAN line in several crops; the PAN they all agree on, or None."""
    from PIL import Image as PILImage

    left, top, right, bottom = box
    height = max(1, bottom - top)
    readings: list[str] = []
    for margin, scale in _REREAD_VARIANTS:
        pad = max(2, round(height * margin))
        crop = image.crop((max(0, left - pad), max(0, top - pad),
                           min(image.width, right + pad), min(image.height, bottom + pad)))
        if scale > 1:
            crop = crop.resize((crop.width * scale, crop.height * scale),
                               PILImage.Resampling.LANCZOS)
        raw = _soft_tesseract(lambda timeout, crop=crop: pytesseract.image_to_string(
            crop, lang=settings.lang, config=_REREAD_CONFIG, timeout=timeout), deadline)
        reading = _REREAD_READING.fullmatch(_repair_ocr_identifiers(normalise_text(raw)))
        if reading:
            readings.append(reading.group(1))
    distinct = set(readings)
    if len(distinct) != 1:  # none valid, or valid readings that disagree: do not choose
        return None
    value = distinct.pop()
    if readings.count(value) < _REREAD_MIN_AGREEING:
        return None
    if _edit_distance(_fold(value), _fold(first_value)) > 1:
        return None   # a PAN unrelated to what the page first read is not a correction
    return value


def _soft_tesseract(call: Any, deadline: float | None) -> Any:
    """Run a second-pass Tesseract call in what is left of the page's time budget; any
    failure becomes _RereadStopped, since the first pass already produced usable text."""
    timeout = 0.0   # pytesseract: 0 means no limit
    if deadline is not None:
        timeout = deadline - time.monotonic()
        if timeout < 0.05:
            raise _RereadStopped("ocr_timeout_s used up")
    try:
        return call(timeout)
    except RuntimeError as exc:
        if "timeout" not in str(exc).lower():
            raise
        raise _RereadStopped("ocr_timeout_s used up") from None
    except Exception as exc:  # TesseractError and friends: keep the first-pass text
        raise _RereadStopped(type(exc).__name__) from None


def _fold(value: str) -> str:
    """Upper-case, without spaces, with look-alike letters as digits: OCR's own confusions
    do not count as differences between two readings."""
    return value.upper().replace(" ", "").translate(_AS_DIGIT)


def _edit_distance(a: str, b: str) -> int:
    """Levenshtein distance (insertions, deletions, substitutions)."""
    if abs(len(a) - len(b)) > 1:
        return abs(len(a) - len(b))
    previous = list(range(len(b) + 1))
    for i, char_a in enumerate(a, 1):
        current = [i]
        for j, char_b in enumerate(b, 1):
            current.append(min(previous[j] + 1, current[j - 1] + 1,
                               previous[j - 1] + (char_a != char_b)))
        previous = current
    return previous[-1]


# Cache.

def _cache_get(store: ContentStore | None, kind: str, data: bytes, digest: str,
               settings: DocumentSettings, started: float) -> Extraction | None:
    """A cached extraction of these exact bytes under these settings, if any."""
    if store is None:
        return None
    try:
        value = store.get_by_content(kind, data)
    except Exception as exc:  # the cache only saves work; a broken one must not block intake
        log.warning("PDF text cache lookup failed (%s); extracting again", type(exc).__name__)
        return None
    if not _valid_cached(value):
        return None
    assert value is not None
    if value["pages"] > settings.max_pages:  # the limit may have been lowered since
        raise _too_many_pages(value["pages"], settings)
    return Extraction(text=value["text"], method=value["method"], pages=value["pages"],
                      ocr_pages=list(value["ocr_pages"]), sha256=digest,
                      elapsed_ms=_ms_since(started), from_cache=True,
                      low_text_pages=list(value.get("low_text_pages", [])))


def _cache_put(store: ContentStore | None, kind: str, data: bytes, extraction: Extraction,
               settings: DocumentSettings) -> None:
    """Remember a successful extraction for repeat uploads of the same bytes."""
    if store is None:
        return
    value = {"text": extraction.text, "method": extraction.method, "pages": extraction.pages,
             "ocr_pages": extraction.ocr_pages, "low_text_pages": extraction.low_text_pages}
    try:
        store.put_by_content(kind, data, value, ttl_s=settings.cache_ttl_s)
    except Exception as exc:
        log.warning("PDF text cache write failed (%s); continuing uncached", type(exc).__name__)


def _valid_cached(value: Any) -> bool:
    """True when a cached value has the shape this version writes."""
    return (isinstance(value, dict) and isinstance(value.get("text"), str)
            and value.get("method") in ("text", "ocr", "mixed")
            and isinstance(value.get("pages"), int) and isinstance(value.get("ocr_pages"), list))


# Error messages.

def _too_many_bytes(size: int, settings: DocumentSettings) -> PDFTooLarge:
    return PDFTooLarge(f"The PDF is {size / _MB:.1f} MB; the limit is "
                       f"{settings.max_bytes / _MB:.1f} MB. Ask the applicant for a smaller "
                       "file, or raise max_bytes in config/documents.yaml.")


def _too_many_pages(pages: int, settings: DocumentSettings) -> PDFTooLarge:
    return PDFTooLarge(f"The PDF has {pages} pages; the limit is {settings.max_pages}. Ask the "
                       "applicant for just the application form, or raise max_pages in "
                       "config/documents.yaml.")


def _unreadable(settings: DocumentSettings, *, ocr_ran: bool, pages: int) -> UnreadablePDF:
    if not ocr_ran:
        return UnreadablePDF(f"No usable text was found in the PDF ({pages} page(s)) and OCR "
                             "is turned off (ocr: never in config/documents.yaml). Turn OCR "
                             "on, or ask the applicant for a PDF with selectable text.")
    return UnreadablePDF(f"OCR found too little text in the PDF ({pages} page(s)). Ask the "
                         "applicant for a clearer scan: upright, in focus, and at least "
                         "300 dpi.")


def _ms_since(started: float) -> float:
    return round((time.perf_counter() - started) * 1000, 3)
