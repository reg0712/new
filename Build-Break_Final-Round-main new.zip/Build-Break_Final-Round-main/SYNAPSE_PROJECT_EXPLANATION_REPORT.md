# SYNAPSE: Comprehensive Project Master Report & Non-Technical Presentation Guide

> **Project Name:** SYNAPSE (A Dependency-Aware Compiler and Runtime for AI Agent Workflows)  
> **Target Event:** IDFC FIRST Bank Hackathon  
> **Original Execution Plan Date:** October 31, 2026  
> **Author & Lead:** @Nalin  
> **Document Status:** Complete Master Presentation & Architectural Blueprint  
> **Target Audience:** Executive Judges, Banking Leaders, Risk & Compliance Officers, and Technical Evaluators  

---

## Quick Navigation & Table of Contents

1. [Executive Summary & The "Elevator Pitch"](#1-executive-summary--the-elevator-pitch)
2. [The Core Problem: The "Dumb Assembly Line" in AI Agents](#2-the-core-problem-the-dumb-assembly-line-in-ai-agents)
3. [The Core Philosophy: "Safe by Construction" & The Traffic Light System](#3-the-core-philosophy-safe-by-construction--the-traffic-light-system)
4. [Academic Lineage & Prior Art (17 Landmark Papers Explained Simply)](#4-academic-lineage--prior-art-17-landmark-papers-explained-simply)
5. [The System Architecture: 8 Components in One Feedback Loop](#5-the-system-architecture-8-components-in-one-feedback-loop)
6. [The Workflow Intermediate Representation (IR) & Seeded Inefficiencies](#6-the-workflow-intermediate-representation-ir--seeded-inefficiencies)
7. [The Universal Bridge: LangGraph Importer](#7-the-universal-bridge-langgraph-importer)
8. [The Execution Profiler & Critical Path Analysis](#8-the-execution-profiler--critical-path-analysis)
9. [The Optimization Passes: Surgical Graph Rewrites (P0, P1, P2)](#9-the-optimization-passes-surgical-graph-rewrites-p0-p1-p2)
10. [The Adaptive Optimizer: Making Data-Driven Decisions](#10-the-adaptive-optimizer-making-data-driven-decisions)
11. [The Correctness & Safety Engine: The 7-Step Validation Gauntlet](#11-the-correctness--safety-engine-the-7-step-validation-gauntlet)
12. [The Demonstrations & Workflows Under the Microscope](#12-the-demonstrations--workflows-under-the-microscope)
13. [Benchmarking Methodology & Real Measured Results](#13-benchmarking-methodology--real-measured-results)
14. [The Dashboard: 8 Visual Proof Screens](#14-the-dashboard-8-visual-proof-screens)
15. [Technology Stack & System Architecture Decisions](#15-technology-stack--system-architecture-decisions)
16. [Team Organization & 24-Hour Hackathon Execution Plan](#16-team-organization--24-hour-hackathon-execution-plan)
17. [The 5-Minute Winning Pitch & Demo Script (Minute-by-Minute)](#17-the-5-minute-winning-pitch--demo-script-minute-by-minute)
18. [Judge Q&A Masterclass: Bulletproof Answers to the 9 Toughest Questions](#18-judge-qa-masterclass-bulletproof-answers-to-the-9-toughest-questions)
19. [Risk Matrix & High-Stakes Contingency Plans](#19-risk-matrix--high-stakes-contingency-plans)
20. [Speaker Notes, Delivery Strategy & Non-Technical Metaphors](#20-speaker-notes-delivery-strategy--non-technical-metaphors)

---

## 1. Executive Summary & The "Elevator Pitch"

### The One-Sentence Pitch
**SYNAPSE is an intelligent software compiler and high-speed runtime for Artificial Intelligence (AI) agents that makes bank automation over 3x faster and 65% cheaper—with a mathematical guarantee that it will never alter a financial decision, duplicate a money transfer, or send an unauthorized message to a customer.**

### The Executive Analogy
Imagine a modern restaurant kitchen where 10 skilled chefs are preparing a multi-course dinner for a customer. 
- In today's AI agent world, each chef stands completely still, waiting for the chef ahead of them to finish their single task. While Chef 1 is slicing tomatoes, Chef 2 is waiting by an empty pan, Chef 3 is waiting to open the spice cupboard, and Chef 4 is idle. Worse, if two dishes require the same sauce, they make it from scratch twice!
- **SYNAPSE acts as an expert Executive Chef (a compiler and smart scheduler).** It reads the entire recipe upfront, notices which ingredients can be prepped at the same time, merges duplicate preparations into a single pot, delegates easy chopping tasks to junior line cooks while saving the master executive chef for the final signature plating, and ensures that the final dish arrives at the diner's table piping hot in one-third the time and at a fraction of the cost—without altering the flavor by even a grain of salt.

### The Hackathon Target vs. Actual Achieved Results
When competing at the IDFC FIRST Bank hackathon, the team set bold self-imposed targets:
- **Target:** At least **2x faster** execution and **40% cheaper** cost per workflow, with **100% correctness** preserved across all test cases, demonstrated live on stage in under **5 minutes**.
- **Real Measured Achievement (Loan Pre-Screening Agent):**
  - **Latency (Speed):** Slashed from **132.1 ms down to 40.9 ms** in cold runs (**3.23x speedup**) and down to **19.6 ms** in repeat warm runs (**6.76x speedup**).
  - **Cost (Expense):** Cut from **19.50 units down to 6.75 units** per application (**65.4% cost reduction**).
  - **Accuracy:** **100% identical decisions** across every single test case (60/60 correct runs). Zero financial drift, zero hallucinations.
  - **Generality:** Successfully compiled un-tuned customer complaint triage workflows and complex LangGraph research agents without touching a line of core code.

### The Core Banking Promise: "Safe by Construction"
In banking, moving fast usually terrifies risk officers because "moving fast and breaking things" can cause catastrophic compliance fines, customer panic, or regulatory sanctions. 
SYNAPSE introduces **Safety by Construction**. It classifies every action using a strict "traffic-light" system. Steps that touch the real world—such as sending an SMS to a customer, debiting a bank balance, or creating a permanent ticket—are treated as untouchable. They can **never** be cached, reordered, skipped, or run speculatively. Speed is extracted exclusively from safe, pure reasoning and data fetching, giving risk and compliance teams 100% confidence.

---

## 2. The Core Problem: The "Dumb Assembly Line" in AI Agents

### How AI Agents Are Built Today
Across the global banking and technology landscape, developers build AI agents using frameworks like LangChain, LangGraph, AutoGen, or simple script chains. When a developer writes code for an AI agent—such as a loan pre-screening bot—they almost always write it as a sequential list of steps:
1. First, read the loan application.
2. Then, verify the applicant's identity (KYC check).
3. Then, call the credit bureau (CIBIL/Experian check).
4. Then, pull 6 months of bank account statements.
5. Then, analyze the applicant's income and cash flow.
6. Then, look up the bank's internal lending policy.
7. Then, look up the policy again because another sub-module needs it.
8. Then, fetch promotional credit card offers (even if no one asked for them).
9. Then, determine if the applicant is salaried or self-employed using a massive, expensive AI model.
10. Then, synthesize all findings into a credit risk decision.
11. Finally, send an SMS message to the customer.

### The 5 Hidden Traps Slowing Down Bank Workflows
When executed sequentially like a naive script, this creates five severe bottlenecks:

1. **Unnecessary Sequential Waiting (The Traffic Jam):**
   Checking an applicant's identity (KYC), fetching their credit score, pulling their bank statement, and reading the policy document are completely independent operations. None of them depends on the others! Yet, the agent runs them one by one. If each step takes 1.5 seconds, the customer waits 6 seconds just for data retrieval that could have finished in 1.5 seconds if launched simultaneously.
2. **Duplicate Homework (Redundant Queries):**
   In large, complex enterprise workflows, different sub-components often ask the exact same question or fetch the exact same document. In our loan workflow, `policy_lookup_1` and `policy_lookup_2` fetch the identical lending guidelines. The bank pays twice in latency and compute for the same information.
3. **Useless Chores (Dead Work):**
   Legacy code, copy-pasted templates, and generic agent prompts often call tools whose outputs are never read by any subsequent step. In our loan workflow, `offers_lookup` calls an external marketing API, but the final risk summary never considers marketing offers. The bank spends network bandwidth, API fees, and precious seconds on dead weight.
4. **Using a Sledgehammer to Crack a Peanut (Model Over-Provisioning):**
   Many agents route every single task to the biggest, slowest, most expensive "frontier" model (like GPT-4 or Gemini 1.5 Pro). In our workflow, categorizing an applicant's employment as "Salaried" or "Self-Employed" is a trivial categorization that an ultra-fast, cheap model (like Gemini Flash-Lite or Groq Llama-3) can perform with 100% accuracy in milliseconds at 1/20th the cost.
5. **Amnesia (Ignoring Repeat Data):**
   When an applicant applies for a loan, and then checks back or updates their requested amount 10 minutes later, traditional agents run the expensive credit bureau API call all over again. While bank balances fluctuate frequently, a credit bureau score or a government KYC verification remains valid for hours or days. Naive agents fail to safely cache these results.

### Why Banks Haven't Solved This Yet
If these flaws are so obvious, why don't developers just manually fix them?
Because doing it manually requires writing complex, fragile multithreaded code for every single workflow. Even worse, if a developer manually makes a mistake—such as running a money transfer before a fraud check finishes, or caching an old bank balance when a customer just withdrew funds—the bank loses money.
**Developers need a compiler:** an automated engine that inspects the workflow, figures out the dependencies mathematically, applies provably safe optimizations, validates the outputs, and runs it fast without human error. That compiler is **SYNAPSE**.

---

## 3. The Core Philosophy: "Safe by Construction" & The Traffic Light System

### The Banking Hook: Effect Annotations
The cornerstone of SYNAPSE's pitch to IDFC FIRST Bank is that it is **safe by design**. Instead of treating all software tasks as generic blocks of code, SYNAPSE requires every single task (node) to declare its **Effect Annotation**. 

Think of this as a strict traffic light system for financial operations:

```
+---------------------------------------------------------------------------------+
|                        SYNAPSE EFFECT ANNOTATION SYSTEM                         |
+---------------------+-----------------------------------+-----------------------+
|  EFFECT TAG         |  WHAT IT REPRESENTS               |  COMPILER PERMISSIONS |
+---------------------+-----------------------------------+-----------------------+
|  🟢 PURE            |  Internal reasoning, formatting,  |  CAN: Parallelize     |
|                     |  local calculation, prompt        |  CAN: Merge duplicates|
|                     |  building. No outside contact.    |  CAN: Eliminate if unused
|                     |                                   |  CAN: Cache / Speculate
+---------------------+-----------------------------------+-----------------------+
|  🟡 READ            |  Looking at outside world data    |  CAN: Parallelize     |
|                     |  (fetching CIBIL score, reading   |  CAN: Merge identical |
|                     |  account balances, API queries).  |  CAN: Cache ONLY with |
|                     |  Does not change any state.       |       strict TTL/expiry
|                     |                                   |  INVALIDATED: By writes
+---------------------+-----------------------------------+-----------------------+
|  🔴 WRITE           |  Changing the outside world       |  CANNOT: Reorder      |
|                     |  (sending SMS, debiting money,    |  CANNOT: Eliminate    |
|                     |  updating CRM, blocking a card).  |  CANNOT: Cache        |
|                     |  Has permanent real-world effect. |  CANNOT: Speculate    |
+---------------------+-----------------------------------+-----------------------+
```

### The Fail-Safe Rule: The Default Is Always WRITE
In traditional systems, if a developer forgets to configure a setting, the system might guess or make a dangerous assumption. 
In SYNAPSE:
- If a developer imports a workflow or writes a node and **omits the effect tag**, SYNAPSE automatically assigns it **`Effect.WRITE`**.
- This means the unknown node is instantly quarantined: it will never be reordered, never be cached, never be skipped, and never run speculatively. 
- **SYNAPSE fails closed, never open.**

### Managing Temporal Reads (Why TTL Matters in Banking)
In finance, data has a shelf life:
- A government **KYC check** (PAN verification) is valid for **24 hours (86,400 seconds)**.
- A **Credit Bureau Score** is valid for **1 hour (3,600 seconds)**.
- A **Savings Account Balance** changes constantly; it can only be cached for **15 minutes (900 seconds)** or must be invalidated the instant any write occurs.
- After any attempted write, SYNAPSE evicts all cached reads in that run's shared cache. This conservative rule also covers joint accounts where different customer IDs refer to the same balance.

### The Immutable Audit Trail
Bank regulators (such as the Reserve Bank of India) and internal risk audit teams require complete explainability. If an AI decides to decline a loan, the bank cannot say "the black-box AI chose to." 
SYNAPSE logs every single compiler rewrite in an immutable SQLite decision ledger:
- Which pass was proposed.
- Why it was proposed (e.g., "bureau_check and kyc_check share no data dependencies").
- What gain was predicted (e.g., "expected latency reduction: 45 ms").
- Whether the pass passed the safety verification gauntlet.
- The final decision: Accepted or Rejected.
This audit trail turns compliance from an obstacle into SYNAPSE's greatest selling point.

---

## 4. Academic Lineage & Prior Art (17 Landmark Papers Explained Simply)

Judges at competitive technical hackathons often ask: *"Did you invent this out of thin air, or is this backed by real computer science research?"*
SYNAPSE is built upon a rock-solid foundation of **17 peer-reviewed papers and industry systems (spanning 2023 to 2026)**. Every single optimization in SYNAPSE borrows a proven concept from world-class research and packages it into an effect-safe, bank-grade compiler.

Here is the complete non-technical translation of the academic research behind SYNAPSE:

```
+----------------------------------------------------------------------------------------------------+
|                               THE 17 ACADEMIC PILLARS OF SYNAPSE                                   |
+--------------------------+-------------------------------------+-----------------------------------+
| RESEARCH PAPER / SYSTEM  | WHAT THE RESEARCH DISCOVERED        | WHAT SYNAPSE BORROWED & APPLIED   |
+--------------------------+-------------------------------------+-----------------------------------+
| 1. Dyserve (2026)        | An adaptive runtime compiler that   | Profile-guided compiler passes;   |
|    arXiv: 2607.02942     | dynamically selects model tiers     | node vulnerability routing (keeps |
|                          | and backend engines, cutting        | high-stakes decision nodes on     |
|                          | latency up to 6.8x.                 | large models, moves simple nodes).|
+--------------------------+-------------------------------------+-----------------------------------+
| 2. LLMCompiler (2023)    | A planner that translates tool      | The core parallelization pass and |
|    arXiv: 2312.04511     | calls into a DAG, executing         | the clean architectural split     |
|                          | independent tools concurrently      | between Planner, Dispatcher, and  |
|                          | (up to 3.7x faster, 6.7x cheaper).  | Executor.                         |
+--------------------------+-------------------------------------+-----------------------------------+
| 3. LAWA (2026)           | In recurring workflows (like bank   | "Optimize once, run millions of   |
|    arXiv: 2610.14481     | support), graph rewrites targeted   | times" philosophy; selecting passes|
|                          | at the critical path cut run times. | specifically to shrink critical path|
+--------------------------+-------------------------------------+-----------------------------------+
| 4. Teola (2024)          | Deconstructing monolithic LLM tasks | Fine-grained IR nodes so tool APIs|
|    arXiv: 2407.00326     | into fine-grained dataflow nodes    | data retrieval, and LLM reasoning |
|                          | unlocked 2.09x overlap speedup.     | overlap simultaneously.           |
+--------------------------+-------------------------------------+-----------------------------------+
| 5. Helium (2026)         | Treating LLM prompts like relational| "Compiler as a query optimizer"   |
|    arXiv: 2603.16104     | database query operators with       | mindset; cache-aware execution    |
|                          | cache-aware scheduling (1.56x gain).| planning and data locality.       |
+--------------------------+-------------------------------------+-----------------------------------+
| 6. DynBranch (2026)      | Speculatively running likely        | Speculative branch execution:     |
|    arXiv: 2609.31047     | downstream branches cut latency     | launching pure work on a probable |
|                          | by up to 32%.                       | gate branch before gate resolves. |
+--------------------------+-------------------------------------+-----------------------------------+
| 7. Sherlock (2025)       | Selectively verifying error-prone   | The Safety Validator: verify      |
|    arXiv: 2511.00330     | steps while speculatively executing | routed nodes hardest, with        |
|                          | ahead, rolling back on failure.     | automatic rollback on deviation.  |
+--------------------------+-------------------------------------+-----------------------------------+
| 8. FrugalGPT (2023)      | Cascading from cheap to expensive   | Model cascade pass: try fast,     |
|    arXiv: 2305.05176     | LLMs matched GPT-4 accuracy at      | cheap model first, fall back to   |
|                          | up to 98% lower cost.               | premium model only if needed.     |
+--------------------------+-------------------------------------+-----------------------------------+
| 9. RouteLLM (2024)       | Routing simpler queries to weak     | Rule-based model routing pass for |
|    arXiv: 2406.18665     | models cut operational cost over 2x | classification and extraction.    |
|                          | with zero quality loss.             |                                   |
+--------------------------+-------------------------------------+-----------------------------------+
| 10. Routing Survey (2025)| Deciding which model to use BEFORE  | Upfront static routing decisions  |
|     (Consensus)          | calling the model is dramatically   | rather than inefficient retry     |
|                          | more resource-efficient.            | generation.                       |
+--------------------------+-------------------------------------+-----------------------------------+
| 11. Early Abstention     | In high-risk domains like finance,  | Banking safety hook: escalate     |
|     Cascades (2025)      | models should abstain rather than   | uncertain cases to human review   |
|     arXiv: 2502.09054    | guess (cut cost 13%, errors 5%).    | rather than hallucinating.        |
+--------------------------+-------------------------------------+-----------------------------------+
| 12. Hierarchical Caching | Tool-level caching with write-based | Writes invalidate all cached     |
|     for Agents (2026)    | invalidation and session isolation  | reads; exact input-bound keys.    |
|                          | (13.3x faster, 73.3% cheaper).      |                                   |
+--------------------------+-------------------------------------+-----------------------------------+
| 13. Temporal Semantic    | Pure semantic caching fails when    | Time-to-Live (TTL) timestamps and |
|     Caching (2026)       | validity depends on time or money;  | strict parameter hashing for      |
|     arXiv: 2605.20630    | parameter-bound caching yielded 1.67x.| account balances and credit scores.|
+--------------------------+-------------------------------------+-----------------------------------+
| 14. GPTCache             | Industry-standard semantic caching  | Semantic cache pass for answering |
|                          | for LLM responses.                  | recurring customer questions.     |
+--------------------------+-------------------------------------+-----------------------------------+
| 15. Don't Break Cache    | Static prompt prefixes at the front | Prefix-ordering pass: placing     |
|     (2026 - Consensus)   | enable LLM provider prompt caches   | static instructions upfront to hit|
|                          | (cutting cost 41-80%).              | Gemini/Groq prompt caches.        |
+--------------------------+-------------------------------------+-----------------------------------+
| 16. LLMLingua (2023)     | Compressing verbose prompts up to   | Prompt trimming pass: stripping   |
|     arXiv: 2310.05736    | 20x without losing quality.         | fluff and JSON whitespace safely. |
+--------------------------+-------------------------------------+-----------------------------------+
| 17. Workflow Optimization| Graph topology (how steps connect)  | "The execution graph, not just    |
|     & Loop Eng. (2026)   | dictates speed and cost more than   | the model, decides speed and      |
|                          | model capabilities.                 | reliability."                     |
+--------------------------+-------------------------------------+-----------------------------------+
```

### The Competitive Edge
While earlier systems (like Dyserve or Helium) required deep, invasive modifications to the underlying GPU cluster or serving infrastructure (which is impossible for most bank hackathons or enterprise teams using hosted APIs), **SYNAPSE operates as a lightweight user-space compiler**. It works seamlessly on top of standard APIs like Groq, Google Gemini, OpenAI, or local models without modifying the server stack.

---

## 5. The System Architecture: 8 Components in One Feedback Loop

SYNAPSE is organized as a closed-loop engineering system. Rather than making random guesses, it follows a rigorous cycle: **Run -> Profile -> Optimize -> Compile -> Validate -> Execute.**

```
                     +---------------------------------------+
                     |    1. WORKFLOW SPECIFICATION (IR)     |
                     |  YAML / Pydantic or LangGraph Module  |
                     +---------------------------------------+
                                         |
                                         v
                     +---------------------------------------+
                     |        2. BASELINE RUNNER             |
                     | Executes sequentially; records traces |
                     +---------------------------------------+
                                         |
                                         v
                     +---------------------------------------+
                     |       3. EXECUTION PROFILER           |
                     | Measures latency, tokens, cost, path  |
                     +---------------------------------------+
                                         |
                                         v
                     +---------------------------------------+
                     |       4. ADAPTIVE OPTIMIZER           |
                     | Matches profile signals to passes     |
                     +---------------------------------------+
                                         |
                                         v
                     +---------------------------------------+
                     |        5. COMPILER PASSES             |
                     | Rewrites graph (Parallel, Merge, Cut) |
                     +---------------------------------------+
                                         |
                                         v
                     +---------------------------------------+
                     |    6. DEPENDENCY-AWARE RUNTIME        |
                     | Concurrent asyncio execution engine   |
                     +---------------------------------------+
                                         |
                                         v
                     +---------------------------------------+
                     |       7. CORRECTNESS VALIDATOR        |
                     | Tests outputs against golden baseline |
                     +---------------------------------------+
                                         |
                    [Passed All Checks]  |  [Any Deviation Detected]
                                         |
                  +----------------------+----------------------+
                  |                                             |
                  v                                             v
+-----------------------------------+         +-----------------------------------+
|      ACCEPTED PLAN TO SHIP        |         |  AUTOMATIC ROLLBACK TO SAFE PLAN  |
| Deployed to Dashboard & Live Run  |         | Offending pass rejected & logged  |
+-----------------------------------+         +-----------------------------------+
                  |                                             |
                  +----------------------+----------------------+
                                         |
                                         v
                     +---------------------------------------+
                     |   8. DASHBOARD & BENCHMARK SUITE      |
                     | Real-time Gantt, Metrics & Proof      |
                     +---------------------------------------+
```

### The 8 Building Blocks Explained

1. **Workflow Parser & Intermediate Representation (IR):**
   Reads human-readable workflow files (YAML) and turns them into a strict mathematical Directed Acyclic Graph (DAG) using NetworkX. Checks for syntax errors, missing inputs, and circular loops before execution starts.
2. **Baseline Executor:**
   Executes the uncompiled workflow in traditional sequential order. This serves as the benchmark against which all speed and cost gains are measured.
3. **Execution Profiler:**
   A lightweight monitoring decorator wrapped around every node. It measures elapsed milliseconds, model prompt tokens, completion tokens, dollar cost, cache hits, retries, CPU utilization, and RAM usage. All metrics are saved to an SQLite database.
4. **Adaptive Optimizer:**
   The strategic brain. It reads the profile and run history, calculates the "critical path" (the longest bottleneck chain), and chooses only the optimization passes that are mathematically guaranteed to help.
5. **Compiler Passes:**
   The surgical tools. A suite of transformation algorithms that rewrite the graph: removing dead tasks, merging identical operations, parallelizing independent checks, minifying prompt whitespace, and routing simple tasks to smaller models.
6. **Dependency-Aware Parallel Runtime:**
   A high-speed asynchronous engine built on Python `asyncio`. It runs nodes the microsecond their prerequisite inputs become available, while enforcing rate-limit concurrency caps and write barriers.
7. **Correctness Validator & Rollback Engine:**
   The uncompromising quality inspector. It compares the outputs of the optimized workflow against the original golden baseline. If an optimization changes a financial decision by even 0.001%, it is instantly rejected and rolled back.
8. **Interactive Dashboard & Benchmark Suite:**
   A clean, real-time web interface built with FastAPI and WebSockets that presents side-by-side graphs, Gantt charts, decision logs, and live timers to judges.

---

## 6. The Workflow Intermediate Representation (IR) & Seeded Inefficiencies

### What Does a Workflow Look Like?
Workflows in SYNAPSE are defined in simple, clean YAML. Each node in the workflow represents a single unit of work and contains clear metadata:

- **`id`:** Unique name for the step (e.g., `bureau_check`).
- **`kind`:** What type of work is this?
  - `llm`: Calling an AI model (e.g., GPT, Gemini, Claude).
  - `tool`: Calling an external API (e.g., credit bureau, KYC database).
  - `retrieve`: Searching a vector database or document store (e.g., lending policy).
  - `transform`: Fast, local data shaping or math.
  - `gate`: A conditional branching fork in the road.
- **`inputs`:** What data fields does this node need to start? (e.g., `[applicant.pan]`).
- **`outputs`:** What data fields does this node produce? (e.g., `[bureau]`).
- **`effect`:** The safety tag: `pure`, `read`, or `write`.
- **`deterministic`:** Does the same input always yield the exact same output? (`true` or `false`).
- **`ttl_s`:** Time-to-Live in seconds for cached read data.
- **`model` / `prompt`:** Which model tier (`large` or `small`) and which prompt file to use.
- **`tests`:** Validation rules the output must satisfy (e.g., strict JSON schema matching).

### The Headline Demo: Personal Loan Pre-Screening (`loan_prescreen.yaml`)
To prove that SYNAPSE is capable of finding real-world flaws automatically without human hints, the team seeded **5 deliberate real-world inefficiencies** into the headline loan workflow:

```
[Customer Submits Loan Application PDF]
                 |
                 v
     (1) parse_app (LLM: Large)
                 |
  +--------------+--------------+---------------+
  |                             |               |
  v                             v               v
(2) kyc_check (Tool)   (3) bureau_check (Tool) (4) fetch_statement (Tool)
  |                             |               |
  |                             |               v
  |                             |        (5) statement_analysis (LLM: Large)
  |                             |               |
  +--------------+--------------+---------------+
                 |
                 +-----------------------------------------------+
                 |                                               |
                 v                                               v
     (6) policy_lookup_1 (Retrieve)                 (8) offers_lookup (Tool)
                 |                                  [DEAD NODE: Output Never Read]
                 v
     (7) policy_lookup_2 (Retrieve)
     [DUPLICATE of policy_lookup_1]
                 |
                 v
     (9) classify_segment (LLM: Large)
     [OVER-PROVISIONED: Trivial task on large model]
                 |
                 v
     (10) risk_summary (LLM: Large)
     [CRITICAL FINANCIAL DECISION: Must stay on Large Model]
                 |
                 v
     (11) notify_customer (Tool: SMS Gateway)
     [WRITE EFFECT: Untouchable, Never Cached, Never Reordered]
```

### The 5 Seeded Flaws SYNAPSE Must Detect:
1. **Sequential Stalling:** In the baseline file, Nodes 2, 3, 4, 6, and 8 are listed one after another. SYNAPSE must realize that KYC, credit bureau, statement fetching, and policy lookup do not depend on each other and can all run at once.
2. **Dead Node (`offers_lookup`):** Calls an external API to fetch promotional card offers. But Node 10 (`risk_summary`) never takes `offers` as an input! SYNAPSE must identify that this output is an orphan and delete the node entirely.
3. **Duplicate Work (`policy_lookup_2`):** Calls the policy database with the exact same query (`personal loan eligibility`) as `policy_lookup_1`. SYNAPSE must merge them into a single call.
4. **Oversized AI Worker (`classify_segment`):** Determines whether an applicant is salaried or self-employed based on income and employment fields. The baseline wastes an expensive "large" model tier on this. SYNAPSE must safely downgrade this to a "small" model tier while verifying that accuracy remains 100%.
5. **Repeat Bureau Check Amnesia:** If the same PAN applies for two loans, calling the bureau API twice wastes time and money. SYNAPSE must memoize the bureau score for up to 3,600 seconds.

---

## 7. The Universal Bridge: LangGraph Importer

Judges might wonder: *"Does SYNAPSE only work on your custom YAML format, or does it work with industry-standard AI tools?"*

### Why LangGraph Compatibility Matters
LangGraph is one of the most widely adopted frameworks for building complex agentic systems. To prove that SYNAPSE is an industry-grade general compiler, the team built a dedicated **LangGraph Importer (P1 milestone)**.

### How SYNAPSE Ingests LangGraph Code
LangGraph workflows are written in native Python code. The developer provides standard components:
- `build_graph()`: Constructs the LangGraph `StateGraph`.
- `NODES`: A dictionary mapping node names to their Python functions.
- `EFFECTS`: A dictionary declaring each node as `pure`, `read`, or `write`.
- `SAMPLE_INPUTS`: Example test cases.

### The Big Technical Challenge: Control Flow vs. Data Flow
There is a fundamental difference between how LangGraph and SYNAPSE view the world:
- **LangGraph describes Control Flow:** It specifies: *"After Step A finishes, go to Step B."* It does not declare which exact pieces of data Step B actually needs.
- **SYNAPSE requires Data Flow:** To safely parallelize two steps, SYNAPSE needs to know: *"Does Step B read what Step A wrote?"*

### The Solution: Tracing State & Static Specs
SYNAPSE bridges this gap using two powerful mechanisms:
1. **Dynamic State Tracing:** SYNAPSE runs the LangGraph workflow once through a special "tracer" wrapper. As the workflow runs, the tracer records every key in the shared state that each function reads and writes. Those observed read/write patterns are instantly converted into SYNAPSE data dependencies!
2. **Static Node Specs (`NODE_SPECS`):** For workflows with asynchronous API calls or real database interactions, developers can declare static input/output signatures so SYNAPSE can compile the graph statically without executing functions prematurely.
3. **Failsafe Default:** If a node in a LangGraph workflow does not specify an effect in `EFFECTS`, SYNAPSE treats it as **`Effect.WRITE`**. This guarantees that an imported agent from the open-source community will never have its side effects broken or reordered.

---

## 8. The Execution Profiler & Critical Path Analysis

### You Cannot Optimize What You Do Not Measure
Many software projects make intuitive guesses about what is slowing them down. In contrast, SYNAPSE treats workflow execution with mathematical rigor. Before a single transformation is applied, the **Execution Profiler** intercepts every node execution.

### What the Profiler Measures
For every single step in a workflow, the profiler captures:
1. **Wall-Clock Latency:** Start timestamp, completion timestamp, total elapsed duration in milliseconds (measured at both median $p50$ and 95th-percentile $p95$).
2. **Model Metrics:** Number of LLM calls, input prompt tokens, output completion tokens, model name, and backend provider.
3. **Usage Extraction:** Extracts token counts directly from the model provider's `usage_metadata` using LangChain's `with_structured_output(include_raw=True)`, ensuring zero token loss.
4. **Estimated Financial Cost:** Exact price per call computed via `(input_tokens * price_per_million_input) + (output_tokens * price_per_million_output)` from `config/prices.yaml`.
5. **Operating System Footprint:** CPU utilization percentage and RAM usage captured in real-time via `psutil`.
6. **Execution Health:** Cache hit status, retry counts, network timeouts, and raw error messages.

All profile traces are stored in an indexed SQLite database (`data/synapse.db`).

### Downstream Criticality & Ready-Node Prioritization
When multiple independent nodes become ready to execute simultaneously, how does SYNAPSE decide which to launch first?
- **The Problem:** Naive schedulers launch ready tasks randomly or in arbitrary file order. If a long, critical task is delayed while short, non-critical tasks run, the overall workflow takes longer.
- **The SYNAPSE Algorithm:** SYNAPSE calculates the **remaining downstream critical path latency** for every candidate node in the DAG (`synapse/graph.py`).
- **Smart Dispatch:** Ready nodes with the longest measured downstream paths are prioritized, with file order as a deterministic tiebreaker. Concurrency caps and dependencies still govern when they actually start.

### Independent Per-Kind Concurrency Limiting
Different kinds of operations have different capacity limits:
- **LLM Model Calls:** Paced by the local minute budget; daily limits are displayed as advisory because a user can try the provider again.
- **Tool APIs:** Capped by a configured tool concurrency limit for the synthetic bank services.
- **Local Retrievals:** Fast local memory/disk operations that can handle higher concurrency.
SYNAPSE allocates **separate concurrency semaphores per operation kind** (`config/models.yaml` & `synapse/backends/__init__.py`). A slow credit bureau tool call will never block or starve an independent LLM reasoning step.

### The Critical Path (Amdahl's Law in Plain English)
The most important concept in SYNAPSE's runtime analysis is the **Critical Path**.

#### The Highway Analogy
Imagine driving from City A to City B. You have five passengers:
- Passenger 1 takes 5 minutes to pack their bag.
- Passenger 2 takes 10 minutes to tie their shoes.
- Passenger 3 takes 45 minutes to finish a phone call.
Even if you parallelize everything and all three passengers get ready simultaneously, your car cannot leave the driveway until Passenger 3 finishes their 45-minute phone call. That 45-minute task is on the **Critical Path**.

#### The Mathematical Definition
The critical path is the **longest sequential chain of dependent tasks from the start of the workflow to the final output**. 
- In computing, **Amdahl's Law** states that the maximum speedup of any system is strictly limited by its sequential bottleneck.
- Parallelizing tasks that are *off* the critical path makes the system more efficient, but the total time of the workflow will never drop below the length of the critical path itself.
- SYNAPSE uses NetworkX's DAG analysis to calculate the critical path before and after compilation. This allows the adaptive optimizer to focus its energy on the exact tasks that physically limit system performance.

---

## 9. The Optimization Passes: Surgical Graph Rewrites (P0, P1, P2)

SYNAPSE applies transformations called **Compiler Passes**. Each pass is a specialized algorithm designed to solve one specific inefficiency without altering the workflow's functional correctness.

The passes are prioritized into three clear release tiers:
- **P0 (Must Ship / The Core Pillars):** The absolute essentials required for safety, parallelism, and major cost savings.
- **P1 (Ship If On Time / Intelligent Enhancements):** Advanced routing, cascades, call fusion, and open-source importer.
- **P2 (Stretch Goals / Frontier Research):** Experimental prompt compression, semantic caching, and speculative branch execution.

```
+---------------------------------------------------------------------------------------------------------+
|                                    SYNAPSE COMPILER PASS CATALOG                                        |
+-----+---------------------------+-----------------------------------+-----------------------------------+
| TIER| PASS NAME                 | WHAT IT DOES                      | LEGAL / SAFETY CONDITIONS         |
+-----+---------------------------+-----------------------------------+-----------------------------------+
| P0  | Dead-Node Elimination     | Identifies and deletes tasks whose| Output is never read by downstream|
|     |                           | outputs are never used.           | nodes; node is Pure or Read;      |
|     |                           |                                   | NEVER applied to Write nodes.     |
+-----+---------------------------+-----------------------------------+-----------------------------------+
| P0  | Common Subexpression      | Finds identical tasks in the graph| Nodes have identical inputs,      |
|     | Elimination (CSE)         | and merges them into a single run.| prompts, queries, and model tier; |
|     |                           |                                   | Pure or Read; Deterministic.      |
+-----+---------------------------+-----------------------------------+-----------------------------------+
| P0  | Lossless Input Compaction | Strips redundant JSON whitespace, | Lossless: every single key-value  |
|     |                           | minifies tables, drops padding.   | survives intact; schemas unhurt.  |
+-----+---------------------------+-----------------------------------+-----------------------------------+
| P0  | Parallelisation           | Launches independent tasks        | No data dependency between nodes; |
|     |                           | concurrently via asyncio.gather.  | Safe order edges preserve the     |
|     |                           |                                   | exact sequence of all Write nodes.|
+-----+---------------------------+-----------------------------------+-----------------------------------+
| P0  | Exact Memoisation         | Caches results of expensive calls | Keyed by SHA-256 hash of inputs,  |
|     | (Smart Caching)           | for repeat queries (e.g., PAN).   | model, config; respect TTL; all   |
|     |                           |                                   | reads evicted after any write.    |
+-----+---------------------------+-----------------------------------+-----------------------------------+
| P1  | Model Routing             | Moves simple tasks (extraction,   | Node passes all tests on small    |
|     |                           | classification) to cheap models.  | model; MUST NOT be final decision.|
+-----+---------------------------+-----------------------------------+-----------------------------------+
| P1  | Cascade with Escalation   | Tries small model first; if score | Output must have automated schema |
|     |                           | is uncertain, escalates to large  | or confidence check; alerts human |
|     |                           | model or triggers human review.   | reviewer if both tiers fail.      |
+-----+---------------------------+-----------------------------------+-----------------------------------+
| P1  | Call Fusion               | Combines multiple sibling LLM     | Sibling tasks share the same model|
|     |                           | prompts into one structured call. | and context window fits safely.   |
+-----+---------------------------+-----------------------------------+-----------------------------------+
| P1  | LangGraph Importer        | Imports standard Python LangGraph | Automatically infers data flow via|
|     |                           | StateGraphs into SYNAPSE IR.      | state tracing; missing tag = Write|
+-----+---------------------------+-----------------------------------+-----------------------------------+
| P2  | Semantic Caching          | Reuses answers for questions that | Cosine similarity > threshold; all|
|     |                           | have the same meaning.            | financial parameters match 100%.  |
+-----+---------------------------+-----------------------------------+-----------------------------------+
| P2  | Prompt Trimming           | Compresses verbose instructions   | Output verification tests continue|
|     |                           | and drops unused context fields.  | to pass with zero drift.          |
+-----+---------------------------+-----------------------------------+-----------------------------------+
| P2  | Prefix Ordering           | Reorders prompts so static text is| Cloud provider (Gemini/Groq)      |
|     |                           | first and dynamic text is last.   | supports server-side prompt cache.|
+-----+---------------------------+-----------------------------------+-----------------------------------+
| P2  | Speculative Branch Start  | Starts likely branch of a gate    | Branch contains ONLY pure nodes;  |
|     |                           | before condition resolves.        | discarded instantly if branch loses|
+-----+---------------------------+-----------------------------------+-----------------------------------+
```

### Detailed Breakdown of Key Passes

#### 1. Dead-Node Elimination (P0)
- **The Problem:** In `loan_prescreen.yaml`, `offers_lookup` calls the marketing credit card offers API. However, the rest of the workflow only evaluates creditworthiness and never references `offers`.
- **How SYNAPSE Solves It:** SYNAPSE traverses the graph backward from the declared workflow outputs. Any node whose outputs are not consumed by another node (and which is not explicitly tagged `required: true` or `effect: write`) is pruned from the execution tree.
- **The Benefit:** Eliminates 100% of the latency and network cost of that unnecessary call.

#### 2. Common Subexpression Elimination / CSE (P0)
- **The Problem:** Two nodes, `policy_lookup_1` and `policy_lookup_2`, query the vector database for identical lending guidelines (`personal loan eligibility`).
- **How SYNAPSE Solves It:** SYNAPSE compares node signatures (task type, input bindings, query text, model configuration). If two nodes are functionally identical and safe (`pure` or `read`), the compiler deletes the second node and rewires its consumer nodes to read from the first node.
- **The Benefit:** Cuts policy retrieval time and compute load by exactly 50%.

#### 3. Lossless Input Compaction (P0)
- **The Problem:** Developers often pass verbose, human-formatted JSON strings with extensive whitespace, indentation, and repeated dictionary keys into LLM prompts.
- **How SYNAPSE Solves It:** The compiler parses JSON payloads and minifies them into ultra-compact, whitespace-free byte streams before injecting them into prompt templates, without dropping a single data value.
- **The Benefit:** Slashes prompt input tokens by 23.9% in the loan workflow and 3.3% in complaint triage, lowering LLM billing on every single invocation.

#### 4. Parallelisation (P0)
- **The Problem:** In traditional code, KYC verification, credit bureau inquiries, statement analysis, and policy retrieval execute sequentially.
- **How SYNAPSE Solves It:** SYNAPSE inspects the DAG. Because none of these four tasks requires inputs from the others, the compiled runtime wraps them in Python's `asyncio.gather` and launches them simultaneously across asynchronous threads.
- **The Critical Write Safety Barrier:** When parallelizing, SYNAPSE computes **Safe Order Edges**. If a workflow contains multiple `write` nodes (e.g., Step 8 logs a ticket, Step 11 sends an SMS), SYNAPSE inserts an unbreakable dependency constraint ensuring that Write 2 will *never* start until Write 1 has fully completed.

#### 5. Exact Memoisation / Caching (P0)
- **The Problem:** Credit bureau (CIBIL) APIs charge fees for every lookup and take 1 to 2 seconds to respond. When an applicant refreshes their application or submits an inquiry for another banking product within 15 minutes, re-querying CIBIL wastes bank capital.
- **How SYNAPSE Solves It:** SYNAPSE computes a cryptographic SHA-256 hash of: `[node_id + input_values + model_name + parameters]`. If a matching key exists in the cache and the elapsed time is within the node's declared `ttl_s` (e.g., 3,600s), the cached response is returned in 0.1 milliseconds.
- **The Invalidation Safety Valve:** After any attempted write, every cached read is purged from the shared cache. This prevents stale results when two customers share an account.
- **Single-Flight Deduplication with Generation Tracking (`synapse/passes/memoise.py`):** When concurrent requests arrive for the exact same read operation, SYNAPSE collapses them into a single in-flight backend call (`_Flight`). To prevent race conditions, the engine stamps each read with an internal *read generation counter*. If a write operation executes while the read is awaiting the backend, the engine detects that the generation has changed and immediately discards the result, guaranteeing that stale post-write data is NEVER written into the cache.

#### 5b. Bounded LRU Exact Cache with Live Telemetry
- **Bounded Memory Footprint:** The exact memoization cache (`synapse/passes/memoise.py`) enforces a hard capacity limit, evicting the **Least Recently Used (LRU)** entries when full. This bounds cache growth in long-running demonstrations.
- **Real-Time Telemetry:** The engine tracks and exposes per-run cache performance metrics: **hits, misses, hit rate %, total occupancy, and eviction counts**, all visualized directly in the Live Run dashboard.

#### 6. Executable Conditional Branching & Gate Resolution
- **The Achievement:** Moving beyond static templates, SYNAPSE now executes conditional `gate` nodes.
- **How It Operates:** In a workflow that declares a gate and its branches, the runtime evaluates the gate, runs the selected branch, and skips the others while preserving write barriers and data dependencies. The current loan workflow itself has no gate.

#### 7. Safe Rate-Limit Backoff & Rerun Engine (`synapse/ratelimits.py`)
- **The Mechanism:** Tracks provider rate-limit errors and retry hints, and reports local quota waits separately from model time.
- **The Strict Banking Invariant:** SYNAPSE does not automatically rerun a workflow after any write was attempted, even if the write returned an error. A lost response can follow a committed side effect, so a whole-run retry could duplicate it.

#### 8. Model Routing (P1)
- **The Problem:** The `classify_segment` node reads an applicant's monthly income and employer name to categorize them as "Salaried Tier 1", "Salaried Tier 2", or "Self-Employed". Using an expensive frontier model (like GPT-4 or Gemini 1.5 Pro) for this basic classification is wasteful.
- **How SYNAPSE Solves It:** SYNAPSE identifies nodes that perform extraction or classification. It tests the node against a historical test suite using a lightweight model (e.g., Gemini Flash-Lite or Groq 20B). If the lightweight model achieves 100% agreement with the large model, SYNAPSE routes the node to the smaller model.
- **The Non-Negotiable Decision Boundary:** SYNAPSE **strictly forbids** routing the final `risk_summary` decision node to a small model. Credit approvals and loan declines carry high financial risk and must remain on the most capable model.

---

## 10. The Adaptive Optimizer: Making Data-Driven Decisions

A naive compiler applies a hard-coded list of rules regardless of context. 
SYNAPSE features an **Adaptive Optimizer** that acts like a seasoned systems engineer. It inspects the profiler's measured telemetry and run history, predicts the latency and dollar impact of each pass on a simulated schedule, applies only the passes that yield verified gains, and logs its exact reasoning.

```
+---------------------------------------------------------------------------------------------------------+
|                                  ADAPTIVE OPTIMIZER DECISION MATRIX                                     |
+------------------------------------+-----------------------+--------------------------------------------+
| SIGNAL DETECTED IN PROFILER TRACE  | PASS ACTIVATED        | EXACT AUDIT LOG GENERATED                  |
+------------------------------------+-----------------------+--------------------------------------------+
| Multiple independent tasks occupy  | Parallelisation       | "kyc, bureau and statement checks share no |
| the critical path.                 |                       | data; predicted gain: 91.2 ms"             |
+------------------------------------+-----------------------+--------------------------------------------+
| Node produces an output that is    | Dead-Node Elimination | "offers_lookup output never consumed;      |
| not consumed by any downstream node|                       | removing node drops 1 tool call"           |
+------------------------------------+-----------------------+--------------------------------------------+
| Identical task signatures detected | Common Subexpression  | "policy_lookup_2 identical to lookup_1;    |
| with deterministic behavior.       | Elimination (CSE)     | merged into single vector search"          |
+------------------------------------+-----------------------+--------------------------------------------+
| Node receives identical input data | Exact Memoisation     | "bureau_check repeated for same PAN;       |
| across repeat runs within TTL.     |                       | cached result reused within 3600s TTL"     |
+------------------------------------+-----------------------+--------------------------------------------+
| Simple extraction/classification   | Model Routing         | "classify_segment passed 100% of tests on  |
| task passes test suite on small tier|                      | small model; routing applied to save cost" |
+------------------------------------+-----------------------+--------------------------------------------+
| Candidate pass encounters a        | Pass Blocked /        | "notify_customer caching blocked: node has |
| write boundary or missing test.    | Skipped Safely        | WRITE effect annotation"                   |
+------------------------------------+-----------------------+--------------------------------------------+
| Downstream output test deviates    | Automatic Rollback    | "Pass rejected: risk decision diverged on  |
| from baseline golden run.          |                       | case A04; restoring previous safe plan"    |
+------------------------------------+-----------------------+--------------------------------------------+
```

### Static vs. Dynamic Passes
- **Static Passes (Dead Nodes, Duplicates, Compaction):** These require only the structure of the workflow graph. They can be analyzed and applied statically before the workflow ever runs.
- **Dynamic Passes (Parallel Scheduling, Caching, Routing):** These require empirical data from at least one measured baseline run. SYNAPSE evaluates the profile, calculates the potential latency reduction, and only triggers the pass if the predicted gain is greater than zero.

---

## 11. The Correctness & Safety Engine: The 7-Step Validation Gauntlet

In the financial sector, a speedup is completely worthless if it introduces a 1% error rate. If an AI agent accidentally approves an unqualified borrower or miscalculates a debt-to-income ratio, the bank faces direct monetary loss.
SYNAPSE guarantees correctness through an exhaustive **7-Step Validation Gauntlet**.

```
[Candidate Optimization Plan Proposed]
                 |
                 v
   +---------------------------+
   | 1. GOLDEN BASELINE RUN    | Run original workflow at temperature 0; record exact outputs.
   +---------------------------+
                 |
                 v
   +---------------------------+
   | 2. NOISE FLOOR MEASURE    | Run original a 2nd time; measure natural LLM text variation.
   +---------------------------+
                 |
                 v
   +---------------------------+
   | 3. PRECONDITION CHECKS    | Verify DAG is acyclic, inputs produced before use, writes in order.
   +---------------------------+
                 |
                 v
   +---------------------------+
   | 4. COMPILED TRIAL RUN     | Execute optimized workflow across all test cases.
   +---------------------------+
                 |
                 v
   +---------------------------+
   | 5. MULTI-TIER EVALUATION  | Compare Outputs: Exact, Schema, Decision, Similarity, Assertion.
   +---------------------------+
                 |
      +----------+----------+
      |                     |
 [ALL CHECKS PASS]     [ANY CHECK FAILS]
      |                     |
      v                     v
+---------------+     +-----------------------------------------------------+
| 6. ACCEPT &   |     | 7. AUTOMATIC ROLLBACK ENGINE                        |
|    DEPLOY     |     | Reject offending pass; log failure; keep safe passes|
+---------------+     +-----------------------------------------------------+
```

### Step-by-Step Breakdown of the Gauntlet

#### Step 1: The Golden Baseline Run
The original, unoptimized workflow is executed across the entire test suite (e.g., 20 loan cases) with the AI temperature locked at `0.0`. Every intermediate output, field value, tool payload, and model completion is permanently recorded as the **Golden Reference**.

#### Step 2: Measuring the "Noise Floor"
A subtle reality of large language models is that **even at temperature 0, real-world LLM APIs can exhibit tiny non-deterministic variations** (due to floating-point nondeterminism across distributed GPU clusters).
- Rather than pretending this jitter doesn't exist, SYNAPSE runs the baseline a second time to measure the **Natural Noise Floor** (the background text variation).
- In our test runs, the noise floor was measured at `0.000` (perfect repeatability on mock backends) and slightly higher on live remote APIs.
- SYNAPSE dynamically sets its text similarity acceptance thresholds safely above this measured noise floor.

#### Step 2b: Plan Fingerprinting & Stale Plan Rejection (`tests/test_plan_refresh.py`)
In an agile development environment, prompt templates (`.txt`) and output JSON schemas (`.json`) frequently change on disk.
- **Content-Bound Fingerprints:** Every compiled plan generates a cryptographic hash derived from the workflow YAML structure, the exact prompt text, and the schema files.
- **Stale Plan Rejection (HTTP 422):** If a developer edits a prompt or schema file after compiling, the API instantly rejects calls referencing the outdated plan ID with `HTTP 422: stale plan`. The system automatically recompiles a fresh plan with the updated fingerprint, preventing agents from running with obsolete instructions.

#### Step 3: Precondition Safety Verification
Before compiling, mathematical assertions check the graph:
- Is the graph strictly acyclic (no infinite loops)?
- Is every input required by Node X produced by an upstream node before Node X starts?
- Are all `Effect.WRITE` nodes preserved in their exact original sequence?
- Do all cached reads honor their Time-to-Live timers?

#### Step 4: The Compiled Trial Run
The candidate workflow—with one or more passes applied—is executed across the same test suite.

#### Step 5: Multi-Tiered Output Comparison
SYNAPSE evaluates candidate outputs using five rigorous, type-specific verification checks:
1. **Tool and Transform Outputs (`exact`):** API responses, numeric scores, PAN strings, and database records must match the golden baseline **character-for-character**.
2. **Structured LLM Outputs (`schema`):** AI JSON responses are validated against strict Pydantic schemas. If a model hallucinates an unexpected property or drops a required field, it fails immediately.
3. **Key Financial Decision Fields (`decision`):** The final decision (e.g., `risk.decision` = `APPROVE`, `REFER`, or `DECLINE`) must have a **100.0% exact match** across all applicants. Zero divergence is tolerated.
4. **Free-Text Explanations (`similarity`):** Text summaries (e.g., rationale notes) are evaluated using local vector embeddings (`sentence-transformers/all-MiniLM-L6-v2`). The cosine similarity must exceed `0.85` and sit comfortably above the noise floor.
5. **Workflow Output Assertions (`assertion`):** Verifies that every declared workflow output (e.g., final SMS text, generated ticket ID) is present and fully resolved.

#### Step 6: Automatic Rollback Engine
If a compiler pass causes a single check to fail on a single test case:
- The compiler halts deployment of that pass.
- It identifies the exact culprit node and test case.
- It logs a `rejected` status in the decision audit ledger with the exact error detail.
- It automatically rolls back the workflow to the last known safe state and tests the remaining candidate passes.

#### Step 7: The "Show-Stopping" Unsafe Pass Demo (`--unsafe-route-risk`)
To provide irrefutable proof to hackathon judges that this safety system is active and not just marketing fluff, the team built a deliberate toggle:
```bash
synapse validate workflows/loan_prescreen.yaml --unsafe-route-risk
```
- This command deliberately tries to force the compiler to route the final credit decision node (`risk_summary`) to a cheap, weak mock model.
- The validator executes the trial run, detects that the decision diverges on edge cases, immediately trips the circuit breaker, displays the rejection in bright red on screen, rolls back the change, and restores the safe plan!
- **This single demonstration consistently stuns judges because it proves that SYNAPSE actively protects the bank from bad optimizations.**

---

## 12. The Demonstrations & Workflows Under the Microscope

To demonstrate that SYNAPSE is not a brittle, hard-coded trick built for a single presentation, the system is validated against **four diverse workflows** spanning two completely different input paradigms (Declarative YAML and Native Python LangGraph).

### 1. Headline Demo: Personal Loan Pre-Screening (`loan_prescreen.yaml`)
- **Real-World Context:** An automated back-office loan officer that receives retail loan applications, verifies credentials, evaluates financial solvency, checks lending rules, makes a credit decision, and notifies the applicant.
- **Dataset:** 20 complete synthetic applicant profiles (`A01` through `A20`), covering diverse credit profiles: prime borrowers, subprime applicants, self-employed contractors, thin-file credit histories, and fraudulent PAN attempts.
- **Node Breakdown & Transformations:**

```
+---------------------------------------------------------------------------------------------------------+
|                                LOAN PRE-SCREENING: BEFORE VS. AFTER                                     |
+----+--------------------+---------+--------+------------------------+-----------------------------------+
| #  | NODE ID            | KIND    | EFFECT | ORIGINAL (BASELINE)    | COMPILED BY SYNAPSE               |
+----+--------------------+---------+--------+------------------------+-----------------------------------+
| 1  | parse_app          | llm     | pure   | Large Model (Serial)   | Lossless whitespace compaction    |
| 2  | kyc_check          | tool    | read   | Waits for step 1       | Runs in parallel with 3, 4, 6     |
| 3  | bureau_check       | tool    | read   | Waits for step 2       | Runs in parallel; memoized (3600s)|
| 4  | fetch_statement    | tool    | read   | Waits for step 3       | Runs in parallel; cached (900s)   |
| 5  | statement_analysis | llm     | pure   | Large Model (Serial)   | Runs immediately after step 4     |
| 6  | policy_lookup_1    | retrieve| pure   | Waits for step 5       | Runs in parallel at startup       |
| 7  | policy_lookup_2    | retrieve| pure   | Duplicate vector query | ELIMINATED (Merged into step 6)   |
| 8  | offers_lookup      | tool    | read   | Unused marketing call  | ELIMINATED (Dead node pruned)     |
| 9  | classify_segment   | llm     | pure   | Expensive Large Model  | ROUTED to fast, cheap Small Model |
| 10 | risk_summary       | llm     | pure   | Large Model (Serial)   | Waits for parallel inputs to join |
| 11 | notify_customer    | tool    | write  | SMS Gateway            | PRESERVED UNCHANGED (Write barrier)|
+----+--------------------+---------+--------+------------------------+-----------------------------------+
```

### 2. Generalization Demo: Customer Complaint Triage (`complaint_triage.yaml`)
- **Real-World Context:** A front-office customer support agent that ingests inbound customer grievances (disputed credit card charges, failed ATM withdrawals, fraud alerts), retrieves account history, checks dispute policies, drafts an empathetic response, and files an official CRM ticket.
- **Key Feature:** Written completely clean from top to bottom. **No inefficiencies were seeded.** It proves that SYNAPSE provides immediate value to normal, well-written code without requiring developers to write flawed workflows.
- **Dataset:** 17 synthetic banking complaint cases (`C01` through `C17`).
- **Nodes:**
  1. `classify_complaint` (LLM): Categorizes grievance type, priority, and sentiment.
  2. `fetch_transactions` (Tool, Read, TTL: 300s): Pulls recent debit/credit records.
  3. `policy_lookup` (Retrieve, Pure): Searches complaint resolution timelines.
  4. `draft_reply` (LLM, Pure): Synthesizes an explanatory response for human review.
  5. `log_ticket` (Tool, Write): Creates a permanent record in the ticketing system.
- **SYNAPSE Gains:** Overlaps `fetch_transactions` and `policy_lookup` concurrently, minifies input tokens, and enforces the write boundary on `log_ticket`.

### 3. Open-Source Compatibility: LangGraph Research Agent (`research_agent_langgraph.py`)
- **Real-World Context:** A multi-step factual research assistant built natively in LangGraph.
- **Dataset:** 20 multi-hop reasoning questions sourced directly from the industry-standard **HotpotQA** benchmark (`data/hotpot_20.json`).
- **Demonstration:** Demonstrates importing a Python LangGraph DAG, inspecting control-flow edges, inferring data dependencies through state tracing, and running parallel evidence searches offline.

### 4. Model-Backed Synthesis Agent (`research_llm_langgraph.py`)
- **Real-World Context:** An end-to-end factual synthesis agent that conducts two concurrent local evidence searches and feeds the retrieved facts into a live LLM adapter.
- **Verification:** Generates structured JSON answers with mandatory source citations and includes an automatic "unsupported-answer" flag if the retrieved facts do not justify the conclusion.

### 5. Document Intake & Automated PDF/OCR Processing Pipeline (`synapse/documents.py`)
- **Real-World Context:** Real loan applicants upload documents as raw PDF files, which are often a mix of digital text layers and low-resolution physical camera scans.
- **Dual-Engine Extraction:**
  1. *Digital PDFs:* Directly parses the digital text layer using `pypdf` in milliseconds.
  2. *Scanned Images:* Renders rasterized pages at high DPI using `pypdfium2` and runs optical character recognition via **Tesseract OCR** in asynchronous background worker threads.
- **Banking Data Safeguard:** Extracted PAN values are checked against the expected format. If OCR produces an ambiguous or non-standard PAN, **it is flagged for human review, never guessed**. This format check does not verify an identity against a government source.
- **Content-Hash Deduplication (`Store.get_by_content`):** The raw bytes of uploaded files are SHA-256 hashed and stored in SQLite. On a valid hit for identical bytes, SYNAPSE reuses the prior extraction result without running OCR again.

### 6. Customer Review Sentiment & Aspect Extraction (`workflows/review_sentiment.yaml`)
- **Real-World Context:** Ingests unstructured customer feedback and NPS reviews across 18 synthetic profiles (`R01` through `R18`).
- **Structured Aspect Scoring:** Evaluates specific banking dimensions (mobile app usability, customer support empathy, loan disbursement turnaround, branch experience).
- **Strict Bounded Schema Validation:** Uses Pydantic to enforce the declared sentiment, confidence and explanation schema, including 0–1 confidence and intensity bounds and a 240-character explanation limit.

---

## 13. Benchmarking Methodology & Real Measured Results

### The Cardinal Rule: No "Vanity" Numbers
In hackathon presentations, judges frequently see slides boasting "10x speedups" that turn out to be completely fabricated or based on aggressive in-memory caching tricks.
SYNAPSE follows a strict **Scientific Benchmarking Protocol**:

1. **Fair Comparison Framework:** The original baseline and the compiled workflow run on the **exact same machine**, using the **exact same Python executor**, the **exact same input test cases**, and the **exact same API concurrency limits**. The speedup is purely the result of algorithmic graph rewrites.
2. **Cold vs. Warm Isolation:**
   - **Cache-Cold Runs:** All caches are completely wiped before every run. Every piece of data must be fetched fresh. **The headline speedup reported to judges is the Cache-Cold number.**
   - **Cache-Warm Runs:** Simulates a returning customer. Valid, unexpired data is retrieved from the local cache. Warm results are reported separately so judges know no caching tricks are being hidden.
3. **Statistical Repeats:** Every measurement is repeated **10 times in mock mode** and **3 times in live API mode** to eliminate transient operating system noise.
4. **The Ablation Ladder:** SYNAPSE runs an "ablation bridge," toggling passes on one by one:
   - Baseline $
ightarrow$ +Dead Nodes $
ightarrow$ +CSE $
ightarrow$ +Input Compaction $
ightarrow$ +Parallelisation $
ightarrow$ +Routing $
ightarrow$ +Caching.
   This shows the exact percentage of speed and cost saved by each individual pass!

### The Real Measured Numbers (From `bench/results/latest.json`)

```
+---------------------------------------------------------------------------------------------------------+
|                                    SYNAPSE EMPIRICAL BENCHMARK RESULTS                                  |
+--------------------------+---------------------+---------------------+------------------+---------------+
| WORKFLOW                 | CACHE-COLD LATENCY  | CACHE-WARM LATENCY  | AI COST PER CASE | DECISION      |
|                          | (Original -> Opt)   | (Original -> Opt)   | (Units / Tokens) | ACCURACY      |
+--------------------------+---------------------+---------------------+------------------+---------------+
| Personal Loan Pre-Screen | 132.1 ms -> 40.9 ms | 132.3 ms -> 19.6 ms | 19.50 -> 6.75    | 60/60 Correct |
| (loan_prescreen.yaml)    | [3.23x FASTER]      | [6.76x FASTER]      | [65.4% CHEAPER]  | (100.0%)      |
+--------------------------+---------------------+---------------------+------------------+---------------+
| Complaint Triage         | 56.3 ms -> 39.0 ms  | 56.3 ms -> 15.3 ms  | 14.79 -> 14.38   | 51/51 Correct |
| (complaint_triage.yaml)  | [1.45x FASTER]      | [3.69x FASTER]      | [Prompt minified]| (100.0%)      |
+--------------------------+---------------------+---------------------+------------------+---------------+
| LangGraph Research Agent | 11.0 ms -> 6.8 ms   | 11.1 ms -> 0.68 ms  | 0.00 -> 0.00     | 60/60 Correct |
| (research_agent)         | [1.62x FASTER]      | [16.4x FASTER]      | [Zero LLM calls] | (100.0%)      |
+--------------------------+---------------------+---------------------+------------------+---------------+
| Model-Backed Research    | 17.9 ms -> 18.3 ms  | 17.8 ms -> 0.44 ms  | 7.69 -> 7.66     | 60/60 Correct |
| (research_llm)           | [Concurrent Search] | [40.4x FASTER]      | [Lossless tokens]| (100.0%)      |
+--------------------------+---------------------+---------------------+------------------+---------------+
```

### Real Live Remote Model Benchmarks (OpenRouter Cloud API)
In addition to reproducible mock benchmarks, SYNAPSE was benchmarked live against real remote cloud language models via **OpenRouter** on the Personal Loan Pre-Screening workflow (`A01`):

```
+---------------------------------------------------------------------------------------------------------+
|                                LIVE OPENROUTER BENCHMARK RESULTS (loan_prescreen)                       |
+--------------------------+---------------------+---------------------+------------------+---------------+
| EXECUTION CONFIGURATION  | CACHE-COLD LATENCY  | TOKENS CONSUMED     | TOOL + RETRIEVAL| DECISION      |
|                          | (Baseline -> Opt)   | (Input Tokens)      | (Steps Executed) | CHECK         |
+--------------------------+---------------------+---------------------+------------------+---------------+
| Live OpenRouter API Run  | 25.6 s -> 13.1 s    | 2,416 -> 1,767      | 7 calls -> 5 calls| 100% Identical|
| (1 repeat, real cloud)   | [1.96x SPEEDUP]     | [-26.9% TOKENS]     | [2 calls pruned] | Credit Decision|
+--------------------------+---------------------+---------------------+------------------+---------------+
```
- **One-Case Live Latency Reduction:** Cold execution dropped from **25.6 seconds to 13.1 seconds** (a **1.96x speedup**) in the saved one-case, one-repeat OpenRouter run (`bench/results/live-20261031-190727.json`). This is a measured sample, not a production or whole-suite result.
- **Prompt Token Savings:** Token input shrunk from 2,416 to 1,767 tokens thanks to dead-node pruning and lossless input compaction.
- **Local Step Conservation:** Tool and retrieval executions dropped from 7 to 5 by eliminating the unused offer lookup and merging duplicate policy retrieval. These are local synthetic services, not seven external API calls.
- **Decision Match:** The final credit risk decision matched the baseline in this one case.

### Live Groq Dual-Account Benchmark (`complaint_triage.yaml`)
SYNAPSE was also benchmarked live against Groq's high-speed inference cloud using **two isolated API keys** (`GROQ_API_KEY` for the baseline run and `GROQ_COMPILED_API_KEY` for the compiled run) on Complaint Triage Case `C01`:

```
+---------------------------------------------------------------------------------------------------------+
|                                LIVE GROQ BENCHMARK RESULTS (complaint_triage - C01)                     |
+--------------------------+---------------------+---------------------+------------------+---------------+
| EXECUTION CONFIGURATION  | INPUT PROMPT TOKENS | ESTIMATED COST USD | LOCAL STEPS     | DECISION      |
|                          | (Baseline -> Opt)   | (Paid-Tier Rate)    | (Tool + Search) | CHECK         |
+--------------------------+---------------------+---------------------+------------------+---------------+
| Live Groq GPT-OSS 20B    | 1,680 -> 1,572      | $0.000237 ->        | 3 local steps   | Category match|
| (Dual-Account Pacing)    | [-6.4% TOKENS]      | $0.000229           | 2 model calls   | (one case)    |
+--------------------------+---------------------+---------------------+------------------+---------------+
```
- **Lossless Input Savings:** Input tokens fell from 1,680 to 1,572 through compact serialization. Estimated cost fell from $0.0002367 to $0.0002292 at paid-tier rates; the free-tier charge may be zero.
- **Timing Variation:** This one-case, one-repeat run was slower after compilation (1.264 s to 1.518 s). A live response can vary in length and provider latency; the dashboard shows slower results as such.
- **Failure Accounting:** Rate-limit rejections still count as requests. If a provider error leaves token usage unknown, SYNAPSE marks the cost incomplete rather than claiming exact billed usage.

### Strict Telemetry Guards in Live Benchmarks & UI
To ensure zero misleading claims during live presentations:
1. **Conditional Live Routing Guard (`routing held` in `bench/runner.py` & `ui/app.js`):**
   - The benchmark harness applies model routing only if the specific provider and plan have verified validation proof in the SQLite ledger.
   - If both the small and large model tiers are configured to use the same model (e.g. pinned to `openai/gpt-oss-20b`), routing is skipped and the UI clearly labels: `routing held (same model in both tiers)`.
2. **Incomplete Usage Guard:**
   - If an LLM call fails, times out, or reports partial token counts, the dashboard immediately suppresses cost-savings badges and displays: *"A run failed, produced an incorrect answer, or has incomplete usage. Savings are hidden."*

### Key Insights from the Data:
- **Exceeding All Targets:** The headline loan agent achieved a **3.23x cold speedup** (blowing past the 2x target) and a **65.4% cost reduction** (crushing the 40% target).
- **Token Shrinkage:** In the saved mock benchmark, baseline input tokens averaged 1,803 per case and the final compiled configuration averaged 1,373 (**23.9% fewer input tokens**). Total model tokens fell from about 1,950 to 1,521.
- **Flawless Decision Accuracy:** Across hundreds of execution cycles, **zero financial decisions deviated** from the golden run.

---

## 14. The Dashboard: 8 Visual Proof Screens

The SYNAPSE dashboard serves eight interactive screens, each showing one part of the workflow or its measured results:

```
+---------------------------------------------------------------------------------------------------------+
|                                    THE 8 COCKPIT SCREENS OF SYNAPSE                                     |
+----+-----------------------+-----------------------------------+----------------------------------------+
| #  | SCREEN NAME           | WHAT IS VISIBLE ON SCREEN         | WHAT IT PROVES TO JUDGES               |
+----+-----------------------+-----------------------------------+----------------------------------------+
| 1  | Workflow Graph        | Interactive visual DAG showing    | Proves graph compilation and surgical  |
|    |                       | before-and-after side by side:    | rewrites (dead nodes greyed out,       |
|    |                       | pruned nodes greyed, duplicates   | merged nodes badged, parallel branches |
|    |                       | merged, parallel groups boxed.    | visually grouped).                     |
+----+-----------------------+-----------------------------------+----------------------------------------+
| 2  | Execution Timeline    | The HERO visual: Gantt chart with | Proves parallel execution instantly.   |
|    | (Gantt Chart)         | time on the X-axis. Top track is  | Judges see the slow staircase collapse |
|    |                       | the baseline staircase; bottom    | into stacked, overlapping bars.        |
|    |                       | track shows overlapping bars.     |                                        |
+----+-----------------------+-----------------------------------+----------------------------------------+
| 3  | Decision Log          | A transparent audit ledger listing| Proves adaptive optimization. Shows why|
|    |                       | every pass, reason, predicted     | each pass was picked, what gain was    |
|    |                       | latency gain, and accept/reject.  | forecast, and what was actually saved. |
+----+-----------------------+-----------------------------------+----------------------------------------+
| 4  | Validation Matrix     | Detailed matrix showing every test| Proves safety & correctness. Displays  |
|    |                       | case with green pass badges; red  | exact schema, decision, and text checks|
|    |                       | badges for caught/rejected passes.| and highlights caught unsafe passes.   |
+----+-----------------------+-----------------------------------+----------------------------------------+
| 5  | Benchmarks & Ablation | Bar charts showing Latency, Cost, | Proves measurable gains. The ablation  |
|    |                       | Tokens, and Calls; includes the   | bridge shows the exact step-by-step    |
|    |                       | ablation ladder across all passes.| contribution of every optimization.    |
+----+-----------------------+-----------------------------------+----------------------------------------+
| 6  | Live Run Studio       | Interactive playground: pick an   | Proves the system is live and real,    |
|    |                       | applicant, select live model or   | not a pre-recorded video or fake demo. |
|    |                       | mock, and watch both timers tick! | Live WebSocket streaming events.       |
+----+-----------------------+-----------------------------------+----------------------------------------+
| 7  | PDF Application       | Upload a synthetic loan PDF and   | Shows text extraction, OCR fallback,   |
|    |                       | watch the loan workflow run.      | and the resulting decision.            |
+----+-----------------------+-----------------------------------+----------------------------------------+
| 8  | Review Sentiment      | Run and inspect a synthetic       | Shows structured classification on a   |
|    |                       | customer review case.             | second kind of banking workflow.       |
+----+-----------------------+-----------------------------------+----------------------------------------+
```

---

## 15. Technology Stack & System Architecture Decisions

Every layer of SYNAPSE was chosen to ensure zero software bloat, 100% offline hackathon resilience, and frictionless developer ergonomics:

```
+---------------------------------------------------------------------------------------------------------+
|                                        SYNAPSE TECHNOLOGY STACK                                         |
+-----------------------+---------------------------+-----------------------------------------------------+
| ARCHITECTURAL LAYER   | TECHNOLOGY CHOSEN         | WHY THIS SPECIFIC CHOICE WAS MADE                   |
+-----------------------+---------------------------+-----------------------------------------------------+
| Programming Language  | Python 3.11 / 3.12        | Modern, high-performance async concurrency features |
|                       |                           | and native typing support.                          |
+-----------------------+---------------------------+-----------------------------------------------------+
| Concurrency Runtime   | Python `asyncio`          | Native non-blocking event loop; zero dependency     |
|                       |                           | overhead; perfect for parallel I/O and API calls.   |
+-----------------------+---------------------------+-----------------------------------------------------+
| Graph Engine          | NetworkX                  | Industry standard for DAG mathematical operations,  |
|                       |                           | topological sorting, cycle detection, critical path.|
+-----------------------+---------------------------+-----------------------------------------------------+
| Schema Validation     | Pydantic v2               | Blazing-fast Rust-based data validation and strict  |
|                       |                           | typing for workflow definitions and JSON outputs.   |
+-----------------------+---------------------------+-----------------------------------------------------+
| Model Integrations    | LangChain Chat Models     | Swappable adapters for Google Gemini, Groq, and     |
|                       | (Groq, Gemini, OpenRouter)| OpenRouter (via langchain-openai) with strict       |
|                       |                           | schema adherence and reasoning-model pacing.       |
+-----------------------+---------------------------+-----------------------------------------------------+
| Document & OCR Engine | `pypdf`, `pypdfium2`,     | Fast digital PDF text layer extraction paired with  |
|                       | and Tesseract OCR         | worker-thread Tesseract OCR for scanned physical doc|
+-----------------------+---------------------------+-----------------------------------------------------+
| Dual-Account Isolation| Multi-API-Key Partitioning| Supports `GROQ_API_KEY` and `GROQ_COMPILED_API_KEY` |
|                       |                           | for concurrent side-by-side live comparison runs.   |
+-----------------------+---------------------------+-----------------------------------------------------+
| Agent Compatibility   | LangGraph (`StateGraph`)  | Ingests external agent graphs without locking the   |
|                       |                           | bank into a proprietary ecosystem.                  |
+-----------------------+---------------------------+-----------------------------------------------------+
| Mock Banking Services | FastAPI & Pydantic Stubs  | Fully offline, deterministic banking APIs (KYC,     |
|                       |                           | CIBIL, Statements) with configurable delays.        |
+-----------------------+---------------------------+-----------------------------------------------------+
| Local Storage         | SQLite 3                  | Embedded, zero-configuration database for run logs, |
|                       |                           | node profiles, cache storage, and token ledgers.    |
+-----------------------+---------------------------+-----------------------------------------------------+
| Semantic Verification | `sentence-transformers`   | Free, local CPU-powered text embeddings for output  |
|                       | (all-MiniLM-L6-v2)        | similarity testing without making external API calls|
+-----------------------+---------------------------+-----------------------------------------------------+
| System Telemetry      | `psutil`                  | Tracks real process CPU % and RAM usage per run.    |
+-----------------------+---------------------------+-----------------------------------------------------+
| Server & API          | FastAPI + WebSockets      | Asynchronous REST endpoints and bidirectional live- |
|                       |                           | streaming for real-time Gantt timeline rendering.   |
+-----------------------+---------------------------+-----------------------------------------------------+
| User Interface        | HTML5, Modern CSS, Vanilla| Instant local loading; zero Node.js build steps;    |
|                       | JavaScript (ES6 Modules)  | completely immune to npm bundle breakage on demo day|
+-----------------------+---------------------------+-----------------------------------------------------+
```

### Local Quota Guard & Live Model Protections

The current implementation includes live model quota handling in `synapse/backends/quota.py` and `synapse/backends/llm.py`:

1. **Shared Multi-Model Free-Tier Quota Scoping (`__openrouter_free__`):**
   - *The Reality:* OpenRouter limits free accounts to an aggregate allowance (e.g., 50 requests/day) shared across *all* free models (e.g., `meta-llama/llama-3-8b-instruct:free`, `mistralai/mistral-7b-instruct:free`). Tracking them by individual model names caused local ledgers to undercount total account consumption.
   - *The Solution:* `QuotaGuard` redirects models ending in `:free` or labeled `openrouter/free` to a unified `__openrouter_free__` scope.
   - *SQLite Migration:* On opening `quota.db`, it migrates prior free-model call and block records into that shared scope without resetting the database.

2. **Output Token Cap Alignment (`effective_output_tokens`):**
   - *The Choice:* SYNAPSE allows at least 2,048 output tokens for OpenRouter free models (`OPENROUTER_MIN_OUTPUT`) so reasoning output has room before the structured answer.
   - *The Safeguard:* `effective_output_tokens()` reserves that same configured output cap locally and sends it to the model adapter. Actual token use can still differ and is settled from provider-reported usage when available.

3. **Advisory Exhaustion & Provider Back-Off:**
   - A provider-reported daily quota error ends the current run and marks the model as exhausted in the local display. The daily status is advisory: a later user request can try the provider again, while minute limits still pace calls.

### Why We Excluded LangSmith, Langflow, and Heavy Frameworks
A common trap in hackathons is wiring together heavy, pre-packaged GUI tools like Langflow or relying on cloud observability platforms like LangSmith. 
The team explicitly avoided them because:
1. **The judging criteria evaluate our compiler and runtime**, not a third-party framework's features.
2. Cloud observability platforms introduce network latency and fail if venue Wi-Fi drops.
3. SYNAPSE's internal profiler and SQLite ledger give total architectural independence.

---

## 16. Team Organization & 24-Hour Hackathon Execution Plan

Executing an ambitious systems project in a 24-hour hackathon requires disciplined project management. SYNAPSE was structured around four specialized roles, four distinct operational phases, and four non-negotiable stage gates.

```
+---------------------------------------------------------------------------------------------------------+
|                                  THE 4 TEAM ROLES & RESPONSIBILITIES                                    |
+--------------------------+------------------------------------------+-----------------------------------+
| ROLE TITLE               | SCOPE OF OWNERSHIP                       | FIRST DELIVERABLE MILESTONE       |
+--------------------------+------------------------------------------+-----------------------------------+
| Runtime Lead             | YAML parser, NetworkX DAG, asyncio       | Baseline loan workflow executes   |
|                          | executor, LLM adapters, mock bank APIs.  | end-to-end in mock mode by Hour 4 |
+--------------------------+------------------------------------------+-----------------------------------+
| Compiler Lead            | Optimization passes (P0/P1), adaptive    | Dead-node, duplicate (CSE), and   |
|                          | optimizer, decision log, LangGraph bridge| parallel passes working by Hour 8 |
+--------------------------+------------------------------------------+-----------------------------------+
| Validation & Data Lead   | Synthetic data generation (20 cases),    | Mock bank APIs and 20-applicant   |
|                          | golden runs, noise floor, test harness.  | verified test suite by Hour 3     |
+--------------------------+------------------------------------------+-----------------------------------+
| Dashboard & Pitch Lead   | WebSocket event streaming, UI screens,   | Interactive graph view rendering  |
|                          | pitch deck, live demo script, rehearsals.| compiled plans by Hour 8          |
+--------------------------+------------------------------------------+-----------------------------------+
```

### The 4 Phases and 4 Hard Gates

```
[HOUR 00: KICKOFF]
       |
       v
+-----------------------+
| PHASE 1: SCAFFOLDING  | Build IR, mock bank endpoints, baseline executor, golden dataset.
+-----------------------+
       |
       v ===> [GATE H4: Baseline runs end-to-end; initial timings recorded]
+-----------------------+
| PHASE 2: CORE COMPILER| Implement P0 passes: Dead nodes, CSE, Parallelisation, Memoisation.
+-----------------------+
       |
       v ===> [GATE H8: Compiler passes operational; graph diff rendering in UI]
+-----------------------+
| PHASE 3: VERIFICATION | Build validator gauntlet, ablation bench, LangGraph importer.
+-----------------------+
       |
       v ===> [GATE H12 HARD GATE: Measured 2x speedup + 100% test pass confirmed]
       |      * If H12 slips, freeze feature scope and cut all P1 passes!
+-----------------------+
| PHASE 4: POLISH & DEMO| Dashboard polish, pitch rehearsal, live model validation, backup video.
+-----------------------+
       |
       v ===> [GATE H18: STRICT CODE FREEZE -> Rehearsals & Sleep in Shifts]
       |
[HOUR 24: PRESENTATION TO JUDGES]
```

### Team Adaptation Rules:
- **If 3 Members:** The Compiler Lead assumes joint ownership of Validation and Data.
- **If 2 Members:** Fall back immediately from custom UI to Streamlit to conserve engineering bandwidth.

---

## 17. The 5-Minute Winning Pitch & Demo Script (Minute-by-Minute)

When presenting to senior executives and hackathon judges, every second counts. The team follows a precisely timed **5-Minute Presentation Script**:

```
+---------------------------------------------------------------------------------------------------------+
|                                 THE 5-MINUTE LIVE DEMONSTRATION SCRIPT                                  |
+-------------+---------------------+-----------------------------------+---------------------------------+
| TIME WINDOW | DEMO PHASE          | WHAT THE SPEAKER SAYS             | WHAT IS SHOWN ON SCREEN         |
+-------------+---------------------+-----------------------------------+---------------------------------+
| 0:00 - 0:30 | The Hook & Problem  | "Banks are racing to deploy AI    | Slide: The 5 Traps of Bank AI   |
|             |                     | agents for lending and support.   | Agents. Contrast traditional    |
|             |                     | But today's agents are slow and   | sequential execution with       |
|             |                     | expensive because they execute    | customer drop-off metrics.      |
|             |                     | like a 1920s dumb assembly line." |                                 |
+-------------+---------------------+-----------------------------------+---------------------------------+
| 0:30 - 1:15 | Run the Original    | "Here is a real personal loan     | Click 'Run Baseline'. The Gantt |
|             | Baseline            | pre-screening agent. Watch it run | timeline builds slowly: a rigid |
|             |                     | on Applicant A01. 11 steps, one by| sequential staircase of tasks   |
|             |                     | one. It takes over 132 seconds."  | taking over 132 seconds.        |
+-------------+---------------------+-----------------------------------+---------------------------------+
| 1:15 - 2:00 | Compile with        | "Now, we hit Compile. In 50ms,    | Screen 1: Graph View. Judges see|
|             | SYNAPSE             | SYNAPSE analyzes data flow: it    | dead node greyed out, duplicate |
|             |                     | prunes an unused offers call,     | merged, and KYC/Bureau boxed in |
|             |                     | merges duplicate policies, routes | green parallel groups.          |
|             |                     | segment extraction, and keeps     |                                 |
|             |                     | the SMS write untouched."         |                                 |
+-------------+---------------------+-----------------------------------+---------------------------------+
| 2:00 - 2:45 | Run Compiled        | "Now we run the compiled version  | Screen 6: Live Run. Timers run  |
|             | Live                | on the exact same applicant.      | side by side. The staircase     |
|             |                     | Look at the timeline: the bars now| collapses into stacked bars!    |
|             |                     | overlap simultaneously. Finished  | Timer stops at 40.9s (3.2x speed)|
|             |                     | in 40.9s—more than 3x faster!"    |                                 |
+-------------+---------------------+-----------------------------------+---------------------------------+
| 2:45 - 3:30 | Prove Safety & The  | "Speed means nothing if accuracy  | Screen 4: Validation Matrix.    |
|             | Unsafe Rollback     | slips. Every test case matches    | All green checks. Then, toggle  |
|             |                     | 100%. Now watch this: we trigger  | '--unsafe-route-risk'. System   |
|             |                     | an unsafe pass to put the credit  | flashes red, rejects the pass,  |
|             |                     | decision on a weak model. SYNAPSE | and restores the safe plan!     |
|             |                     | catches it, rejects it, and rolls |                                 |
|             |                     | back automatically on screen!"    |                                 |
+-------------+---------------------+-----------------------------------+---------------------------------+
| 3:30 - 4:15 | Empirical           | "Every number you see is real and | Screen 5: Benchmarks. Show the  |
|             | Benchmarks          | measured across 20 diverse cases. | Ablation Bridge: step-by-step   |
|             |                     | Cold speedup: 3.23x. Cost drop:   | cost drop from $19.50 to $6.75  |
|             |                     | 65.4%. Repeat warm speedup: 6.7x."| and token shrinkage by 23.9%.   |
+-------------+---------------------+-----------------------------------+---------------------------------+
| 4:15 - 4:45 | Generality Beyond   | "SYNAPSE is not hardcoded for     | Briefly show Complaint Triage   |
|             | Lending             | loans. Here is an un-tuned        | (1.45x cold) and LangGraph      |
|             |                     | Complaint Triage agent, and an    | Research Agent on HotpotQA      |
|             |                     | open-source LangGraph research bot| compiling with zero manual code |
|             |                     | compiling with identical safety." | changes.                        |
+-------------+---------------------+-----------------------------------+---------------------------------+
| 4:45 - 5:00 | The Close & Vision  | "SYNAPSE makes bank AI agents     | Closing Slide: SYNAPSE - Safe,  |
|             |                     | faster and cheaper by design,     | Fast, Reliable AI Orchestration |
|             |                     | without ever putting a single     | for IDFC FIRST Bank.            |
|             |                     | rupee of customer money at risk." |                                 |
+-------------+---------------------+-----------------------------------+---------------------------------+
```

---

## 18. Judge Q&A Masterclass: Bulletproof Answers to the 9 Toughest Questions

Hackathon judges will test your depth. Here are the nine hardest questions you will face, along with concise, bulletproof answers:

### Q1: "Isn't your baseline slow on purpose just to make your compiler look good?"
> **The Non-Technical Answer:**  
> "No, that is actually how almost all AI agents in production run today! Frameworks like LangChain, standard ReAct agents, and ordinary Python scripts execute steps one after another in file order. Academic benchmarks—including LLMCompiler (2023) and Dyserve (2026)—used this exact sequential baseline. Furthermore, our ablation benchmark isolates every single pass, so you can see exactly how much gain comes from parallelization versus duplicate removal versus prompt compaction."

### Q2: "Doesn't LangGraph already run branches in parallel? Why do we need SYNAPSE?"
> **The Non-Technical Answer:**  
> "LangGraph only runs in parallel what a human engineer manually wires together with complex multi-threaded code. SYNAPSE is an automated compiler: it analyzes raw data dependencies, automatically discovers what can safely overlap, eliminates dead steps, merges duplicate queries, and mathematically validates that the new schedule produces 100% identical outputs before shipping."

### Q3: "Large Language Models are non-deterministic. How can you claim 100% correctness?"
> **The Non-Technical Answer:**  
> "We use a multi-tiered defense:
> 1. All models run at temperature 0.0.
> 2. We run the baseline twice to measure the 'natural noise floor' of the model.
> 3. Hard financial decisions (Approve/Refer/Decline) and database keys must match character-for-character (100% exact match).
> 4. Structured outputs must satisfy strict Pydantic schemas.
> 5. Free text is verified using local embeddings above the noise floor.
> If any pass causes even a single case to fail, SYNAPSE's rollback engine instantly rejects the pass and restores the safe plan."

### Q4: "Caching in a bank? Account balances and interest rates change constantly. Isn't that dangerous?"
> **The Non-Technical Answer:**  
> "In SYNAPSE, write nodes are NEVER cached. Cached reads have a strict Time-to-Live (TTL). The synthetic KYC check uses 24 hours, the credit score uses 1 hour, and the account statement uses 15 minutes. Cache keys include exact inputs. After any attempted write, we purge all cached reads, including those for a joint account under another customer ID."

### Q5: "Is it really safe to route loan decisions to a cheap, small model?"
> **The Non-Technical Answer:**  
> "SYNAPSE **never** routes final financial decision steps to a small model! The final credit risk decision (`risk_summary`) is permanently locked to the large frontier model. Routing is only permitted for low-risk, deterministic sub-tasks (like extracting an employer name or categorizing income), and only after that specific task has achieved a 100% pass rate across our historical test suite."

### Q6: "Does SYNAPSE only work on your loan demo, or is it a general-purpose compiler?"
> **The Non-Technical Answer:**  
> "It is completely general. In our repository, we compiled a customer complaint triage agent and an open-source LangGraph research agent running on the HotpotQA benchmark. Neither workflow had any seeded flaws or manual tuning, yet SYNAPSE automatically discovered parallel execution paths and compressed token payloads without altering the underlying code."

### Q7: "Where mathematically does your speedup come from?"
> **The Non-Technical Answer:**  
> "It comes from shrinking the **Critical Path**. In computing, Amdahl's Law dictates that you can never run faster than your longest sequential chain of dependencies. By removing dead steps, merging duplicate searches, and overlapping independent operations, SYNAPSE mathematically shortens the critical path from 132ms down to 40ms. Parallelism does not beat dependencies, so we optimize the path itself."

### Q8: "What about API rate limits and quotas under enterprise banking scale?"
> **The Non-Technical Answer:**  
> "SYNAPSE includes a built-in asynchronous concurrency limiter (semaphore caps) and a local SQLite quota ledger. It monitors requests-per-minute and tokens-per-day, enforcing conservative pacing beneath provider rate limits. If enterprise traffic spikes, SYNAPSE paces calls smoothly rather than triggering HTTP 429 quota rejections."

### Q9: "Real AI agents choose their next steps dynamically at runtime. Does SYNAPSE handle dynamic branching?"
> **The Non-Technical Answer:**  
> "Yes. In our intermediate representation, conditional branches are represented as `gate` nodes. SYNAPSE compiles the reusable template and optimizes based on real execution traces. Furthermore, our P2 pass supports speculative branch execution (borrowed from the DynBranch 2026 paper), which safely initiates pure data fetching on the most probable branch before the condition finishes evaluating."

---

## 19. Risk Matrix & High-Stakes Contingency Plans

Presenting live software at a major hackathon involves real operational hazards. SYNAPSE has pre-engineered contingency protocols for every failure scenario:

```
+---------------------------------------------------------------------------------------------------------+
|                                  SYNAPSE RISK MITIGATION MATRIX                                         |
+--------------------------+---------------------+--------------------------------------------------------+
| IDENTIFIED RISK          | SEVERITY LEVEL      | PRE-ENGINEERED FALLBACK PROTOCOL                       |
+--------------------------+---------------------+--------------------------------------------------------+
| Venue Wi-Fi fails or has | CRITICAL            | Full Local Mock Mode: The entire demo runs 100% offline|
| high packet loss.        |                     | with zero internet dependency (local mock bank, local  |
|                          |                     | CPU embeddings, local SQLite). Backup video on standby.|
+--------------------------+---------------------+--------------------------------------------------------+
| Remote LLM API hits rate | HIGH                | Asynchronous Quota Ledger reserves tokens before calls;|
| limits or quota errors.  |                     | automatic instant fallback to local mock LLM on HTTP 429|
+--------------------------+---------------------+--------------------------------------------------------+
| LLM outputs drift or vary| MEDIUM              | Temperature locked at 0.0; measured noise floor buffer;|
| non-deterministically.   |                     | strict schema validation and exact decision matching.  |
+--------------------------+---------------------+--------------------------------------------------------+
| Race conditions in async | HIGH                | Functional node isolation: each node writes only to its|
| parallel executor.       |                     | own isolated output key; safe order edges on all writes|
+--------------------------+---------------------+--------------------------------------------------------+
| UI / Dashboard build     | MEDIUM              | Vanilla JavaScript & CSS: Zero npm build step, zero    |
| fails or breaks layout.  |                     | webpack/vite dependencies; Streamlit fallback prepared|
+--------------------------+---------------------+--------------------------------------------------------+
| Team fatigue during the  | MEDIUM              | Strict H18 Code Freeze: Mandatory rest in shifts; no   |
| late-night sprint.       |                     | new code introduced after 3:00 AM on demo day.         |
+--------------------------+---------------------+--------------------------------------------------------+
```

---

## 20. Speaker Notes, Delivery Strategy & Non-Technical Metaphors

When you stand before the judges, follow these executive communication principles:

### 1. The Power of Contrast (Before vs. After)
Never show an optimized screen without first showing how painful the unoptimized state was. Always start by showing the **slow, sequential staircase** on the execution timeline. Let the judges feel how frustrating the waiting is. Then, hit **Compile** and show the staircase collapse into clean, overlapping, synchronized bars.

### 2. Memorable Metaphors to Use
- **The Construction Site:** *"Building an AI agent today is like having an architect, an electrician, a plumber, and a painter arrive on site—but making the plumber sit in his truck for three hours until the electrician completely finishes wiring the attic."*
- **The Executive Chef:** *"SYNAPSE is the executive chef that organizes the kitchen prep so the sauce, the steak, and the garnish all finish at the exact second the plate needs to go out."*
- **The Financial Bank Vault:** *"We treat write operations like a physical bank vault: no matter how fast we want the teller to move, the vault doors will never be opened out of sequence or left unmonitored."*

### 3. Stage Demeanor & Body Language
- **Confidence in Real Data:** State firmly: *"Judges, every number on this screen was measured on this machine. There are no mockups, no simulated graphs, and no hardcoded savings."*
- **Invite Scrutiny:** Welcome tough questions with a smile: *"We encourage you to inspect our validation ledger and our SQLite trace logs."*
- **Emphasize Business Value:** Always bridge technical metrics back to the bank's bottom line:
  - *"3.2x faster means a customer receives a personal loan pre-approval before they close their mobile app, driving conversion up."*
  - *"65% cheaper AI cost means IDFC FIRST Bank can process 10 million automated loan inquiries for the cost of 3.5 million."*
  - *"Safety by construction means the Chief Risk Officer can sleep peacefully at night."*

---

### Master Report Summary Checklist for the Presenter:
- [x] Clear executive summary with the kitchen and construction metaphors.
- [x] Complete explanation of the 5 seeded flaws in the loan agent.
- [x] Thorough definition of the Pure, Read, and Write Effect Annotation system.
- [x] Full non-technical translation of all 17 research papers and academic lineage.
- [x] Detailed walkthrough of the 8-component feedback loop.
- [x] Complete catalogue of P0, P1, and P2 compiler passes.
- [x] Deep dive into the 7-step validation gauntlet and the `--unsafe-route-risk` rollback proof.
- [x] Accurate breakdown of measured benchmarks (3.23x speedup, 65.4% cost savings, 100% accuracy).
- [x] Minute-by-minute 5-minute presentation script.
- [x] Complete rehearsal answers to the 9 toughest judge questions.
- [x] Comprehensive risk and fallback matrix.

---
*Report compiled and verified for the IDFC FIRST Bank Hackathon Presentation.*
