# SYNAPSE

**A dependency-aware compiler and runtime for AI agent workflows.** SYNAPSE reads an existing workflow, finds work that can safely overlap or be reused, and measures whether the compiled version is faster while preserving its checked outputs.

The headline demonstration is a **synthetic bank loan pre-screening agent**. The original workflow runs 11 steps in file order. SYNAPSE builds a dependency graph, removes an unused offer lookup, merges a duplicate policy lookup, overlaps independent checks, and caches eligible results. A validator tests each change against the original before accepting it. A second complaint triage workflow and a LangGraph research example show that the compiler is not tied to the loan agent.

All bank customers, accounts, policy passages and service responses in this repository are synthetic. The demo is not connected to a bank and is not a production credit or complaint decision system.

## See it run

From the repository root, with Conda and `make` installed:

```bash
make setup      # creates the Python 3.12 "synapse" environment; downloads the local embedding model
make test       # offline tests; no real model or external API calls
make bench      # measured mock ablation, 20 loan cases × 10 repeats by default
make demo       # profiles and validates, then serves http://127.0.0.1:8000
```

Open [the local dashboard](http://127.0.0.1:8000). Its eight views cover workflow graphs, an execution timeline, compiler decisions, validation, benchmarks, live runs, PDF application intake, and review sentiment. The timeline puts the original and compiled traces on the same axis so overlapping work is visible; skipped branches are labelled. `make bench` writes `bench/results/latest.json`; run it before `make demo` if you want benchmark data on the screen immediately. The results and SQLite traces are generated locally and ignored by Git.

Open the dashboard through the server URL above. Opening `ui/index.html` as a local file displays the source page without its API or assets.

For a quick terminal demonstration without the dashboard:

```bash
conda run -n synapse synapse run workflows/loan_prescreen.yaml --case A01 --latency-scale 0.01
conda run -n synapse synapse compare workflows/loan_prescreen.yaml --case A01 --latency-scale 0.01
conda run -n synapse synapse validate workflows/loan_prescreen.yaml --unsafe-route-risk --latency-scale 0.001
```

The third command deliberately tries to route the final risk decision to a weak mock model. It should print a rejection reason while retaining the safe plan. `--latency-scale` changes **simulated mock delays**; it does not scale Python or model execution time.

## How it works

```mermaid
flowchart LR
    A[Workflow YAML or LangGraph sample] --> B[Parser and dependency graph]
    B --> C[Baseline run and profiler]
    C --> D[Compiler passes]
    D --> E[Dependency-aware executor]
    C --> F[Golden outputs]
    E --> G[Validator]
    F --> G
    G -->|accepted plan| H[Dashboard and benchmark]
    G -->|failed check| D
```

Each node declares what it reads, what it produces, and its effect: `pure`, `read`, or `write`. The parser catches missing inputs, cycles and undeclared outputs. In baseline mode, the executor awaits every node in YAML order. In compiled mode, a node starts when all producers of its inputs have finished, subject to write-order barriers and a model concurrency cap.

In the loan workflow, statement fetching and policy retrieval can begin while the application is parsed. After parsing, KYC, bureau and segment classification can overlap. `risk_summary` waits for all of their outputs; `notify_customer` waits for the risk decision. The compiler currently supports:

| Pass | Change | Safety condition |
| --- | --- | --- |
| Compact inputs | Remove JSON whitespace and repeated table keys | Every field/value survives; templates and schemas stay intact; writes are excluded. |
| Dead nodes | Remove unused work | Never removes a write, a `required: true` check, or a producer of a declared workflow output. |
| Common subexpressions | Merge equivalent calls | Requires the same behavior and safe effect; reads cannot merge across an intervening write. |
| Parallel execution | Start independent nodes together | Data dependencies and write barriers remain in force. |
| Exact memoisation | Reuse repeated results | Keys include inputs, node configuration and model provider; reads expire and writes invalidate cached reads. |
| Model routing and cascade | Try a smaller model on checkable steps | Requires validation evidence; a schema failure retries on the large model. Final decision steps stay on the large model. |

A missing effect tag is treated as `write`. A write is never removed, merged, cached or reordered against any other step. The validator runs the original twice to measure natural output variation, then tests compiler changes incrementally on the same cases. Structured outputs must satisfy their JSON Schema; decision fields and non-text fields are checked exactly; free text is compared for similarity. A failing pass is rejected with a reason.

## Workflows

| Workflow | What it exercises | Cases | Command |
| --- | --- | ---: | --- |
| `loan_prescreen.yaml` | Application parsing, KYC, bureau, statement and policy checks, risk decision, SMS write | 20 | `synapse compare workflows/loan_prescreen.yaml --case A01` |
| `complaint_triage.yaml` | Complaint classification, transaction and policy reads, reply draft, ticket write | 17 | `synapse compare workflows/complaint_triage.yaml --case C01` |
| `review_sentiment.yaml` | Google-review sentiment from user-supplied text: aspects and tone in parallel, then a structured sentiment, confidence and explanation | 18 | `synapse compare workflows/review_sentiment.yaml --case R01` |
| `research_llm_langgraph.py` | Two local evidence searches, one structured model answer with citations and an unsupported-answer flag | 20 | Select `research_llm` and any configured model in the dashboard |
| `research_agent_langgraph.py` | Importing a LangGraph DAG and overlapping two retrieval and summary branches | 20 | `synapse import-langgraph workflows/research_agent_langgraph.py --show-graph --run` |

The complaint reply is a draft for human review, and the policy corpus is explicitly synthetic. The research cases come from the [HotpotQA dataset](https://huggingface.co/datasets/hotpotqa/hotpot_qa); its local answer function demonstrates scheduling and output preservation, **not question-answering accuracy**. Conditional branches imported from LangGraph are represented as required gate nodes and run only their chosen branch.

## Commands

| Command | Purpose |
| --- | --- |
| `synapse run WORKFLOW --case ID [--mode compiled]` | Run one synthetic case or all cases; print the result and timing. |
| `synapse compile WORKFLOW --show-graph --explain` | Show the graph and each compiler decision. `--explain` uses stored mock baseline profiles. |
| `synapse profile WORKFLOW --case ID --runs N` | Record node timings, tokens, model costs, retries, CPU and memory in `data/synapse.db`. |
| `synapse compare WORKFLOW --case ID` | Run baseline and compiled versions on the same case. |
| `synapse validate WORKFLOW [--unsafe-route-risk]` | Check candidate passes against golden runs; the unsafe switch is for the loan mock demo. |
| `synapse bench [WORKFLOW ...] [--cases A01,A03] [--steps baseline,parallelise]` | Measure pass-by-pass cold and warm results. |
| `synapse import-langgraph MODULE --show-graph --run` | Import and validate a supported LangGraph DAG. |
| `synapse extract-pdf FILE.pdf [--ocr auto\|always\|never] [--show-text]` | Extract a PDF application's text (OCR for scanned pages) and print how it was read. |
| `synapse run workflows/loan_prescreen.yaml --application-pdf FILE.pdf --customer-id ID` | Run the loan workflow on an uploaded PDF instead of a synthetic case. |

The mock bank can also run as a separate local service with `make mock`; pass `--bank-url http://127.0.0.1:8001` to `synapse run`. `make api` starts the dashboard API without first profiling or validating.

### Benchmark method

`make bench` uses the same executor, cases and concurrency cap for each configuration. It adds dead-node removal, duplicate merging, lossless input compaction, parallel execution, model routing, then caching one step at a time. Live benchmarks apply routing only after the exact plan and provider models passed validation; when both tiers use the same model, routing is skipped because it cannot save a model call. By default the mock benchmark runs every case in all four workflows 10 times. The dashboard shows original and optimized input/output tokens, their total, estimated cost per case, and the measured difference. It also shows cache-cold median and p95 latency, model calls, critical path and correctness. A separate warm result represents repeat requests with a prefilled cache. The default mock delay scale is `0.01`, recorded in the output JSON so runs at different scales are not confused. Mock cost units are reproducible comparison units, **not dollars**. Results vary by machine and load. A bundled three-repeat synthetic example populates the dashboard on a fresh checkout until `make bench` writes local results.

The bundled three-repeat example at scale `0.01` measured these cache-cold means per case:

| Workflow | Tokens, original → optimized | Mock cost, original → optimized | Correct optimized runs |
| --- | ---: | ---: | ---: |
| Loan pre-screen | 1,950.4 → 1,520.8 | 19.504 → 6.750 units | 60/60 |
| Complaint triage | 1,479.2 → 1,437.8 | 14.792 → 14.378 units | 51/51 |
| Research scheduling sample | 0 → 0 | 0 → 0 units | 60/60 |
| Model-backed research | 768.6 → 766.0 | 7.686 → 7.660 units | 60/60 |

Loan inputs shrink by 23.9% in this simulation; complaint inputs by 3.3%. Large cost reductions
in the mock loan benchmark also include validated model routing, which live runs do not inherit
without provider-specific validation. Parallel execution alone cannot reduce token counts.
The single-call research workflow has little redundant input and its tiny local searches do
not yield a meaningful cold speedup (17.9 → 18.3 ms in this sample). Do not interpret output
preservation as research answer accuracy. These are controlled simulation results, not bank
results. The bundled data are in `bench/sample_mock.json`; local measurements replace them.

For a short local check:

```bash
conda run -n synapse synapse bench --cases A01,A03 --repeats 1 --latency-scale 0.001
```

## Optional live model calls

Mock mode is the default and is sufficient for the whole demo. To call a real model, copy `.env.example` to `.env`, set `GOOGLE_API_KEY` (or `GROQ_API_KEY` or `OPENROUTER_API_KEY`, chosen with `--provider`), and add `--live` to `run`, `compare`, `profile`, `validate`, or `bench`. The `.env` file is ignored by Git. LangSmith tracing is optional through the variables shown in `.env.example`.

**`--live` changes only the LLM calls.** Bank tools still use the local mock bank, retrieval still uses local synthetic policies, and all cases remain synthetic. Gemini has been exercised end to end; Groq GPT-OSS 20B and 120B have each completed complaint case C01. Live calls may consume provider quota. Live cost figures are estimates at the configured paid-tier token rates, even when an account is on a free tier. Mock and live benchmark files are kept separately.

For a two-account Groq comparison, set `GROQ_API_KEY` for the original run and
`GROQ_COMPILED_API_KEY` for the compiled run in the ignored `.env` file. Both keys are required
for a live Groq comparison or compiled run. The dashboard starts both runs together and shows
separate local quota estimates for each account. The CLI uses the same split:

```bash
synapse compare workflows/complaint_triage.yaml --case C01 --live --provider groq \
  --model openai/gpt-oss-20b --latency-scale 0.001
```

`--model` pins both workflow model tiers to GPT-OSS 20B, so this check never calls 120B.
Each account's actual rate limit depends on its Groq organization; the local estimate counts
only SYNAPSE calls. The estimated USD cost is a paid-tier equivalent, not a free-tier charge.
The selective audit of `venky-feature` and its deferred safety issues is in
[VENKY_FEATURE_AUDIT.md](VENKY_FEATURE_AUDIT.md).
Live comparisons can run concurrently on the two accounts. Their response times and generated
output lengths can differ even for identical prompts, so a single live run may be slower or
use more tokens after compilation. The dashboard shows increases as well as reductions. Its
adjusted time removes only local quota pacing; provider retry waits remain. A warm cache can
show zero new model tokens when an exact prior result is reused; compare cold runs to measure
the compiler's own prompt savings. Benchmark comparisons are withheld when a run failed, a
decision was incorrect, usage is incomplete, or no baseline was measured.

The dashboard's model selectors offer Mock and the configured Gemini, Groq and OpenRouter models. Live runs default to one compiled execution; select **Compare both** when you want to spend requests on both versions and see their measured token and estimated USD costs side by side. A compiled-only run shows its own usage; it cannot claim an original-run cost without making those extra calls. Pricing uses the selected model's actual rate, even if the workflow labels its node with another tier. The original `research_agent` is a scheduling-only example with zero model calls. The new `research_llm` has a real structured answer step and works with the selected provider. Its two local searches run concurrently in the compiled plan, then one synthesis call cites evidence; it avoids two intermediate model summaries by design. The local SQLite quota ledger reserves requests and tokens before each call, survives server restarts, and shows remaining local budget beside the selector. Minute pacing uses conservative caps below [Groq's published free limits](https://console.groq.com/docs/rate-limits);
[Gemini limits](https://ai.google.dev/gemini-api/docs/rate-limits) vary by project/model.
Daily exhaustion is **advisory**: models stay selectable and each uncached call tries the
provider again after minute pacing. A daily quota rejection ends that run immediately without
repeated daily-limit retries. A successful call clears the old provider warning. This ledger
cannot see use in other apps or guarantee a free-tier allowance.

The dashboard shows total elapsed time and execution time after removing quota idle periods.
It removes an interval only while every active step is waiting, so parallel work is counted.
Per-call wait totals can overlap and are displayed separately, along with model time,
input/output tokens, cost and each step's usage. A slower/more expensive result is red.
A run with all model answers reused shows zero **new** model tokens. Partial cache hits keep
their measured token and cost totals, with cache reuse identified separately. Compare cold
runs to isolate compiler savings. If a provider omits usage, the dashboard shows only reported
totals and withholds token and cost reduction claims. A model can vary output
length even at temperature zero. Groq uses [strict structured output](https://console.groq.com/docs/structured-outputs)
for the supported GPT-OSS models; local schema validation remains in place.

Select **Reuse exact results** to retain compiled model answers between identical runs in
this server session. The first run is cold; subsequent exact matches are warm and may avoid
all model calls. Fresh bank reads still occur after writes, and each SMS/ticket write still
executes once per run. Keys include model/provider, inputs, prompt/schema contents and node
settings. Cold is the default; do not compare warm reuse with cold execution as a compiler
speed benchmark. Completed traces, including failed-call usage and waits, persist in SQLite.

LangGraph modules can declare `NODE_SPECS` for every node to import I/O without executing any
function. This is required for read/write services and async model calls. The original pure
scheduling example still supports tracing. `research_llm_langgraph.py` can also be run natively
with `build_graph(adapter).compile()`, using the same adapter contract. Conditional gates
choose one branch in both execution modes; untaken steps are recorded as skipped and are shown
as such on the dashboard timeline. A branch can feed a common downstream step through
`optional_inputs` in a YAML workflow.

Routing evidence is tied to the workflow, prompt and schema contents, full case suite, provider, and model names. The API runs a compiled live plan without routing until those live models pass validation; an explicitly requested routed plan is rejected until then.

### OpenRouter (free models)

Set `OPENROUTER_API_KEY` in `.env` and add `--live --provider openrouter` to `run`, `compare`,
`profile`, `validate` or `bench`; the dashboard also lists it. Both tiers use
`nvidia/nemotron-3.5-super-vl:free`, which honours the JSON schemas. Requests ask for hosts
that support those parameters, with low reasoning effort and at least 2,048 output tokens,
because free models often reason before answering.

- **Free-tier limits:** an account with under $10 of credit gets 20 requests a minute and 50 a
  day across all free models. SYNAPSE's local minute ledger and remaining-budget display share
  one allowance across those models, including counts saved before this change. It reserves
  the same 2,048-token minimum output cap it sends to OpenRouter. A daily-cap error
  ("free-models-per-day") stops the run instead of retrying; the user can try again later.
- **Measured on 2026-11-01:**
  - review R13 came back `negative`, as expected;
  - a loan compare on A01 ran 30.1 s → 15.1 s (2.00x), with the same `approve`;
  - a one-repeat live benchmark on A01 gave a cold median of 25.6 s → 13.1 s (1.96x), with every
    optimised decision correct (`bench/results/latest_live.json`).
- **Not a full live benchmark:** the plan's 3 repeats over the whole suite needs the 1,000-a-day
  tier.
- **Variation:** a free model can route to different hosts and reasons for a varying number of
  tokens. Its cost and length vary from run to run even at temperature 0; pin hosts with
  `route` in `config/models.yaml` for repeatable output.

## PDF applications and OCR

The loan workflow's `application_pdf` input can come from a real PDF file instead of the synthetic
text fixtures, which keep working unchanged. `synapse/documents.py` reads each page's text layer
with pypdf. A page with almost no text (fewer than `min_chars_per_page` characters) is treated as
scanned: it is rendered with pypdfium2 and read by [Tesseract](https://github.com/tesseract-ocr/tesseract)
OCR. The extracted text then goes to the existing `parse_app` step.

- **Setup:** `make setup` installs the Tesseract binary from conda-forge into the `synapse` env.
  Text PDFs never need it; set `ocr: never` to refuse scans instead.
- **Configuration** (`config/documents.yaml`): `ocr` (`auto`, `always`, `never`), `dpi`, `lang`,
  `tesseract_cmd`, `max_bytes` (10 MB), `max_pages` (20), `min_chars_per_page`, `ocr_timeout_s`,
  `cache_ttl_s`.
- **Errors:** encrypted, oversized, too many pages, not a PDF, damaged, unreadable, and Tesseract
  missing each raise a clear error that never quotes the document. The API maps them to HTTP 422,
  413 (too large) and 503 (OCR unavailable).
- **API:** `POST /applications/pdf` with the PDF as the raw body (`Content-Type: application/pdf`)
  and the customer id in the `X-Customer-Id` header, so it stays out of URLs and logs. Optional
  query parameters are `mode`, `scale`, `provider` and `model`. The provider defaults to mock;
  configured Gemini, Groq and OpenRouter models are available for live model steps. It returns
  the extraction metadata, never the text, and
  a run to follow on `WS /ws/runs/{run_id}`.

```bash
curl -s -X POST 'http://127.0.0.1:8000/applications/pdf?mode=compiled' \
  -H 'Content-Type: application/pdf' -H 'X-Customer-Id: CUST-A04' --data-binary @application.pdf
```

**Limitations.** OCR is not perfect. OCR'd PANs get a safe positional repair and, if still
invalid, a targeted second read of the identifier line. The result is accepted only when it
matches PAN format; an unreadable or ambiguous identifier remains flagged for a person.
The extraction then carries a
`review_flags` entry, and KYC fails on the unknown PAN rather than matching the wrong person.
Handwriting, photos taken at an angle and non-English forms are untested. The mock bank only knows
the 20 synthetic applicants, so an uploaded PDF must use one of their PANs and customer ids.

## Review sentiment

`review_sentiment.yaml` classifies the text of a Google review as positive, neutral or negative,
with a confidence from 0 to 1 and an explanation of at most 240 characters. The JSON Schema
enforces those bounds. It is separate from complaint triage and has no write steps.

- **Data source:** the workflow takes review text supplied by the user; it does not scrape Google
  Maps. The 18 test reviews (R01–R18) are synthetic, written for a fictional branch. They include
  sarcasm, rating-text conflicts, mixed aspects, negation, emoji, Spanish and Hinglish.
- **Authorized source (not implemented):** the
  [Google Business Profile API](https://developers.google.com/my-business/reference/rest/v4/accounts.locations.reviews/list)
  lists reviews only for locations the bank owns or manages. It needs an approved Google Cloud
  project and OAuth with the `business.manage` scope; the refresh token belongs outside the repo.
  Wiring it in means a new read tool node with a short `ttl_s` that maps `comment` to `review_text`
  and `starRating` to `star_rating`.
- **Live check:** on Groq GPT-OSS, review R13 (a 5-star rating on negative text) came back
  negative with confidence 0.96, and the strict schema accepted the numeric and length bounds.

## Hash-based storage

There is one cache design, not two:

- **Node results:** `ExactCache` (`synapse/passes/memoise.py`) keys each result by SHA-256 of
  the node, its inputs, the model, and the prompt and schema contents. It lives in memory: reads
  expire after `ttl_s`, and a write drops the cached reads it may have changed. It is deliberately
  not persisted, because a stored read could outlive another process's write.
- **Uploaded documents:** `Store.get_by_content` and `Store.put_by_content` (`synapse/store.py`)
  reuse the existing SQLite `cache` table, keyed by kind and the SHA-256 of the content. A lookup
  compares the stored bytes with the new ones, so a hash collision can never return another
  document's text; a colliding row is kept and the new value is not cached. Expiry uses wall-clock
  time, since rows outlive processes.
- **What it saves:** a repeat upload of the same scanned PDF skips OCR. In a local check, a second
  extraction took 7 ms from the cache instead of about 1 s of OCR.
- **What it stores:** the cache kind includes the Tesseract version and the OCR settings, so an
  upgrade never serves stale text. The original PDF bytes are kept for verification. They are
  personal data, so the default `cache_ttl_s` is one day, and `data/synapse.db` is git-ignored.

## Concurrency

The asyncio executor is unchanged. Independent steps run concurrently, capped by the provider's
`max_concurrency`. OCR is CPU-bound, so `extract_text_async`, which the API uses, runs parsing,
rendering and Tesseract in a worker thread; pdfium calls are serialised because pdfium is not
thread-safe. Measured on one page at 300 dpi, OCR took about 0.55 s either way. A 10 ms ticker on
the event loop saw at most an 11 ms gap with the worker thread, against 543–592 ms when OCR ran
directly on the loop. Profiling showed no case for multiprocessing.

During a live `compare`, a run that stops on a per-minute rate limit is rerun once after the
provider's suggested wait. A daily quota stops it with a message, and it is never rerun after a
write step, so an SMS or ticket is never sent twice (`synapse/ratelimits.py`).

## Repository map

```text
workflows/          Loan, complaint, review-sentiment and LangGraph example workflows
prompts/            Prompt templates and JSON Schemas
mock_services/      Synthetic cases, deterministic mock LLM tasks and mock bank API
synapse/            Parser, graph, passes, executor, validator, profiler, store, API,
                    and PDF/OCR intake (documents.py)
bench/              Repeated cold/warm benchmark harness
ui/                 Offline dashboard assets
config/             Mock delays, model mapping and cost rates
tests/              Offline unit and integration tests
```

## Team repository rules

This is a private hackathon repository. Push work without rewriting history. Do not commit `.env`, credentials, the team's execution plan PDF, or real customer data. Do not change repository visibility or add people outside the team.
