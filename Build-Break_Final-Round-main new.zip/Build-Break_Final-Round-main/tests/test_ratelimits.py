"""Rerunning a run that stopped on a rate limit: only per-minute limits, as long as the
provider asks, and never after a write step has happened."""

from __future__ import annotations

import asyncio

import pytest

from synapse.ir import Node, NodeRun, RunRecord, Workflow
from synapse.ratelimits import limit_kind, rerun_is_safe, run_with_limit_retry, wait_s

WF = Workflow(name="toy", inputs=["x"], nodes=[
    Node(id="ask", kind="llm", model="large", prompt="p.txt", effect="pure",
         inputs=["x"], outputs=["a"]),
    Node(id="send", kind="tool", tool="sms", effect="write", inputs=["a"], outputs=["s"]),
    Node(id="check", kind="llm", model="large", prompt="p.txt", effect="pure",
         inputs=["s"], outputs=["c"]),
])
MINUTE = "ModelRateLimitError: 429 RESOURCE_EXHAUSTED. Please retry in 7.2s."
DAILY = ("429 RESOURCE_EXHAUSTED: quota exceeded for metric "
         "GenerateRequestsPerDayPerProjectPerModel-FreeTier")


def record(*nodes: tuple[str, str | None]) -> RunRecord:
    return RunRecord(run_id="r", workflow="toy", mode="baseline", case_id="c", wall_ms=1.0,
                     nodes=[NodeRun(run_id="r", node_id=node_id, start_s=0, end_s=1, error=error)
                            for node_id, error in nodes])


@pytest.mark.parametrize(("error", "kind"), [
    pytest.param(MINUTE, "minute", id="per-minute-429"),
    pytest.param(DAILY, "daily", id="gemini-per-day-metric"),
    pytest.param("daily quota reached", "daily", id="daily-quota"),
    pytest.param("429 Rate limit exceeded: free-models-per-day. Add 10 credits to unlock 1000",
                 "daily", id="openrouter-free-per-day"),
    pytest.param("ValueError: 400 INVALID_ARGUMENT", None, id="not-a-limit"),
    pytest.param(None, None, id="no-error"),
])
def test_limit_kind_tells_daily_quotas_from_minute_limits(error: str | None, kind: str) -> None:
    assert limit_kind(error) == kind


def test_wait_uses_the_providers_hint_else_a_minute() -> None:
    assert wait_s(MINUTE) == 10.0  # ceil(7.2) + 2 s margin
    assert wait_s("429 too many requests") == 60.0
    assert wait_s("retry in 0.5s") == 5.0  # never less than five seconds


def test_rerun_is_unsafe_once_a_write_has_happened() -> None:
    assert rerun_is_safe(record(("ask", MINUTE)), WF)
    assert not rerun_is_safe(record(("ask", None), ("send", None), ("check", MINUTE)), WF)
    assert not rerun_is_safe(record(("unknown", None), ("check", MINUTE)), WF)
    failed_write = record(("ask", None), ("send", "response lost after commit"))
    assert not rerun_is_safe(failed_write, WF)
    skipped_write = record(("send", None), ("check", MINUTE))
    skipped_write.nodes[0].skipped = True
    assert rerun_is_safe(skipped_write, WF)


def retry(runs: list[RunRecord]) -> tuple[RunRecord, list[float], list[str], int]:
    """Drive run_with_limit_retry over scripted records, recording waits and notices."""
    waits: list[float] = []
    notes: list[str] = []
    calls = 0

    async def run() -> RunRecord:
        nonlocal calls
        calls += 1
        return runs[calls - 1]

    async def sleep(seconds: float) -> None:
        waits.append(seconds)

    result = asyncio.run(run_with_limit_retry(run, WF, "Original", sleep=sleep,
                                              notify=notes.append))
    return result, waits, notes, calls


def test_a_minute_limit_before_any_write_waits_as_asked_and_reruns_once() -> None:
    done = record(("ask", None), ("send", None), ("check", None))
    result, waits, notes, calls = retry([record(("ask", MINUTE)), done])
    assert (result, waits, calls) == (done, [10.0], 2)
    assert "waiting 10 s" in notes[0]


def test_a_daily_quota_is_not_rerun() -> None:
    failed = record(("ask", DAILY))
    result, waits, notes, calls = retry([failed])
    assert (result, waits, calls) == (failed, [], 1)
    assert "daily quota" in notes[0]


def test_a_limit_after_a_write_is_not_rerun_so_the_write_is_not_repeated() -> None:
    failed = record(("ask", None), ("send", None), ("check", MINUTE))
    result, waits, notes, calls = retry([failed])
    assert (result, waits, calls) == (failed, [], 1)
    assert "not rerunning" in notes[0]


def test_a_limit_after_an_errored_write_is_not_rerun() -> None:
    failed = record(("send", MINUTE))
    result, waits, notes, calls = retry([failed])
    assert (result, waits, calls) == (failed, [], 1)
    assert "not rerunning" in notes[0]


def test_other_errors_and_successes_return_unchanged() -> None:
    for runs in ([record(("ask", "KeyError: x"))], [record(("ask", None))]):
        result, waits, notes, calls = retry(runs)
        assert (result, waits, notes, calls) == (runs[0], [], [], 1)
