"""Conditional branches run once and preserve their decisions after compilation."""

from __future__ import annotations

import asyncio

import pytest

from synapse.backends import mock_backends
from synapse.backends.retrieval import KeywordRetriever
from synapse.api import contract_event, replay_events
from mock_services.bank_api import create_app
from synapse.compiler import check_rewrite, compile_workflow
from synapse.executor import execute, final_outputs
from synapse.graph import GraphError, build_graph
from synapse.parser import parse_workflow
from synapse.store import Store
from synapse.validator import validate


FLOW = parse_workflow({
    "workflow": "conditional_example",
    "input": ["amount"],
    "nodes": [
        {"id": "choose", "kind": "gate", "effect": "pure", "deterministic": True,
         "inputs": ["amount"], "outputs": ["route"],
         "condition": "high if amount > 100 else low",
         "branches": {"high": ["high_step"], "low": ["low_step"]}},
        {"id": "high_step", "kind": "transform", "effect": "pure",
         "deterministic": True, "tool": "high_fn", "inputs": ["amount"],
         "outputs": ["high_result"]},
        {"id": "low_step", "kind": "transform", "effect": "pure",
         "deterministic": True, "tool": "low_fn", "inputs": ["amount"],
         "outputs": ["low_result"]},
        {"id": "join", "kind": "transform", "effect": "pure",
         "deterministic": True, "tool": "join_fn",
         "inputs": ["high_result", "low_result"],
         "optional_inputs": ["high_result", "low_result"], "outputs": ["result"]},
    ],
    "output": ["result"],
})


def test_conditional_branches_match_in_baseline_and_compiled_modes() -> None:
    calls: list[str] = []

    def high(values: dict) -> dict:
        calls.append("high")
        return {"high_result": values["amount"] * 2}

    def low(values: dict) -> dict:
        calls.append("low")
        return {"low_result": values["amount"] + 1}

    functions = {"high_fn": high, "low_fn": low,
                 "join_fn": lambda values: {"result": next(iter(values.values()))}}
    plan = compile_workflow(FLOW)

    async def run_all():
        async with mock_backends(0.001, retriever=KeywordRetriever(),
                                 functions=functions) as backends:
            return [(await execute(FLOW, {"case_id": str(amount), "amount": amount},
                                   mode, backends, plan=plan if mode == "compiled" else None))
                    for amount in (50, 150) for mode in ("baseline", "compiled")]

    records = asyncio.run(run_all())
    assert calls.count("high") == calls.count("low") == 2
    for original, compiled in zip(records[::2], records[1::2]):
        assert not any(node.error for node in original.nodes + compiled.nodes)
        assert final_outputs(original)["result"] == final_outputs(compiled)["result"]
        assert [node.branch for node in original.nodes if node.branch] == [
            node.branch for node in compiled.nodes if node.branch]
        assert sum(node.skipped for node in original.nodes) == 1
        assert sum(node.skipped for node in compiled.nodes) == 1
        assert all(check.passed for check in validate([original], [compiled], 0, wf=FLOW))
        skipped = [event for event in replay_events(compiled)
                   if event["type"] == "node_skip"]
        assert len(skipped) == 1 and skipped[0]["reason"]
        assert contract_event(compiled.run_id, {"type": "node_skip",
                                                 "node_id": "low_step", "at_s": 0,
                                                 "reason": "branch not taken"}) == {
            "type": "node_skip", "run_id": compiled.run_id, "node_id": "low_step",
            "t_ms": 0.0, "reason": "branch not taken"}


def test_store_keeps_branch_and_skip_evidence_for_replay(tmp_path) -> None:
    from synapse.ir import NodeRun, RunRecord

    record = RunRecord(run_id="branch1", workflow="conditional_example",
                       mode="compiled", case_id="C01", wall_ms=3, nodes=[
                           NodeRun(run_id="branch1", node_id="choose", start_s=0,
                                   end_s=.001, branch="low", output={"route": "low"}),
                           NodeRun(run_id="branch1", node_id="high_step", start_s=.001,
                                   end_s=.001, skipped=True,
                                   skip_reason="branch not taken")])
    with Store(tmp_path / "runs.db") as store:
        store.save_run(record)
    with Store(tmp_path / "runs.db") as reopened:
        restored = reopened.load_run("branch1")
    assert restored == record
    skipped = [event for event in replay_events(restored) if event["type"] == "node_skip"]
    assert len(skipped) == 1 and skipped[0]["reason"] == "branch not taken"
    assert not any(event["type"] == "node_start" and event["node_id"] == "high_step"
                   for event in replay_events(restored))


def test_validator_rejects_changed_gate_choice_even_without_gate_output() -> None:
    from synapse.ir import NodeRun, RunRecord

    original = RunRecord(run_id="a", workflow="branch", mode="baseline", case_id="C",
                         wall_ms=1, nodes=[NodeRun(run_id="a", node_id="gate", start_s=0,
                                                   end_s=.001, branch="yes")])
    changed = original.model_copy(deep=True)
    changed.nodes[0].branch = "no"
    assert not all(check.passed for check in validate([original], [changed], 0))


def test_compiler_rejects_a_pass_that_changes_a_gate_condition() -> None:
    changed = FLOW.model_copy(deep=True)
    changed.nodes[0].condition = "low if amount > 100 else high"
    with pytest.raises(ValueError, match="changed gate"):
        check_rewrite(FLOW, changed, "bad_pass")


def test_graph_rejects_a_missing_branch_member() -> None:
    changed = FLOW.model_copy(deep=True)
    changed.nodes = [node for node in changed.nodes if node.id != "high_step"]
    changed.nodes[-1].inputs = ["low_result"]
    changed.nodes[-1].optional_inputs = ["low_result"]
    with pytest.raises(GraphError, match="missing node high_step"):
        build_graph(changed)


def test_cse_keeps_a_duplicate_result_used_by_a_gate() -> None:
    workflow = parse_workflow({
        "workflow": "gate_input", "input": ["value"],
        "nodes": [
            {"id": "lookup_one", "kind": "retrieve", "effect": "pure",
             "deterministic": True, "index": "complaint_policy", "query": "query",
             "outputs": ["first"]},
            {"id": "lookup_two", "kind": "retrieve", "effect": "pure",
             "deterministic": True, "index": "complaint_policy", "query": "query",
             "outputs": ["second"]},
            {"id": "choose", "kind": "gate", "effect": "pure", "deterministic": True,
             "inputs": ["second"], "condition": "yes if second == 'x' else no",
             "branches": {"yes": ["leaf"], "no": []}},
            {"id": "leaf", "kind": "transform", "effect": "pure", "deterministic": True,
             "tool": "leaf", "outputs": ["result"]},
        ], "output": ["result"],
    })
    plan = compile_workflow(workflow, passes=("cse",))
    assert any(node.id == "lookup_two" for node in plan.workflow.nodes)
    assert any(decision.pass_name == "cse" and "feeds gate" in decision.reason
               for decision in plan.decisions)


def test_untaken_branch_never_sends_an_sms() -> None:
    workflow = parse_workflow({
        "workflow": "conditional_sms", "input": ["amount", "customer_id", "decision"],
        "nodes": [
            {"id": "choose", "kind": "gate", "effect": "pure", "deterministic": True,
             "inputs": ["amount"], "condition": "high if amount > 100 else low",
             "branches": {"high": ["high_sms"], "low": ["low_sms"]}},
            {"id": "high_sms", "kind": "tool", "tool": "sms_gateway",
             "effect": "write", "inputs": ["customer_id", "decision"],
             "outputs": ["high_sent"]},
            {"id": "low_sms", "kind": "tool", "tool": "sms_gateway",
             "effect": "write", "inputs": ["customer_id", "decision"],
             "outputs": ["low_sent"]},
        ], "output": [],
    })
    bank = create_app(scale=0.001)
    plan = compile_workflow(workflow)

    async def collect():
        async with mock_backends(0.001, bank_app=bank,
                                 retriever=KeywordRetriever()) as backends:
            return [(await execute(workflow, {"case_id": str(amount), "amount": amount,
                                             "customer_id": "CUST-A01", "decision": "approve"},
                                   mode, backends, plan=plan if mode == "compiled" else None))
                    for amount in (50, 150) for mode in ("baseline", "compiled")]

    records = asyncio.run(collect())
    assert len(bank.state.sms_log) == len(records) == 4
    for record in records:
        assert not any(node.error for node in record.nodes)
        assert sum(node.skipped for node in record.nodes) == 1
        assert sum(not node.skipped for node in record.nodes if node.node_id.endswith("sms")) == 1
