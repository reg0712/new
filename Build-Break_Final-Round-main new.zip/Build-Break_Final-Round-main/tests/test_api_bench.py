"""M10-M11: local demo routes and measured ablation output."""

from __future__ import annotations

import asyncio
import json

import pytest
from fastapi import HTTPException
from fastapi.testclient import TestClient

from bench.runner import RESULTS_DIR, STEPS, Target, _headline, _summarise, benchmark, target_for
from mock_services import MOCK_TASKS
from synapse import ROOT
from synapse.api import RunState, create_app, measured_gains
from synapse.api import quota_idle_ms, usage_totals
from synapse.backends.llm import MockLLM
from synapse.backends.retrieval import KeywordRetriever
from synapse.compiler import compile_workflow
from synapse.config import load_config
from synapse.parser import load_workflow
from synapse.store import Store
from synapse.ir import Node, NodeRun, RunRecord, Usage, Workflow
from synapse.validator import Check


def test_dashboard_compile_and_websocket_events(tmp_path) -> None:
    app = create_app(db_path=tmp_path / "api.db", results_dir=tmp_path / "results",
                     backend_options={"retriever": KeywordRetriever()})
    with TestClient(app) as client:
        page = client.get("/")
        assert page.status_code == 200 and "SYNAPSE" in page.text
        assert "sourceNotice" in page.text
        assert client.get("/ui/app.js?v=12").status_code == 200
        assert client.get("/ui/style.css?v=12").status_code == 200
        models = client.get("/models").json()
        assert {m["provider"] for m in models} == {"mock", "gemini", "groq", "openrouter"}
        assert len(models) == len({(m["provider"], m["model"]) for m in models})
        groq = next(row for row in models if row["provider"] == "groq")
        assert set(groq["account_remaining"]) == {"original", "compiled"}
        workflows = client.get("/workflows").json()
        assert {row["name"] for row in workflows} >= {"loan_prescreen", "complaint_triage"}
        compiled = client.post("/compile", json={"workflow": "loan_prescreen"}).json()
        assert len(compiled["source"]["nodes"]) == 11
        assert len(compiled["plan"]["workflow"]["nodes"]) == 9
        assert compiled["graph"]["source"]["nodes"]
        for mode, count in (("baseline", 11), ("compiled", 9)):
            started = client.post("/runs", json={"workflow": "loan_prescreen",
                                                  "mode": mode, "case_id": "A01",
                                                  "scale": 0.001}).json()
            run_id = started["run_id"]
            with client.websocket_connect(f"/ws/runs/{run_id}") as websocket:
                events = []
                while True:
                    event = websocket.receive_json()
                    events.append(event)
                    if event["type"] == "run_end":
                        break
            assert sum(e["type"] == "node_start" for e in events) == count
            assert sum(e["type"] == "node_end" for e in events) == count
            assert events[-1]["run_id"] == run_id and events[-1]["error"] is None
            record = client.get(f"/runs/{run_id}").json()
            assert record["status"] == "done" and len(record["nodes"]) == count
            assert record["key_value"] == "approve"
            totals = record["usage_totals"]
            assert totals["tokens_total"] == totals["tokens_in"] + totals["tokens_out"]
            assert totals["cost"] == pytest.approx(sum(n["usage"]["cost"]
                                                       for n in record["nodes"]))


def test_api_marks_retry_unsafe_after_a_completed_write(tmp_path) -> None:
    app = create_app(db_path=tmp_path / "api.db", results_dir=tmp_path / "results",
                     backend_options={"retriever": KeywordRetriever()})
    name, target = app.state.lab.target("complaint_triage")
    state = RunState("test-run", name, target.workflow.name, "baseline", "C01",
                     False, 0, None, target)
    failed = NodeRun(run_id="test-run", node_id="draft_reply", start_s=0,
                     end_s=.01, error="rate limit")
    written = NodeRun(run_id="test-run", node_id="log_ticket", start_s=.02,
                      end_s=.03, output={"ticket": {"id": "TEST-1"}})
    state.record = RunRecord(run_id="test-run", workflow=target.workflow.name,
                             mode="baseline", case_id="C01", wall_ms=30,
                             nodes=[written, failed])
    assert app.state.lab.run_body(state)["rerun_safe"] is False
    state.record.nodes = [failed]
    assert app.state.lab.run_body(state)["rerun_safe"] is True


def test_validation_rejects_provider_without_live_mode(tmp_path) -> None:
    app = create_app(db_path=tmp_path / "api.db", results_dir=tmp_path / "results",
                     backend_options={"retriever": KeywordRetriever()})
    with TestClient(app) as client:
        response = client.post("/validate", json={"workflow": "complaint_triage",
                                                   "provider": "groq"})
        assert response.status_code == 422
        assert "live=true" in response.text


def test_failed_benchmark_run_cannot_claim_token_or_cost_savings() -> None:
    wf = load_workflow(ROOT / "workflows" / "complaint_triage.yaml")
    target = target_for(wf)
    failed = RunRecord(run_id="failed", workflow=wf.name, mode="baseline",
                       case_id="C01", wall_ms=10, nodes=[NodeRun(
                           run_id="failed", node_id="classify_complaint", start_s=0,
                           end_s=.01, usage=Usage(usage_complete=False),
                           error="provider rate limit")])
    row = _summarise(STEPS[0], "cold", wf, None, [failed], target, {})
    assert row["errors"] == 1 and not row["comparable"]
    assert row["mean_tokens_in"] is None and row["mean_cost"] is None
    assert row["p50_ms"] is None
    assert not _headline([row, {**row, "name": "compact_inputs"}])["comparable"]
    assert not _headline([{**row, "name": "compact_inputs"}])["comparable"]


def test_failed_benchmark_row_does_not_crash_compiler_gain_log() -> None:
    result = {"steps": [{"name": "baseline"}, {"name": "parallelise"}],
              "configurations": [
                  {"name": "baseline", "cache": "cold", "p50_ms": 10.0,
                   "mean_cost": 1.0, "comparable": True},
                  {"name": "parallelise", "cache": "cold", "p50_ms": None,
                   "mean_cost": None, "comparable": False}]}
    assert measured_gains(result) == {}
    result["configurations"][1].update(p50_ms=7.0, mean_cost=.8,
                                        comparable=True)
    assert measured_gains(result)["parallelise"]["measured_ms"] == 3.0
    result["configurations"][0]["p50_ms"] = 0.0
    assert measured_gains(result)["parallelise"]["measured_share"] is None


def test_compile_still_loads_graph_with_a_failed_saved_benchmark(tmp_path) -> None:
    results_dir = tmp_path / "results"
    results_dir.mkdir()
    (results_dir / "latest.json").write_text(json.dumps([{
        "workflow": "complaint_triage",
        "steps": [{"name": "baseline"}, {"name": "parallelise"}],
        "configurations": [
            {"name": "baseline", "cache": "cold", "p50_ms": 10.0,
             "mean_cost": 1.0, "comparable": True},
            {"name": "parallelise", "cache": "cold", "p50_ms": None,
             "mean_cost": None, "comparable": False}]
    }]))
    app = create_app(db_path=tmp_path / "api.db", results_dir=results_dir,
                     backend_options={"retriever": KeywordRetriever()})
    with TestClient(app) as client:
        response = client.post("/compile", json={"workflow": "complaint_triage"})
    assert response.status_code == 200, response.text
    assert response.json()["graph"]["compiled"]["nodes"]


def test_benchmark_counts_actual_model_calls_after_retries() -> None:
    wf = Workflow(name="calls", inputs=["x"], nodes=[Node(
        id="answer", kind="llm", model="large", prompt="prompt.txt", effect="pure",
        inputs=["x"], outputs=["answer"])])
    target = Target(workflow=wf, cases=[{"case_id": "C01", "x": "test"}])
    node = NodeRun(run_id="r1", node_id="answer", start_s=0, end_s=.01,
                   retries=2, usage=Usage(calls=3, retries=2, tokens_in=10))
    record = RunRecord(run_id="r1", workflow="calls", mode="baseline",
                       case_id="C01", wall_ms=10, nodes=[node])
    row = _summarise(STEPS[0], "cold", wf, None, [record], target, {"C01": {}})
    assert row["mean_llm_calls"] == 3
    node.usage.calls = 0  # legacy trace before explicit call accounting
    node.usage.retries = 0
    assert _summarise(STEPS[0], "cold", wf, None, [record], target,
                      {"C01": {}})["mean_llm_calls"] == 3
    node.skipped = True
    assert _summarise(STEPS[0], "cold", wf, None, [record], target,
                      {"C01": {}})["mean_llm_calls"] == 0
    wf.nodes.append(Node(id="lookup", kind="tool", tool="lookup", effect="read",
                         outputs=["lookup"]))
    record.nodes.append(NodeRun(run_id="r1", node_id="lookup", start_s=.01,
                                end_s=.01, skipped=True))
    assert _summarise(STEPS[0], "cold", wf, None, [record], target,
                      {"C01": {}})["mean_tool_calls"] == 0


def test_benchmark_subset_without_original_has_no_headline() -> None:
    measured = {"name": "compact_inputs", "cache": "cold", "comparable": True,
                "p50_ms": 10, "p95_ms": 12, "mean_cost": 1,
                "mean_llm_calls": 1, "correct_rate": 1}
    summary = _headline([measured, {**measured, "name": "parallelise"}])
    assert summary["comparable"] is False
    assert "baseline" in summary["reason"]


def test_repeated_case_reuses_model_results_but_writes_once_per_run(tmp_path) -> None:
    from mock_services.bank_api import create_app as bank_app
    bank = bank_app(scale=.001)
    app = create_app(db_path=tmp_path / "api.db", results_dir=tmp_path / "results",
                     backend_options={"retriever": KeywordRetriever(), "bank_app": bank})
    with TestClient(app) as client:
        client.post("/compile", json={"workflow": "complaint_triage"})
        bank.state.ticket_log.clear()  # exclude measured profiling cases
        records = []
        for cache_mode in ("warm", "warm", "cold"):
            response = client.post("/runs", json={"workflow": "complaint_triage",
                                  "mode": "compiled", "case_id": "C01", "scale": .001,
                                  "cache_mode": cache_mode})
            assert response.status_code == 200
            id = response.json()["run_id"]
            with client.websocket_connect(f"/ws/runs/{id}") as websocket:
                while websocket.receive_json()["type"] != "run_end":
                    pass
            records.append(client.get(f"/runs/{id}").json())
            assert records[-1]["status"] == "done"
        assert len(bank.state.ticket_log) == 3
        assert [r["cold_cache"] for r in records] == [True, False, True]
        assert records[0]["usage_totals"]["tokens_total"] > 0
        assert records[1]["usage_totals"]["tokens_total"] == 0
        assert records[2]["usage_totals"]["tokens_total"] > 0
        assert records[0]["cache_metrics"]["misses"] > 0
        assert records[1]["cache_metrics"]["hits"] > 0
        assert records[2]["cache_metrics"]["hits"] == 0
        assert records[0]["key_value"] == records[1]["key_value"] == records[2]["key_value"]
        assert all(next(n for n in r["nodes"] if n["node_id"] == "log_ticket")["cache_hit"] is False
                   for r in records)
        with Store(tmp_path / "api.db") as store:
            restored = store.load_run(records[0]["run_id"])
            assert restored.nodes[0].usage.model_dump() == records[0]["nodes"][0]["usage"]


def test_quota_idle_excludes_only_time_when_every_active_step_waits() -> None:
    record = RunRecord(run_id="timing", workflow="test", mode="compiled", case_id="T1",
                       wall_ms=10000, nodes=[
        NodeRun(run_id="timing", node_id="model", start_s=0, end_s=10,
                usage=Usage(quota_wait_ms=5000, quota_wait_intervals=[(2, 7)])),
        NodeRun(run_id="timing", node_id="read", start_s=0, end_s=4),
    ])
    assert quota_idle_ms(record) == pytest.approx(3000)
    assert usage_totals(record)["quota_idle_ms"] == pytest.approx(3000)
    record.nodes[1].usage.quota_wait_intervals = [(1, 4)]
    assert quota_idle_ms(record) == pytest.approx(5000)


def test_bundled_benchmark_example_covers_every_workflow() -> None:
    data = json.loads((ROOT / "bench" / "sample_mock.json").read_text())
    assert {row["workflow"] for row in data} == {
        "loan_prescreen", "complaint_triage", "research_agent", "research_llm"}
    assert all(row["sample"] and row["mode"] == "mock" for row in data)
    for result in data:
        cold = [row for row in result["configurations"] if row["cache"] == "cold"]
        assert cold[0]["name"] == "baseline" and cold[-1]["name"] == "memoise"
        assert cold[-1]["correct"] == cold[-1]["runs"]


def test_dashboard_uses_bundled_mock_example_when_no_local_benchmark(
        tmp_path, monkeypatch) -> None:
    monkeypatch.setattr("synapse.api.results_path",
                        lambda _live, _directory: tmp_path / "missing.json")
    app = create_app(db_path=tmp_path / "api.db", results_dir=RESULTS_DIR)
    with TestClient(app) as client:
        data = client.get("/bench/latest").json()
        assert len(data) == 4 and all(row["sample"] for row in data)
        assert client.get("/bench/latest?mode=live").status_code == 404


def test_benchmark_has_cold_warm_ablation_and_correctness() -> None:
    wf = load_workflow(ROOT / "workflows" / "loan_prescreen.yaml")
    result = asyncio.run(benchmark(wf, repeats=2, scale=0.001, case_ids=["A01", "A03"]))
    assert [(c["name"], c["cache"]) for c in result["configurations"]] == [
        ("baseline", "cold"), ("baseline", "warm"),
        ("dead_nodes", "cold"), ("cse", "cold"), ("compact_inputs", "cold"),
        ("parallelise", "cold"), ("routing", "cold"),
        ("memoise", "cold"), ("memoise", "warm")]
    assert all(c["runs"] == 4 and c["correct"] == 4 and c["errors"] == 0
               for c in result["configurations"])


def test_requested_plan_failure_does_not_erase_accepted_routing_proof(
        tmp_path, monkeypatch) -> None:
    from synapse import validator

    db = tmp_path / "api.db"
    app = create_app(db_path=db, results_dir=tmp_path / "results",
                     backend_options={"retriever": KeywordRetriever()})
    lab = app.state.lab
    name, target = lab.target("complaint_triage")
    accepted = compile_workflow(target.workflow,
                                passes=("dead_nodes", "cse", "compact_inputs", "parallelise", "memoise", "routing"),
                                routing_probe=True)
    requested = compile_workflow(target.workflow, passes=())
    lab.remember(name, requested)

    async def approved(*_args, **_kwargs):
        return accepted, [Check(case_id=case["case_id"], node_id="triage.category",
                                kind="decision", passed=True) for case in target.cases], 0.0

    monkeypatch.setattr(validator, "validate_workflow", approved)
    monkeypatch.setattr(validator, "validate", lambda *_args, **_kwargs: [
        Check(case_id="C01", node_id="triage.category", kind="decision", passed=False)])
    with TestClient(app) as client:
        response = client.post("/validate", json={"workflow": name,
                                                  "plan_id": requested.plan_id, "scale": 0})
    assert response.status_code == 200
    assert response.json()["passed"] == 0
    with Store(db) as store:
        assert store.route_validated(target.workflow)


def test_live_run_needs_proof_for_its_actual_provider_and_models(tmp_path) -> None:
    db = tmp_path / "api.db"
    lab = create_app(db_path=db, results_dir=tmp_path / "results").state.lab
    _, target = lab.target("loan_prescreen")
    routed = compile_workflow(target.workflow,
                              passes=("dead_nodes", "cse", "compact_inputs", "parallelise", "memoise", "routing"),
                              routing_probe=True)
    assert any(node.fallback_model for node in routed.workflow.nodes)
    safe = lab.live_plan(target, routed, explicit=False)
    assert not any(node.fallback_model for node in safe.workflow.nodes)
    with pytest.raises(HTTPException, match="has not passed validation"):
        lab.live_plan(target, routed, explicit=True)

    models = load_config("models.yaml")
    provider = models["live_provider"]
    tiers = models["providers"][provider]
    names = {tier: str(tiers[tier]) for tier in ("small", "large")}
    with Store(db) as store:
        store.save_validation(target.workflow, routed,
                              [case["case_id"] for case in target.cases], True,
                              provider=provider, model_names=names)
    assert lab.live_plan(target, routed, explicit=True) is routed


def test_dashboard_can_choose_groq_without_real_network(tmp_path, monkeypatch) -> None:
    monkeypatch.setattr("synapse.backends.load_env", lambda: None)
    fake = MockLLM(MOCK_TASKS, {"small": 0, "large": 0},
                   load_config("models.yaml")["providers"]["groq"], scale=0)
    app = create_app(db_path=tmp_path / "api.db", results_dir=tmp_path / "results",
                     backend_options={"retriever": KeywordRetriever(), "llm": fake})
    with TestClient(app) as client:
        invalid = client.post("/runs", json={"workflow": "complaint_triage", "case_id": "C01",
                                               "provider": "mock", "live": True})
        assert invalid.status_code == 422
        started = client.post("/runs", json={"workflow": "complaint_triage", "case_id": "C01",
                                               "provider": "groq", "model": "openai/gpt-oss-20b",
                                               "scale": 0}).json()
        assert started["provider"] == "groq" and started["live"]
        assert started["model"] == "openai/gpt-oss-20b"
        with client.websocket_connect(f"/ws/runs/{started['run_id']}") as websocket:
            while websocket.receive_json()["type"] != "run_end":
                pass
        record = client.get(f"/runs/{started['run_id']}").json()
        assert record["status"] == "done" and record["key_value"] == "failed_transfer"
        assert record["provider"] == "groq"
