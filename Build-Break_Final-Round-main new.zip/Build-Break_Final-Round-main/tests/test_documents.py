"""PDF intake: text PDFs are read from their text layer without Tesseract, scans are OCR'd,
both feed the loan workflow to the rule's decision, bad uploads fail with operator-readable
errors, repeat uploads come from the content cache, and OCR leaves the event loop free.
Every PDF is built here from the synthetic applicants; no binaries are committed."""

from __future__ import annotations

import asyncio
import hashlib
import io
import sys
import time
from typing import Any

import pytest
from fpdf import FPDF
from PIL import Image, ImageDraw, ImageFont

from mock_services import loan, suite_for
from synapse import ROOT, documents
from synapse.backends import mock_backends
from synapse.backends.retrieval import KeywordRetriever
from synapse.documents import (DocumentSettings, EncryptedPDF, Extraction, MalformedPDF,
                               OCRUnavailable, PDFTooLarge, UnreadablePDF, application_case,
                               extract_text, extract_text_async)
from synapse.executor import execute, final_outputs, resolve
from synapse.parser import load_workflow

LOAN = load_workflow(ROOT / "workflows" / "loan_prescreen.yaml")
SUITE = suite_for("loan_prescreen")
A01 = loan.applicant("A01")
A01_TEXT = loan.application_text(A01)
A01_FIELDS = {"name": A01["name"], "pan": A01["pan"], "income": A01["income"],
              "employment": A01["employment"], "requested_amount": A01["requested_amount"]}


def _tesseract_missing() -> bool:
    try:
        documents.resolve_tesseract(DocumentSettings.load())
    except OCRUnavailable:
        return True
    return False


needs_tesseract = pytest.mark.skipif(_tesseract_missing(),
                                     reason="tesseract binary not found; run make setup")


# Synthetic PDFs.

def text_pdf(text: str = A01_TEXT, pages: int = 1, **encryption: str) -> bytes:
    """A PDF with a real text layer, one copy of text per page."""
    pdf = FPDF()
    if encryption:
        pdf.set_encryption(**encryption)
    for _ in range(pages):
        pdf.add_page()
        pdf.set_font("Helvetica", size=11)
        for line in text.split("\n"):
            pdf.cell(0, 6, line, new_x="LMARGIN", new_y="NEXT")
    return bytes(pdf.output())


def page_image(text: str = A01_TEXT) -> Image.Image:
    """The text drawn large and clear on a white page, as a scanner would capture it."""
    image = Image.new("L", (1700, 1100), 255)
    draw = ImageDraw.Draw(image)
    font = ImageFont.load_default(size=40)
    for row, line in enumerate(text.split("\n")):
        draw.text((80, 60 + 70 * row), line, font=font, fill=0)
    return image


def scanned_pdf(*images: Image.Image) -> bytes:
    """An image-only PDF (no text layer) of the given page images."""
    first, *rest = images or (page_image(),)
    buffer = io.BytesIO()
    first.save(buffer, format="PDF", resolution=200, save_all=True, append_images=rest)
    return buffer.getvalue()


def blank_scan() -> bytes:
    return scanned_pdf(Image.new("L", (1700, 1100), 255))


class FakeStore:
    """In-memory stand-in for Store's content-addressed cache."""

    def __init__(self) -> None:
        self.rows: dict[tuple[str, str], tuple[bytes, dict[str, Any]]] = {}
        self.gets = self.puts = 0

    def get_by_content(self, kind: str, content: bytes) -> dict[str, Any] | None:
        self.gets += 1
        row = self.rows.get((kind, hashlib.sha256(content).hexdigest()))
        return dict(row[1]) if row and row[0] == content else None

    def put_by_content(self, kind: str, content: bytes, value: dict[str, Any],
                       ttl_s: int | None = None) -> str:
        assert ":" not in kind
        self.puts += 1
        digest = hashlib.sha256(content).hexdigest()
        self.rows[(kind, digest)] = (bytes(content), dict(value))
        return digest


def forbid_ocr(monkeypatch: pytest.MonkeyPatch) -> None:
    """Make any OCR attempt fail the test, including importing pytesseract."""
    def fail(*_: Any, **__: Any) -> Any:
        raise AssertionError("OCR ran")
    monkeypatch.setattr(documents, "_ocr_pages", fail)
    monkeypatch.setitem(sys.modules, "pytesseract", None)


def parsed(extraction: Extraction) -> dict[str, Any]:
    return loan.parse_application({"application_pdf": extraction.text})


@pytest.fixture(scope="module")
def scan_store() -> FakeStore:
    return FakeStore()


@pytest.fixture(scope="module")
def scanned(scan_store: FakeStore) -> tuple[bytes, Extraction]:
    """A01's application as a scan, OCR'd once for the module at the default settings."""
    if _tesseract_missing():
        pytest.skip("tesseract binary not found; run make setup")
    data = scanned_pdf()
    return data, extract_text(data, store=scan_store)


# Text and OCR extraction.

def test_text_pdf_is_read_from_its_text_layer_without_tesseract(
        monkeypatch: pytest.MonkeyPatch) -> None:
    forbid_ocr(monkeypatch)
    monkeypatch.setattr(documents, "resolve_tesseract", lambda *_: pytest.fail("looked up"))
    data = text_pdf()
    extraction = extract_text(data)
    assert (extraction.method, extraction.pages, extraction.ocr_pages) == ("text", 1, [])
    assert extraction.sha256 == hashlib.sha256(data).hexdigest()
    assert not extraction.from_cache
    assert parsed(extraction) == A01_FIELDS


def test_scanned_pdf_is_ocrd_to_the_same_fields(scanned: tuple[bytes, Extraction]) -> None:
    _, extraction = scanned
    assert (extraction.method, extraction.pages, extraction.ocr_pages) == ("ocr", 1, [1])
    assert parsed(extraction) == A01_FIELDS


def test_text_and_scanned_pages_together_are_mixed(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[list[int]] = []

    def fake_ocr(data: bytes, indexes: list[int], settings: DocumentSettings) -> list[documents.PageOCR]:
        calls.append(indexes)
        return [documents.PageOCR("Tenure: 36 months\nPurpose: home renovation and more")
                for _ in indexes]
    monkeypatch.setattr(documents, "_ocr_pages", fake_ocr)
    first = text_pdf()
    scan = scanned_pdf()
    from pypdf import PdfReader, PdfWriter
    writer = PdfWriter()
    for blob in (first, scan):
        writer.append(PdfReader(io.BytesIO(blob)))
    buffer = io.BytesIO()
    writer.write(buffer)
    extraction = extract_text(buffer.getvalue())
    assert calls == [[1]]
    assert (extraction.method, extraction.pages, extraction.ocr_pages) == ("mixed", 2, [2])
    assert parsed(extraction) == A01_FIELDS


def test_ocr_always_reads_text_pdfs_through_tesseract_too(monkeypatch: pytest.MonkeyPatch
                                                         ) -> None:
    monkeypatch.setattr(documents, "_ocr_pages", lambda data, indexes, s:
                        [documents.PageOCR(A01_TEXT) for _ in indexes])
    extraction = extract_text(text_pdf(), settings=DocumentSettings.load(ocr="always"))
    assert (extraction.method, extraction.ocr_pages) == ("ocr", [1])


def test_normalise_text_keeps_line_breaks_and_squeezes_whitespace() -> None:
    raw = "  PAN:  FAKEP0001A \r\n\r\n\r\n\tNet monthly   income: INR 85,000\x0cﬁne  "
    assert documents.normalise_text(raw) == ("PAN: FAKEP0001A\n\nNet monthly income: "
                                             "INR 85,000\nfine")


def test_ocr_letter_digit_swaps_in_a_pan_are_repaired_only_into_valid_pans() -> None:
    repair = documents._repair_ocr_identifiers
    assert repair("PAN: FAKEPOO01A\nCustomer ID: CUST-AO1") == "PAN: FAKEP0001A\nCustomer ID: CUST-AO1"
    assert repair("PAN; fakepoo01a") == "PAN: FAKEP0001A"
    assert repair("PAN: FAKEPOOO1A") == "PAN: FAKEP0001A"
    assert repair("PAN: F4KEPXXXXA") == "PAN: F4KEPXXXXA"   # cannot become a PAN: untouched


# End to end through the loan workflow.

@pytest.mark.parametrize("kind", ["text", "scanned"])
def test_uploaded_pdf_reaches_the_rule_decision(kind: str, scanned: tuple[bytes, Extraction],
                                               scan_store: FakeStore) -> None:
    data, store = (text_pdf(), FakeStore()) if kind == "text" else (scanned[0], scan_store)
    case = application_case(data, A01["customer_id"], "A01", store=store)
    assert {k: case[k] for k in LOAN.inputs} == {"application_pdf": case["application_pdf"],
                                                 "customer_id": "CUST-A01"}
    assert "text" not in case["document"] and case["document"]["chars"] > 0

    async def run() -> Any:
        async with mock_backends(0.001, retriever=KeywordRetriever()) as backends:
            return await execute(LOAN, case, "baseline", backends)
    record = asyncio.run(run())
    assert all(node.error is None for node in record.nodes)
    assert resolve(SUITE.key_field, final_outputs(record)) == SUITE.expected("A01")
    assert final_outputs(record)["applicant"] == A01_FIELDS


def test_application_case_needs_a_customer_id() -> None:
    with pytest.raises(ValueError, match="customer_id"):
        application_case(text_pdf(), "  ")


# Refused uploads.

def assert_no_content(error: Exception) -> None:
    message = str(error)
    for secret in (A01["name"], A01["pan"], "85,000", A01["employer"]):
        assert secret not in message
    assert error.__cause__ is None


@pytest.mark.parametrize("encryption", [{"owner_password": "owner-only"},
                                        {"owner_password": "o", "user_password": "u"}],
                         ids=["empty-user-password", "user-password"])
def test_encrypted_pdfs_are_refused(encryption: dict[str, str]) -> None:
    with pytest.raises(EncryptedPDF, match="password-protected") as error:
        extract_text(text_pdf(**encryption))
    assert_no_content(error.value)


def test_oversized_bytes_are_refused_before_parsing(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(documents, "_open_pdf", lambda *_: pytest.fail("parsed"))
    with pytest.raises(PDFTooLarge, match="limit is"):
        extract_text(text_pdf(), settings=DocumentSettings.load(max_bytes=500))


def test_load_pdf_refuses_big_files_without_reading_them(tmp_path: Any,
                                                        monkeypatch: pytest.MonkeyPatch) -> None:
    path = tmp_path / "huge.pdf"
    with path.open("wb") as handle:
        handle.truncate(11 * 1024 * 1024)   # sparse: no 11 MB written
    small = tmp_path / "small.pdf"
    small.write_bytes(text_pdf())
    settings = DocumentSettings.load()
    assert documents.load_pdf(small, settings) == small.read_bytes()
    monkeypatch.setattr(type(path), "open", lambda *_, **__: pytest.fail("read"))
    with pytest.raises(PDFTooLarge, match="11.0 MB; the limit is 10.0 MB"):
        documents.load_pdf(path, settings)


def test_too_many_pages_are_refused() -> None:
    with pytest.raises(PDFTooLarge, match="3 pages; the limit is 2"):
        extract_text(text_pdf(pages=3), settings=DocumentSettings.load(max_pages=2))


@pytest.mark.parametrize("data", [b"", b"PERSONAL LOAN APPLICATION\nPAN: FAKEP0001A",
                                  b"\x89PNG\r\n\x1a\n" + bytes(64)],
                         ids=["empty", "plain-text", "png"])
def test_non_pdfs_are_refused(data: bytes) -> None:
    with pytest.raises(MalformedPDF) as error:
        extract_text(data)
    assert_no_content(error.value)


@pytest.mark.parametrize("cut", ["half", "tail", "garbage"])
def test_damaged_pdfs_are_refused(cut: str) -> None:
    data = text_pdf()
    damaged = {"half": data[:len(data) // 2], "tail": data[:-200],
               "garbage": b"%PDF-1.7\n" + bytes(range(256)) * 20}[cut]
    with pytest.raises(MalformedPDF, match="damaged") as error:
        extract_text(damaged)
    assert_no_content(error.value)


def test_blank_scan_with_ocr_off_is_unreadable(monkeypatch: pytest.MonkeyPatch) -> None:
    forbid_ocr(monkeypatch)
    with pytest.raises(UnreadablePDF, match="OCR is turned off"):
        extract_text(blank_scan(), settings=DocumentSettings.load(ocr="never"))


@needs_tesseract
def test_blank_scan_with_ocr_is_unreadable() -> None:
    with pytest.raises(UnreadablePDF, match="clearer scan"):
        extract_text(blank_scan(), settings=DocumentSettings.load(dpi=100))


def test_ocr_with_a_missing_tesseract_binary_is_unavailable(tmp_path: Any) -> None:
    settings = DocumentSettings.load(tesseract_cmd=str(tmp_path / "no-such-tesseract"))
    with pytest.raises(OCRUnavailable, match="tesseract_cmd"):
        extract_text(scanned_pdf(), settings=settings)
    # A text PDF needs no OCR, so the same broken setting does not matter.
    assert extract_text(text_pdf(), settings=settings).method == "text"


def test_ocr_without_any_tesseract_install_is_unavailable(tmp_path: Any,
                                                         monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(documents.shutil, "which", lambda *_: None)
    monkeypatch.setattr(documents.sys, "executable", str(tmp_path / "python"))
    with pytest.raises(OCRUnavailable, match="not installed"):
        extract_text(scanned_pdf())


def test_settings_reject_unknown_keys_and_bad_values() -> None:
    assert DocumentSettings.load() == DocumentSettings()
    with pytest.raises(ValueError, match="unknown"):
        DocumentSettings.load(dpii=300)
    with pytest.raises(ValueError, match="ocr must be"):
        DocumentSettings.load(ocr="sometimes")
    assert DocumentSettings.load(ocr=False).ocr == "never"


# Content cache.

def test_repeat_upload_is_served_from_cache_without_ocr(
        scanned: tuple[bytes, Extraction], scan_store: FakeStore,
        monkeypatch: pytest.MonkeyPatch) -> None:
    data, first = scanned
    forbid_ocr(monkeypatch)
    again = extract_text(data, store=scan_store)
    assert again.from_cache and not first.from_cache
    assert (again.text, again.method, again.ocr_pages, again.sha256) == (
        first.text, first.method, first.ocr_pages, first.sha256)
    assert parsed(again) == A01_FIELDS


def test_cache_misses_when_settings_or_bytes_change(scanned: tuple[bytes, Extraction],
                                                    scan_store: FakeStore,
                                                    monkeypatch: pytest.MonkeyPatch) -> None:
    data, _ = scanned
    calls: list[int] = []

    def fake_ocr(data: bytes, indexes: list[int], settings: DocumentSettings) -> list[documents.PageOCR]:
        calls.append(settings.dpi)
        return [documents.PageOCR(A01_TEXT) for _ in indexes]
    monkeypatch.setattr(documents, "_ocr_pages", fake_ocr)
    assert not extract_text(data, settings=DocumentSettings.load(dpi=200),
                            store=scan_store).from_cache
    assert not extract_text(data, settings=DocumentSettings.load(lang="eng+hin"),
                            store=scan_store).from_cache
    assert not extract_text(data + b"\n", store=scan_store).from_cache
    assert calls == [200, 300, 300]
    kinds = {kind for kind, _ in scan_store.rows}
    assert all("tesseract-" in kind for kind in kinds) and len(kinds) == 3


def test_failed_extractions_are_not_cached() -> None:
    store = FakeStore()
    with pytest.raises(UnreadablePDF):
        extract_text(blank_scan(), settings=DocumentSettings.load(ocr="never"), store=store)
    assert store.puts == 0


def test_a_broken_cache_does_not_block_intake() -> None:
    class Broken:
        def get_by_content(self, kind: str, content: bytes) -> None:
            raise OSError("database is locked")

        def put_by_content(self, *_: Any, **__: Any) -> str:
            raise OSError("database is locked")
    assert extract_text(text_pdf(), store=Broken()).method == "text"


@needs_tesseract
def test_real_store_dedups_repeat_uploads_from_the_async_path(
        tmp_path: Any, monkeypatch: pytest.MonkeyPatch) -> None:
    from synapse.store import Store

    data = scanned_pdf(page_image(loan.application_text(loan.applicant("A02"))))
    settings = DocumentSettings.load(dpi=200)

    async def twice(store: Store) -> tuple[Extraction, Extraction]:
        first = await extract_text_async(data, settings=settings, store=store)
        forbid_ocr(monkeypatch)
        return first, await extract_text_async(data, settings=settings, store=store)
    with Store(tmp_path / "synapse.db") as store:
        first, second = asyncio.run(twice(store))
    assert (first.from_cache, second.from_cache) == (False, True)
    assert first.method == second.method == "ocr" and second.text == first.text
    assert loan.parse_application({"application_pdf": second.text})["pan"] == \
        loan.applicant("A02")["pan"]


def test_targeted_pan_reread_requires_consistent_valid_readings() -> None:
    from PIL import Image

    class Tesseract:
        def __init__(self, readings: list[str]) -> None:
            self.readings = iter(readings)

        def image_to_string(self, image, *, lang, config, timeout):
            return next(self.readings)

    image = Image.new("L", (200, 60), "white")
    settings = DocumentSettings.load()
    agreed = Tesseract(["PAN: FAKEP0004D"] * 5)
    assert documents._reread_pan(agreed, image, (5, 5, 180, 35),
                                 "FAKEPOOO04D", settings, None) == "FAKEP0004D"
    conflicting = Tesseract(["PAN: FAKEP0004D", "PAN: FAKEP0004E",
                             "PAN: FAKEP0004D", "PAN: FAKEP0004E", "unreadable"])
    assert documents._reread_pan(conflicting, image, (5, 5, 180, 35),
                                 "FAKEPOOO04D", settings, None) is None


# The event loop during OCR.

async def _max_tick_gap(work: Any) -> tuple[float, float]:
    """Run work beside a 10 ms ticker; returns (work seconds, longest gap between ticks)."""
    gaps: list[float] = []
    done = asyncio.Event()

    async def ticker() -> None:
        last = time.perf_counter()
        while not done.is_set():
            await asyncio.sleep(0.01)
            now = time.perf_counter()
            gaps.append(now - last)
            last = now
    task = asyncio.create_task(ticker())
    await asyncio.sleep(0.03)
    started = time.perf_counter()
    await work()
    elapsed = time.perf_counter() - started
    await asyncio.sleep(0.03)
    done.set()
    await task
    return elapsed, max(gaps)


@needs_tesseract
def test_async_extraction_keeps_the_event_loop_responsive() -> None:
    data = scanned_pdf()

    async def offloaded() -> None:
        assert (await extract_text_async(data)).method == "ocr"

    async def blocking() -> None:
        assert extract_text(data).method == "ocr"
    async_s, async_gap = asyncio.run(_max_tick_gap(offloaded))
    sync_s, sync_gap = asyncio.run(_max_tick_gap(blocking))
    print(f"\nOCR wall time: async {async_s * 1000:.0f} ms, sync {sync_s * 1000:.0f} ms; "
          f"max ticker gap: async {async_gap * 1000:.1f} ms, sync {sync_gap * 1000:.1f} ms")
    assert async_gap < 0.1                 # ticks keep coming every ~10 ms during OCR
    assert sync_gap > 0.8 * sync_s         # the blocking call starves the loop for the whole OCR
