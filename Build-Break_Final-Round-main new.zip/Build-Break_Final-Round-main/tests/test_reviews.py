"""The review sentiment workflow: user-supplied review text in, one schema-checked sentiment out,
kept apart from the bank complaint workflow."""

from __future__ import annotations

import asyncio
from collections import Counter

import pytest
from pydantic import ValidationError

from mock_services import MOCK_TASKS, SUITES, reviews, suite_for
from synapse import ROOT
from synapse.backends import mock_backends
from synapse.backends.llm import load_schema, output_schema
from synapse.backends.retrieval import KeywordRetriever
from synapse.compiler import compile_workflow
from synapse.executor import execute, final_outputs, resolve
from synapse.graph import build_graph
from synapse.ir import Effect, NodeKind
from synapse.parser import load_workflow

WORKFLOW = load_workflow(ROOT / "workflows" / "review_sentiment.yaml")
SUITE = suite_for(WORKFLOW.name)
SENTIMENT = load_schema("review_sentiment.json")
GOOD = {"sentiment": "positive", "confidence": 0.8, "explanation": "Praises the staff."}


def test_review_workflow_has_valid_dependencies_and_only_pure_steps() -> None:
    graph = build_graph(WORKFLOW)
    assert WORKFLOW.inputs == ["review_text", "star_rating"]
    assert WORKFLOW.outputs == ["sentiment", "aspects"]
    assert [(node.id, node.kind, node.effect, node.model) for node in WORKFLOW.nodes] == [
        ("extract_aspects", NodeKind.LLM, Effect.PURE, "small"),
        ("judge_tone", NodeKind.LLM, Effect.PURE, "large"),
        ("score_sentiment", NodeKind.LLM, Effect.PURE, "large"),
    ]
    assert set(graph.predecessors("score_sentiment")) == {"extract_aspects", "judge_tone"}
    for node in WORKFLOW.nodes:
        assert "{inputs}" in (ROOT / str(node.prompt)).read_text(), node.id
        assert output_schema(node) is not None, node.id


def test_review_workflow_is_separate_from_complaint_triage() -> None:
    assert not [node for node in WORKFLOW.nodes if node.effect is Effect.WRITE]
    assert not [node for node in WORKFLOW.nodes if node.kind is not NodeKind.LLM]
    assert SUITE is SUITES["review_sentiment"] and SUITE is not SUITES["complaint_triage"]
    assert SUITE.key_field == "sentiment.sentiment"
    complaint = load_workflow(ROOT / "workflows" / "complaint_triage.yaml")
    assert not {node.prompt for node in WORKFLOW.nodes} & {node.prompt for node in complaint.nodes}
    assert set(reviews.MOCK_TASKS) == {"extract_review_aspects", "judge_review_tone",
                                       "score_review_sentiment"}
    assert all(MOCK_TASKS[name] is task for name, task in reviews.MOCK_TASKS.items())


def test_review_set_is_synthetic_and_balanced() -> None:
    rows = reviews.load_reviews()
    assert [row["case_id"] for row in rows] == [f"R{n:02d}" for n in range(1, 19)]
    assert all(row["source"] == "synthetic" for row in rows)
    assert Counter(row["expected_sentiment"] for row in rows) == {
        "positive": 6, "neutral": 6, "negative": 6}
    assert {row["star_rating"] for row in rows} >= {None, 1, 3, 5}


@pytest.mark.parametrize("bad", [
    {**GOOD, "confidence": 1.5}, {**GOOD, "confidence": -0.1},
    {**GOOD, "sentiment": "mixed"}, {**GOOD, "sentiment": "Positive"},
    {key: value for key, value in GOOD.items() if key != "confidence"},
    {key: value for key, value in GOOD.items() if key != "explanation"},
    {**GOOD, "explanation": "x" * 241}, {**GOOD, "extra": 1}])
def test_sentiment_schema_rejects_bad_results(bad) -> None:
    with pytest.raises(ValidationError):
        SENTIMENT.model_validate(bad)


def test_sentiment_schema_accepts_its_bounds() -> None:
    for confidence in (0, 0.0, 1, 1.0):
        assert SENTIMENT.model_validate({**GOOD, "confidence": confidence}).confidence == confidence
    assert SENTIMENT.model_validate({**GOOD, "explanation": "x" * 240})
    tone = load_schema("review_tone.json")
    with pytest.raises(ValidationError):
        tone.model_validate({"polarity": "neutral", "sarcastic": False, "intensity": 2})


def test_compiler_optimises_the_review_workflow_without_hand_tuning() -> None:
    plan = compile_workflow(WORKFLOW)
    applied = {d.pass_name for d in plan.decisions if d.status == "applied"}
    assert "parallelise" in applied
    assert any(d.pass_name == "parallelise" and set(d.nodes) == {"extract_aspects", "judge_tone"}
               and d.status == "applied" for d in plan.decisions)
    assert [node.id for node in plan.workflow.nodes] == [node.id for node in WORKFLOW.nodes]


def test_every_review_gets_the_expected_schema_valid_sentiment_in_both_modes() -> None:
    plan = compile_workflow(WORKFLOW)

    async def collect() -> None:
        async with mock_backends(0.001, retriever=KeywordRetriever()) as backends:
            for case in SUITE.cases():
                baseline = await execute(WORKFLOW, case, "baseline", backends)
                compiled = await execute(WORKFLOW, case, "compiled", backends, plan=plan)
                for run in (baseline, compiled):
                    assert not [node.error for node in run.nodes if node.error], case["case_id"]
                    result = final_outputs(run)
                    assert resolve(SUITE.key_field, result) == SUITE.expected(case["case_id"])
                    sentiment = SENTIMENT.model_validate(result["sentiment"])
                    assert 0 <= sentiment.confidence <= 1
                    assert 0 < len(sentiment.explanation) <= 240
                assert final_outputs(baseline) == final_outputs(compiled), case["case_id"]

    asyncio.run(collect())


def test_hard_reviews_are_read_for_meaning() -> None:
    def run(case_id: str) -> dict:
        case = SUITE.case(case_id)
        aspects = reviews.extract_review_aspects(case)
        tone = reviews.judge_review_tone(case)
        return reviews.score_review_sentiment({**case, "aspects": aspects, "tone": tone})

    sarcastic = run("R04")
    assert sarcastic["sentiment"] == "negative" and "sarcastic" in sarcastic["explanation"]
    conflicted = run("R13")  # five stars on a one-star text
    assert conflicted["sentiment"] == "negative"
    assert "5-star" in conflicted["explanation"] and conflicted["confidence"] < run("R07")[
        "confidence"]
    assert run("R06")["sentiment"] == "neutral"  # praise and criticism cancel out
    assert run("R17")["sentiment"] == "positive"  # "not a single problem"
