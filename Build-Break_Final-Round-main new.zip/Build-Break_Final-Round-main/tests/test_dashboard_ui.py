"""The dashboard page and its assets load offline, and the PDF upload and review sentiment
panels are present in the page and wired up in app.js. No browser runs here: these check the
served files, the element ids the script reads, and that the script parses."""

from __future__ import annotations

import re
import shutil
import subprocess
from collections.abc import Iterator
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from synapse import ROOT
from synapse.api import create_app
from synapse.backends.retrieval import KeywordRetriever

PDF_IDS = ["pdfForm", "pdfFile", "pdfCustomer", "pdfCustomers", "pdfMode",
           "pdfScale", "pdfModel", "pdfRun", "pdfBudget", "pdfStatus", "pdfDocument",
           "pdfTimer", "pdfResult", "pdfGantt"]
REVIEW_IDS = ["reviewCase", "reviewMode", "reviewScale", "reviewModel", "reviewRun",
              "reviewBudget", "reviewStatus", "reviewTimer", "reviewResult"]


@pytest.fixture
def client(tmp_path: Path) -> Iterator[TestClient]:
    app = create_app(db_path=tmp_path / "api.db", results_dir=tmp_path / "results",
                     backend_options={"retriever": KeywordRetriever()})
    with TestClient(app) as test_client:
        yield test_client


@pytest.fixture
def page(client: TestClient) -> str:
    response = client.get("/")
    assert response.status_code == 200
    return response.text


def asset_urls(page: str) -> list[str]:
    return re.findall(r'(?:src|href)="(/ui/[^"]+)"', page)


def test_page_and_versioned_assets_load_from_this_server(client: TestClient, page: str) -> None:
    urls = asset_urls(page)
    assert any(url.startswith("/ui/app.js") for url in urls)
    assert any(url.startswith("/ui/style.css") for url in urls)
    for url in urls:
        response = client.get(url)
        assert response.status_code == 200, url
        assert response.text.strip()
    assert "javascript" in client.get("/ui/app.js").headers["content-type"]
    assert "css" in client.get("/ui/style.css").headers["content-type"]


def test_dashboard_has_no_network_assets(page: str) -> None:
    script = (ROOT / "ui" / "app.js").read_text()
    style = (ROOT / "ui" / "style.css").read_text()
    assets = re.findall(r'<(?:script|link|img|iframe)\b[^>]*\b(?:src|href)="([^"]+)"', page)
    assert assets and all(url.startswith("/ui/") for url in assets), assets
    assert "@import" not in style and "url(" not in style
    assert not re.search(r"""fetch\(\s*["'`]https?:""", script)


@pytest.mark.parametrize("element_id", PDF_IDS + REVIEW_IDS + ["timelineStatus"])
def test_new_panel_ids_are_in_the_page_and_used_by_the_script(page: str,
                                                              element_id: str) -> None:
    script = (ROOT / "ui" / "app.js").read_text()
    assert len(re.findall(rf'\bid="{element_id}"', page)) == 1
    assert f'"{element_id}"' in script


def test_panels_have_tabs_and_the_upload_sends_the_customer_id_as_a_header(page: str) -> None:
    script = (ROOT / "ui" / "app.js").read_text()
    for screen in ("pdf", "reviews"):
        assert f'data-screen="{screen}"' in page
        assert f'<section id="{screen}" class="screen"' in page
    assert 'accept="application/pdf' in page
    assert 'value="CUST-A01"' in page and "CUST-A20" in page
    assert '"X-Customer-Id": customerId' in script
    assert '"Content-Type": "application/pdf"' in script
    assert "/applications/pdf?" in script
    upload_url = re.search(r"const params = new URLSearchParams\(([^)]*)\)", script)
    assert upload_url and "customer" not in upload_url.group(1).lower()
    assert "console.log" not in script


def test_every_model_selector_is_filled_from_the_model_list(client: TestClient,
                                                            page: str) -> None:
    script = (ROOT / "ui" / "app.js").read_text()
    selects = re.search(r"const MODEL_SELECTS = \[([^\]]*)\]", script)
    assert selects
    for element_id in ("liveModel", "pdfModel", "reviewModel"):
        assert f'"{element_id}"' in selects.group(1)
        assert f'<select id="{element_id}"' in page
    providers = {row["provider"] for row in client.get("/models").json()}
    assert {"mock", "gemini", "groq", "openrouter"} <= providers


def test_review_panel_workflow_and_cases_are_listed(client: TestClient) -> None:
    listed = {row["name"]: row for row in client.get("/workflows").json()}
    review = listed["review_sentiment"]
    assert review["error"] is None
    assert review["cases"][0] == "R01" and len(review["cases"]) >= 18
    assert "loan_prescreen" in listed


def test_both_screens_share_one_rate_limit_retry(page: str) -> None:
    script = (ROOT / "ui" / "app.js").read_text()
    assert script.count("async function withRateLimitRetry") == 1
    for caller in ("async function runPair", "async function liveRun", "async function pdfRun",
                   "async function reviewRun"):
        body = script.split(caller, 1)[1].split("\nasync function ", 1)[0]
        assert "withRateLimitRetry(" in body, caller
    assert "catch (_) {}\n  const record" not in script  # the event stream error is kept


@pytest.mark.skipif(shutil.which("node") is None, reason="node is not installed")
def test_app_js_parses() -> None:
    result = subprocess.run(["node", "--check", str(ROOT / "ui" / "app.js")],
                            capture_output=True, text=True, timeout=60)
    assert result.returncode == 0, result.stderr


@pytest.mark.skipif(shutil.which("node") is None, reason="node is not installed")
def test_stale_dashboard_responses_do_not_replace_current_workflow() -> None:
    script = r"""
const assert = require("node:assert/strict");
const fs = require("node:fs");
const vm = require("node:vm");
const elements = new Map();
const requests = {};
const fetch = url => new Promise(resolve => {
  requests[url] = value => resolve({ ok: true, json: async () => value });
});
const document = { getElementById(id) {
  if (!elements.has(id)) elements.set(id, { value: "C01", innerHTML: "", textContent: "", checked: false });
  return elements.get(id);
} };
const context = vm.createContext({ document, fetch, requests, performance: { now: () => 0 },
  setInterval, clearInterval });
vm.runInContext(fs.readFileSync(process.argv[1], "utf8")
  .replace("async function runPair(", "async function unusedRunPair(")
  .replace(/\ninit\(\);\s*$/, "\n") +
  "\nlet finishTimeline; async function runPair() { return new Promise(resolve => { finishTimeline = resolve; }); }\n",
  context);
(async () => {
  await vm.runInContext(`(async () => {
    state.selected = "loan_prescreen";
    state.workflowVersion = 1;
    const validation = validateRun();
    state.selected = "complaint_triage";
    state.workflowVersion = 2;
    requests["/validate"]({ passed: 1, checks: [], cases: [], verdicts: {} });
    await validation;
    if (state.validation !== null) throw new Error("stale validation replaced current workflow");

    const timeline = timelineRun();
    state.selected = "review_sentiment";
    state.workflowVersion = 3;
    finishTimeline({ baseline: { wall_ms: 2 }, compiled: { wall_ms: 1 } });
    await timeline;
    if (state.pair !== null) throw new Error("stale timeline replaced current workflow");

    state.benchMode = "mock";
    const mock = loadBench();
    state.benchMode = "live";
    const live = loadBench();
    requests["/bench/latest?mode=live"]([{ workflow: "live-marker" }]);
    await live;
    requests["/bench/latest?mode=mock"]([{ workflow: "mock-marker" }]);
    await mock;
    if (state.bench[0].workflow !== "live-marker") throw new Error("stale benchmark mode replaced current result");
  })()`, context);
  assert.equal(elements.get("validateRun").disabled, false);
  assert.equal(elements.get("timelineRun").disabled, false);
})().catch(error => { console.error(error); process.exitCode = 1; });
"""
    result = subprocess.run(["node", "-e", script, str(ROOT / "ui" / "app.js")],
                            capture_output=True, text=True, timeout=60)
    assert result.returncode == 0, result.stderr
