"""SQLite store: content-addressed records on the existing cache table (verification against
the original bytes, collisions, wall-clock expiry, kinds as namespaces), migration of an
old-schema database, and the in-memory memoisation rules through the executor."""

from __future__ import annotations

import asyncio
import logging
import sqlite3
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import pytest

from synapse.backends import open_backends
from synapse.backends.retrieval import KeywordRetriever
from synapse.compiler import compile_workflow
from synapse.executor import execute
from synapse.ir import Decision, ExecPlan, Node, NodeRun, RunRecord, Usage, Workflow
from synapse.passes import memoise
from synapse.passes.memoise import ExactCache
from synapse.store import Store

PDF = b"%PDF-1.7 statement for C1"
OTHER = b"%PDF-1.7 statement for C2"


@pytest.fixture
def store(tmp_path: Path) -> Store:
    with Store(tmp_path / "synapse.db") as opened:
        yield opened


def cache_rows(store: Store) -> list[sqlite3.Row]:
    return store.connection.execute("SELECT * FROM cache ORDER BY key").fetchall()


# Content-addressed records


def test_round_trip_returns_a_copy_and_the_sha256(store: Store) -> None:
    import hashlib
    digest = store.put_by_content("ocr", PDF, {"text": "Balance 100", "pages": [1]}, ttl_s=60)
    assert digest == hashlib.sha256(PDF).hexdigest()
    value = store.get_by_content("ocr", PDF)
    assert value == {"text": "Balance 100", "pages": [1]}
    value["text"] = "edited"
    assert store.get_by_content("ocr", PDF)["text"] == "Balance 100"
    (row,) = cache_rows(store)
    assert (row["key"], row["kind"], row["content_sha256"], bytes(row["content"])) == (
        f"ocr:{digest}", "ocr", digest, PDF)
    assert store.get_by_content("ocr", b"never stored") is None


def test_repeat_put_of_identical_bytes_updates_rather_than_duplicates(
        store: Store, monkeypatch: pytest.MonkeyPatch) -> None:
    clock = [1000.0]
    monkeypatch.setattr("synapse.store.time.time", lambda: clock[0])
    first = store.put_by_content("ocr", PDF, {"text": "v1"}, ttl_s=10)
    clock[0] = 1008.0
    second = store.put_by_content("ocr", bytearray(PDF), {"text": "v2"}, ttl_s=10)
    assert first == second and len(cache_rows(store)) == 1
    clock[0] = 1015.0  # past the first put's expiry, within the second's
    assert store.get_by_content("ocr", PDF) == {"text": "v2"}


def test_different_bytes_of_one_kind_are_separate_records(store: Store) -> None:
    a = store.put_by_content("ocr", PDF, {"text": "C1"})
    b = store.put_by_content("ocr", OTHER, {"text": "C2"})
    assert a != b and len(cache_rows(store)) == 2
    assert store.get_by_content("ocr", PDF) == {"text": "C1"}
    assert store.get_by_content("ocr", OTHER) == {"text": "C2"}


def test_kinds_are_separate_namespaces(store: Store) -> None:
    store.put_by_content("ocr", PDF, {"text": "C1"})
    assert store.get_by_content("layout", PDF) is None
    store.put_by_content("layout", PDF, {"blocks": 3})
    assert store.get_by_content("ocr", PDF) == {"text": "C1"}
    assert store.get_by_content("layout", PDF) == {"blocks": 3}
    with pytest.raises(ValueError, match="kind"):
        store.put_by_content("ocr:v2", PDF, {})  # ':' would let kinds overlap
    with pytest.raises(TypeError, match="bytes"):
        store.get_by_content("ocr", "a str is not bytes")  # type: ignore[arg-type]


def test_a_simulated_collision_never_returns_or_overwrites_the_other_document(
        store: Store, monkeypatch: pytest.MonkeyPatch, caplog: pytest.LogCaptureFixture) -> None:
    monkeypatch.setattr("synapse.store._content_digest", lambda content: "0" * 64)
    with caplog.at_level(logging.WARNING, logger="synapse.store"):
        first = store.put_by_content("ocr", PDF, {"text": "C1"})
        assert store.get_by_content("ocr", OTHER) is None  # same digest, other bytes
        second = store.put_by_content("ocr", OTHER, {"text": "C2"})
        assert store.get_by_content("ocr", OTHER) is None  # still not cached
    assert first == second == "0" * 64
    assert store.get_by_content("ocr", PDF) == {"text": "C1"}  # the original is kept
    (row,) = cache_rows(store)
    assert bytes(row["content"]) == PDF
    assert sum("collision" in record.message for record in caplog.records) == 3  # 2 gets, 1 put


def test_a_row_inserted_under_the_same_key_with_other_bytes_is_not_trusted(
        store: Store) -> None:
    import hashlib
    key = f"ocr:{hashlib.sha256(PDF).hexdigest()}"
    with store.connection:
        store.connection.execute(
            "INSERT INTO cache (key, value_json, created_at, ttl_s, kind, content) "
            "VALUES (?, '{\"text\": \"forged\"}', 0, NULL, 'ocr', ?)", (key, OTHER))
    assert store.get_by_content("ocr", PDF) is None
    store.put_by_content("ocr", PDF, {"text": "C1"})
    assert store.get_by_content("ocr", PDF) is None
    assert bytes(cache_rows(store)[0]["content"]) == OTHER


def test_an_expired_collision_is_replaced(store: Store, monkeypatch: pytest.MonkeyPatch) -> None:
    clock = [0.0]
    monkeypatch.setattr("synapse.store.time.time", lambda: clock[0])
    monkeypatch.setattr("synapse.store._content_digest", lambda content: "0" * 64)
    store.put_by_content("ocr", PDF, {"text": "C1"}, ttl_s=5)
    clock[0] = 5.0
    store.put_by_content("ocr", OTHER, {"text": "C2"})
    assert store.get_by_content("ocr", OTHER) == {"text": "C2"}
    assert store.get_by_content("ocr", PDF) is None


def test_ttl_uses_wall_clock_and_expired_rows_are_missing_and_deleted(
        store: Store, monkeypatch: pytest.MonkeyPatch) -> None:
    clock = [1_700_000_000.0]
    monkeypatch.setattr("synapse.store.time.time", lambda: clock[0])
    store.put_by_content("ocr", PDF, {"text": "C1"}, ttl_s=60)
    store.put_by_content("ocr", OTHER, {"text": "C2"})  # no ttl_s: never expires
    clock[0] += 59.9
    assert store.get_by_content("ocr", PDF) == {"text": "C1"}
    clock[0] += 0.1  # exactly ttl_s later, as ExactCache: expired
    assert store.get_by_content("ocr", PDF) is None
    assert [bytes(row["content"]) for row in cache_rows(store)] == [OTHER]
    clock[0] += 10 ** 9
    assert store.get_by_content("ocr", OTHER) == {"text": "C2"}
    with pytest.raises(ValueError, match="ttl_s"):
        store.put_by_content("ocr", PDF, {}, ttl_s=-1)


def test_records_survive_reopening_the_database(tmp_path: Path) -> None:
    with Store(tmp_path / "s.db") as first:
        first.put_by_content("ocr", PDF, {"text": "C1"}, ttl_s=3600)
    with Store(tmp_path / "s.db") as second:
        assert second.get_by_content("ocr", PDF) == {"text": "C1"}


# Migration from the old schema

OLD_SCHEMA = """
CREATE TABLE runs (run_id TEXT PRIMARY KEY, workflow TEXT, mode TEXT, plan_id TEXT,
  case_id TEXT, live INTEGER, cold_cache INTEGER, wall_ms REAL, created_at TEXT);
CREATE TABLE node_runs (run_id TEXT, node_id TEXT, start_s REAL, end_s REAL,
  tokens_in INTEGER, tokens_out INTEGER, model TEXT, cost REAL, cache_hit INTEGER,
  cpu_pct REAL, mem_mb REAL, error TEXT, output_json TEXT);
CREATE TABLE decisions (plan_id TEXT, workflow TEXT, pass_name TEXT, nodes_json TEXT,
  reason TEXT, status TEXT, predicted_ms REAL, predicted_cost REAL,
  measured_ms REAL, measured_cost REAL);
CREATE TABLE cache (key TEXT PRIMARY KEY, entity TEXT, value_json TEXT,
  created_at REAL, ttl_s INTEGER);
CREATE TABLE checks (run_id TEXT, case_id TEXT, node_id TEXT, kind TEXT,
  passed INTEGER, detail TEXT);
"""


def test_an_old_schema_database_migrates_and_keeps_runs_and_decisions(tmp_path: Path) -> None:
    path = tmp_path / "old.db"
    old = sqlite3.connect(path)
    old.executescript(OLD_SCHEMA)
    old.execute("INSERT INTO runs VALUES ('old1', 'toy', 'baseline', NULL, 'A01', 0, 1, 5.0, 'x')")
    old.execute("INSERT INTO node_runs VALUES ('old1', 'a', 0, 1, 2, 3, 'm', 0.5, 0, NULL, NULL, "
                "NULL, '{\"a_out\": 1}')")
    old.execute("INSERT INTO cache VALUES ('legacy', 'C1', '{}', 0, 60)")
    old.commit()
    old.close()

    with Store(path) as store:
        columns = {row["name"] for row in store.connection.execute("PRAGMA table_info(cache)")}
        assert {"kind", "content_sha256", "content"} <= columns
        legacy = store.load_run("old1")
        assert legacy.nodes[0].output == {"a_out": 1} and legacy.nodes[0].usage.tokens_in == 2
        assert store.load_run_metadata("old1") == {}
        record = RunRecord(run_id="new1", workflow="toy", mode="compiled", plan_id="p1",
                           case_id="A02", wall_ms=7.0, latency_scale=0.01, nodes=[
                               NodeRun(run_id="new1", node_id="a", start_s=0, end_s=1,
                                       usage=Usage(tokens_in=4, model="m"), retries=1,
                                       input_hash="f" * 64, output={"a_out": 2})])
        store.save_run(record, metadata={"provider": "groq", "model": "openai/gpt-oss-20b"})
        assert store.load_run("new1") == record
        assert store.load_run_metadata("new1") == {
            "provider": "groq", "model": "openai/gpt-oss-20b"}
        assert store.list_runs("toy") == ["old1", "new1"]
        wf = Workflow(name="toy", inputs=["x"], outputs=["a_out"], nodes=[
            Node(id="a", kind="transform", effect="pure", inputs=["x"], outputs=["a_out"])])
        plan = ExecPlan(plan_id="p1", workflow=wf, decisions=[
            Decision(pass_name="memoise", nodes=["a"], reason="pure", status="applied")])
        store.save_decisions(plan)
        store.save_decisions(plan)  # replaces, does not duplicate
        assert store.connection.execute("SELECT COUNT(*) FROM decisions").fetchone()[0] == 1
        store.put_by_content("ocr", PDF, {"text": "C1"})
        assert store.get_by_content("ocr", PDF) == {"text": "C1"}
        assert tuple(store.connection.execute(
            "SELECT entity, ttl_s FROM cache WHERE key='legacy'").fetchone()) == ("C1", 60)
    with Store(path) as reopened:  # migrating twice is a no-op
        assert reopened.get_by_content("ocr", PDF) == {"text": "C1"}
        assert reopened.load_run_metadata("new1")["provider"] == "groq"


# Memoisation through the executor (in-memory ExactCache, unchanged)


@pytest.mark.parametrize("passes", [("memoise",), ("parallelise", "memoise")])
def test_cached_read_expires_after_ttl_and_a_write_to_the_customer_invalidates_it(
        monkeypatch: pytest.MonkeyPatch, passes: tuple[str, ...]) -> None:
    clock = [0.0]
    # Only memoise's clock is faked: the asyncio loop keeps the real time.monotonic.
    monkeypatch.setattr(memoise, "time", SimpleNamespace(monotonic=lambda: clock[0]))
    balances = {"C1": 100}
    reads: list[str] = []

    def read_balance(inputs: dict[str, Any]) -> dict[str, Any]:
        reads.append(inputs["customer_id"])
        return {"balance": balances[inputs["customer_id"]]}

    def pay(inputs: dict[str, Any]) -> dict[str, Any]:
        balances[inputs["customer_id"]] -= 30
        return {"paid": True}

    read = Node(id="read", kind="transform", effect="read", ttl_s=60, deterministic=True,
                inputs=["customer_id"], outputs=["balance"])
    write = Node(id="pay", kind="transform", effect="write", inputs=["customer_id"],
                 outputs=["paid"])
    only_read = Workflow(name="toy", inputs=["customer_id"], nodes=[read], outputs=["balance"])
    pay_then_read = Workflow(name="toy", inputs=["customer_id"], nodes=[write, read],
                             outputs=["paid", "balance"])
    plans = {wf.nodes[0].id: compile_workflow(wf, passes=passes)
             for wf in (only_read, pay_then_read)}
    assert all("read" in plan.cached_nodes and "pay" not in plan.cached_nodes
               for plan in plans.values())
    cache = ExactCache()

    async def go() -> list[tuple[int, bool]]:
        seen = []
        async with open_backends(live=False, scale=0.001, retriever=KeywordRetriever(),
                                 functions={"read": read_balance, "pay": pay}) as backends:
            for at, wf in [(0, only_read), (59.9, only_read), (60, only_read),
                           (61, pay_then_read), (62, only_read)]:
                clock[0] = at
                record = await execute(wf, {"case_id": "T", "customer_id": "C1"}, "compiled",
                                       backends, plan=plans[wf.nodes[0].id], cache=cache)
                assert all(node.error is None for node in record.nodes)
                (node,) = [n for n in record.nodes if n.node_id == "read"]
                seen.append((node.output["balance"], node.cache_hit))
        return seen

    assert asyncio.run(go()) == [
        (100, False),  # first read
        (100, True),   # within ttl_s: reused
        (100, False),  # ttl_s elapsed: read again
        (70, False),   # the write ran first in this run, so the cached read was dropped
        (70, True),    # the post-write read is cached in turn
    ]
    assert reads == ["C1"] * 3


@pytest.mark.parametrize("passes", [("memoise",), ("parallelise", "memoise")])
def test_errored_write_invalidates_warm_read_cache(passes: tuple[str, ...]) -> None:
    balance = {"C1": 0}
    reads: list[int] = []

    def read_balance(inputs: dict[str, Any]) -> dict[str, Any]:
        value = balance[inputs["customer_id"]]
        reads.append(value)
        return {"balance": value}

    def commit_then_lose_response(inputs: dict[str, Any]) -> dict[str, Any]:
        balance[inputs["customer_id"]] += 1
        raise RuntimeError("response lost after commit")

    read = Node(id="read", kind="transform", effect="read", ttl_s=60,
                deterministic=True, inputs=["customer_id"], outputs=["balance"])
    write = Node(id="pay", kind="transform", effect="write",
                 inputs=["customer_id"], outputs=["paid"])
    only_read = Workflow(name="toy", inputs=["customer_id"], nodes=[read],
                         outputs=["balance"])
    read_then_write = Workflow(name="toy", inputs=["customer_id"], nodes=[read, write],
                               outputs=["balance", "paid"])
    read_plan = compile_workflow(only_read, passes=passes)
    write_plan = compile_workflow(read_then_write, passes=passes)
    cache = ExactCache()

    async def check() -> None:
        async with open_backends(live=False, scale=.001, retriever=KeywordRetriever(),
                                 functions={"read": read_balance,
                                            "pay": commit_then_lose_response}) as backends:
            case = {"case_id": "T", "customer_id": "C1"}
            first = await execute(only_read, case, "compiled", backends,
                                  plan=read_plan, cache=cache)
            failed = await execute(read_then_write, case, "compiled", backends,
                                   plan=write_plan, cache=cache)
            assert failed.nodes[-1].error == "RuntimeError: response lost after commit"
            assert failed.nodes[0].cache_hit
            assert balance["C1"] == 1
            later = await execute(only_read, case, "compiled", backends,
                                  plan=read_plan, cache=cache)
            assert first.nodes[0].output["balance"] == 0
            assert later.nodes[0].output["balance"] == 1
            assert not later.nodes[0].cache_hit

    asyncio.run(check())
    assert reads == [0, 1]


@pytest.mark.parametrize("passes", [("memoise",), ("parallelise", "memoise")])
def test_write_invalidates_shared_account_read_across_customers(
        passes: tuple[str, ...]) -> None:
    balances = {"TEST-ACC-JOINT": 100}
    reads: list[int] = []

    def read_balance(inputs: dict[str, Any]) -> dict[str, Any]:
        value = balances[inputs["account_id"]]
        reads.append(value)
        return {"balance": value}

    def debit(inputs: dict[str, Any]) -> dict[str, Any]:
        balances[inputs["account_id"]] -= 30
        return {"paid": True}

    read = Node(id="read", kind="transform", effect="read", ttl_s=60,
                deterministic=True, inputs=["account_id"], outputs=["balance"])
    write = Node(id="debit", kind="transform", effect="write",
                 inputs=["account_id"], outputs=["paid"])
    only_read = Workflow(name="joint_account", inputs=["customer_id", "account_id"],
                         nodes=[read], outputs=["balance"])
    only_write = Workflow(name="joint_account", inputs=["customer_id", "account_id"],
                          nodes=[write], outputs=["paid"])
    read_plan = compile_workflow(only_read, passes=passes)
    write_plan = compile_workflow(only_write, passes=passes)
    cache = ExactCache()

    async def check() -> None:
        async with open_backends(live=False, scale=.001, retriever=KeywordRetriever(),
                                 functions={"read": read_balance, "debit": debit}) as backends:
            account = "TEST-ACC-JOINT"
            first = await execute(only_read, {"case_id": "J1", "customer_id": "C1",
                                              "account_id": account}, "compiled", backends,
                                  plan=read_plan, cache=cache)
            changed = await execute(only_write, {"case_id": "J2", "customer_id": "C2",
                                                 "account_id": account}, "compiled", backends,
                                    plan=write_plan, cache=cache)
            later = await execute(only_read, {"case_id": "J1", "customer_id": "C1",
                                              "account_id": account}, "compiled", backends,
                                  plan=read_plan, cache=cache)
            assert all(node.error is None for run in (first, changed, later)
                       for node in run.nodes)
            assert first.nodes[0].output["balance"] == 100
            assert later.nodes[0].output["balance"] == 70
            assert not later.nodes[0].cache_hit

    asyncio.run(check())
    assert reads == [100, 70]
