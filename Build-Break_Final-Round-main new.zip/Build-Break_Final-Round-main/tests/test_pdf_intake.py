"""PDF intake wired into the CLI and API: an uploaded application runs the loan workflow,
bad uploads get clear errors with the right HTTP status, the extraction is cached by content
hash, and an OCR'd PAN that is not a valid PAN is flagged for review instead of guessed."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from fpdf import FPDF

import synapse.store
from mock_services import loan, suite_for
from synapse import ROOT
from synapse.api import create_app
from synapse.backends.retrieval import KeywordRetriever
from synapse.cli import main
from synapse.documents import review_flags

LOAN = ROOT / "workflows" / "loan_prescreen.yaml"


def text_pdf(case_id: str) -> bytes:
    """A one-page text PDF of a synthetic applicant's application."""
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Helvetica", size=12)
    for line in loan.application_text(loan.applicant(case_id)).splitlines():
        pdf.cell(0, 8, line, new_x="LMARGIN", new_y="NEXT")
    return bytes(pdf.output())


@pytest.fixture
def isolated_store(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Point the CLI's default Store at a temporary database."""
    db = tmp_path / "cli.db"
    real = synapse.store.Store
    monkeypatch.setattr(synapse.store, "Store", lambda path=db: real(path))
    return db


def test_extract_pdf_reports_metadata_and_reuses_the_cache(
        tmp_path: Path, isolated_store: Path, capsys: pytest.CaptureFixture[str]) -> None:
    path = tmp_path / "A04.pdf"
    path.write_bytes(text_pdf("A04"))
    assert main(["extract-pdf", str(path)]) == 0
    first = json.loads(capsys.readouterr().out)
    assert (first["method"], first["pages"], first["from_cache"]) == ("text", 1, False)
    assert first["review_flags"] == [] and "text" not in first
    assert main(["extract-pdf", str(path)]) == 0
    assert json.loads(capsys.readouterr().out)["from_cache"] is True


def test_extract_pdf_explains_a_bad_upload(tmp_path: Path, isolated_store: Path,
                                           capsys: pytest.CaptureFixture[str]) -> None:
    path = tmp_path / "bad.pdf"
    path.write_bytes(b"not a pdf at all")
    assert main(["extract-pdf", str(path)]) == 1
    assert "not a PDF" in capsys.readouterr().err


def test_run_takes_a_pdf_application(tmp_path: Path, isolated_store: Path, embedding_model: str,
                                     capsys: pytest.CaptureFixture[str]) -> None:
    path = tmp_path / "A04.pdf"
    path.write_bytes(text_pdf("A04"))
    assert main(["run", str(LOAN), "--application-pdf", str(path), "--customer-id",
                 "CUST-A04", "--latency-scale", "0.001"]) == 0
    row = capsys.readouterr().out.rstrip().splitlines()[-1].split()
    assert row[:2] == ["UPLOAD", suite_for("loan_prescreen").expected("A04")]


def test_run_with_a_pdf_needs_a_customer_id(tmp_path: Path,
                                            capsys: pytest.CaptureFixture[str]) -> None:
    path = tmp_path / "A04.pdf"
    path.write_bytes(text_pdf("A04"))
    assert main(["run", str(LOAN), "--application-pdf", str(path)]) == 1
    assert "--customer-id" in capsys.readouterr().err


@pytest.fixture
def client(tmp_path: Path) -> TestClient:
    app = create_app(db_path=tmp_path / "api.db", results_dir=tmp_path / "results",
                     backend_options={"retriever": KeywordRetriever()})
    with TestClient(app) as test_client:
        yield test_client


def upload(client: TestClient, body: bytes, customer: str | None = "CUST-A01",
           **params: str) -> object:
    headers = {"Content-Type": "application/pdf"}
    if customer:
        headers["X-Customer-Id"] = customer
    return client.post("/applications/pdf", content=body, headers=headers,
                       params={"scale": "0.001", **params})


def test_api_upload_runs_the_loan_workflow_without_echoing_the_text(client: TestClient) -> None:
    response = upload(client, text_pdf("A01"), mode="compiled")
    assert response.status_code == 200
    body = response.json()
    assert body["document"]["method"] == "text" and "text" not in body["document"]
    run_id = body["run"]["run_id"]
    with client.websocket_connect(f"/ws/runs/{run_id}") as websocket:
        while websocket.receive_json()["type"] != "run_end":
            pass
    record = client.get(f"/runs/{run_id}").json()
    assert record["status"] == "done" and record["mode"] == "compiled"
    assert record["key_value"] == suite_for("loan_prescreen").expected("A01")


@pytest.mark.parametrize(("body", "customer", "headers", "status", "message"), [
    pytest.param(b"%PDF-", "CUST-A01", {}, 422, "PDF", id="damaged-pdf"),
    pytest.param(b"hello", "CUST-A01", {}, 422, "not a PDF", id="not-a-pdf"),
    pytest.param(b"x", None, {}, 422, "X-Customer-Id", id="no-customer-header"),
    pytest.param(b"x", "CUST-A01", {"Content-Length": str(50 * 1024 * 1024)}, 413, "limit",
                 id="declared-too-large"),
])
def test_api_rejects_bad_uploads_with_clear_errors(client: TestClient, body: bytes,
                                                   customer: str | None, headers: dict[str, str],
                                                   status: int, message: str) -> None:
    request_headers = {"Content-Type": "application/pdf", **headers}
    if customer:
        request_headers["X-Customer-Id"] = customer
    if "Content-Length" in headers:  # the declared size is refused before the body is read
        response = client.post("/applications/pdf", content=body, headers=request_headers)
    else:
        response = upload(client, body, customer)
    assert response.status_code == status
    assert message in response.json()["detail"]


def test_an_unreadable_ocr_pan_is_flagged_and_never_guessed() -> None:
    assert review_flags("PAN: FAKEPOOO04D\n", ocr_used=True)  # 11 characters after OCR
    assert review_flags("PAN: FAKEP0004D\n", ocr_used=True) == []
    assert review_flags("PAN: anything\n", ocr_used=False) == []  # text layers are exact


@pytest.mark.parametrize(("params", "message"), [
    pytest.param({"model": "nvidia/nemotron-3.5-super-vl:free"}, "not configured",
                 id="model-without-live-provider"),
    pytest.param({"provider": "groq", "model": "not-a-model"}, "not configured",
                 id="model-not-in-config"),
])
def test_api_upload_rejects_a_model_the_provider_does_not_have(
        client: TestClient, params: dict[str, str], message: str) -> None:
    response = upload(client, text_pdf("A01"), **params)
    assert response.status_code == 422 and message in response.json()["detail"]


def test_api_upload_refuses_an_unknown_provider(client: TestClient) -> None:
    assert upload(client, text_pdf("A01"), provider="telepathy").status_code == 422


def test_api_upload_stops_reading_a_body_without_length_once_over_the_limit(
        client: TestClient, monkeypatch: pytest.MonkeyPatch) -> None:
    from synapse import documents
    real = documents.DocumentSettings.load
    monkeypatch.setattr(documents.DocumentSettings, "load",
                        classmethod(lambda cls, **kw: real(**{**kw, "max_bytes": 1024})))
    chunks = (b"%PDF-" + b"x" * 600 for _ in range(4))  # streamed: no Content-Length
    response = client.post("/applications/pdf", content=chunks,
                           headers={"Content-Type": "application/pdf",
                                    "X-Customer-Id": "CUST-A01"})
    assert response.status_code == 413
