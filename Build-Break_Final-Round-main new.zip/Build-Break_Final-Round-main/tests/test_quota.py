"""Local free-tier budgets are shared and survive a new guard instance."""

from __future__ import annotations

import sqlite3

import pytest

from synapse.backends import quota


def test_quota_reservations_enforce_minute_day_and_provider_blocks(tmp_path, monkeypatch) -> None:
    now = [1_000_000.0]
    monkeypatch.setitem(quota.LIMITS, "groq", quota.Limit(rpm=2, rpd=3, tpm=2_000,
                                                       tpd=4_000))
    guard = quota.QuotaGuard(tmp_path / "quota.db", clock=lambda: now[0])
    first = guard.reserve("groq", "test-model", "hello")
    guard.settle(first, 10)
    guard.reserve("groq", "test-model", "hello")
    with pytest.raises(quota.QuotaExceeded, match="minute budget") as caught:
        guard.reserve("groq", "test-model", "hello")
    assert caught.value.retry_after_s == pytest.approx(60.1)
    now[0] += 61
    another = quota.QuotaGuard(tmp_path / "quota.db", clock=lambda: now[0])
    another.reserve("groq", "test-model", "hello")
    with pytest.raises(quota.QuotaExceeded, match="daily budget") as daily:
        another.reserve("groq", "test-model", "hello")
    assert daily.value.retry_after_s is None
    assert another.status("groq", "test-model")["rpd_remaining"] == 0
    now[0] += 86_401
    assert another.status("groq", "test-model")["rpd_remaining"] == 3
    another.block("groq", "test-model")
    with pytest.raises(quota.QuotaExceeded, match="daily quota is exhausted"):
        another.reserve("groq", "test-model", "hello")


def test_advisory_daily_quota_allows_user_to_try_again(tmp_path, monkeypatch) -> None:
    now = [1_000_000.0]
    monkeypatch.setitem(quota.LIMITS, "groq", quota.Limit(rpm=2, rpd=1, tpm=2_000, tpd=100))
    guard = quota.QuotaGuard(tmp_path / "quota.db", clock=lambda: now[0], advisory_daily=True)
    guard.block("groq", "test")
    assert guard.status("groq", "test")["blocked"]
    ticket = guard.reserve("groq", "test", "hello")
    guard.settle(ticket, 50)
    assert not guard.status("groq", "test")["blocked"]
    assert guard.status("groq", "test")["rpd_remaining"] == 0
    now[0] += 61
    assert guard.reserve("groq", "test", "hello") > ticket


def test_two_groq_accounts_have_independent_local_ledgers(tmp_path, monkeypatch) -> None:
    monkeypatch.setitem(quota.LIMITS, "groq", quota.Limit(rpm=1, rpd=1, tpm=2_000,
                                                       tpd=4_000))
    path = tmp_path / "quota.db"
    original = quota.QuotaGuard(quota.quota_path_for_role(path, "groq", "original"))
    compiled = quota.QuotaGuard(quota.quota_path_for_role(path, "groq", "compiled"))
    assert original.path != compiled.path
    original.reserve("groq", "openai/gpt-oss-20b", "hello")
    assert original.status("groq", "openai/gpt-oss-20b")["rpd_remaining"] == 0
    assert compiled.status("groq", "openai/gpt-oss-20b")["rpd_remaining"] == 1
    compiled.reserve("groq", "openai/gpt-oss-20b", "hello")
    assert compiled.status("groq", "openai/gpt-oss-20b")["rpd_remaining"] == 0
    assert quota.quota_path_for_role(path, "gemini", "compiled") == path


def test_openrouter_free_models_share_one_account_budget(tmp_path, monkeypatch) -> None:
    now = [1_000_000.0]
    monkeypatch.setitem(quota.LIMITS, "openrouter", quota.Limit(
        rpm=1, rpd=2, tpm=4_000, tpd=8_000))
    guard = quota.QuotaGuard(tmp_path / "quota.db", clock=lambda: now[0],
                             advisory_daily=True)
    first = "first/model:free"
    second = "second/model:free"
    guard.reserve("openrouter", first, "hello", output_tokens=100)
    with pytest.raises(quota.QuotaExceeded, match="minute budget"):
        guard.reserve("openrouter", second, "hello", output_tokens=100)
    assert guard.status("openrouter", second)["rpm_remaining"] == 0
    guard.block("openrouter", first)
    assert guard.status("openrouter", second)["blocked"]
    now[0] += 61
    guard.reserve("openrouter", second, "hello", output_tokens=100)
    assert guard.status("openrouter", first)["rpd_remaining"] == 0


def test_existing_openrouter_free_model_counts_migrate_to_shared_budget(tmp_path) -> None:
    path = tmp_path / "quota.db"
    with sqlite3.connect(path) as db:
        db.execute("CREATE TABLE calls (id INTEGER PRIMARY KEY, provider TEXT, model TEXT, "
                   "at REAL, tokens INTEGER)")
        db.execute("CREATE TABLE blocks (provider TEXT, model TEXT, until REAL, "
                   "PRIMARY KEY(provider, model))")
        db.execute("INSERT INTO calls (provider, model, at, tokens) VALUES "
                   "('openrouter', 'first/model:free', 1000, 100), "
                   "('openrouter', 'second/model:free', 1000, 200)")
        db.execute("INSERT INTO blocks VALUES ('openrouter', 'first/model:free', 2000)")
    guard = quota.QuotaGuard(path, clock=lambda: 1000, advisory_daily=True)
    assert guard.status("openrouter", "third/model:free")["rpd_remaining"] == 48
    assert guard.status("openrouter", "third/model:free")["blocked"]
    with sqlite3.connect(path) as db:
        assert db.execute("SELECT COUNT(DISTINCT model) FROM calls").fetchone()[0] == 1
